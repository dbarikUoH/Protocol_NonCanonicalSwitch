% *************************************************************************
% This function plots the one-parameter bifurcation diagrams of the 
% bistable switches.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function plot_bifurcation(bfrSN,vss1,vus1)

pos=bfrSN(:,1)-1;
hold on
if length(pos)==0
    plot(vss1(:,1),vss1(:,2),'color','k','linewidth',1.0)
elseif length(pos)==1
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:end,1),vss1(pos(1)+1:end,2),'color','k','linewidth',1.0)
elseif length(pos)==2
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:pos(2),1),vss1(pos(1)+1:pos(2),2),'color','k','linewidth',1.0)
    plot(vss1(pos(2)+1:end,1),vss1(pos(2)+1:end,2),'color','k','linewidth',1.0)
elseif length(pos)==3
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:pos(2),1),vss1(pos(1)+1:pos(2),2),'color','k','linewidth',1.0)
    plot(vss1(pos(2)+1:pos(3),1),vss1(pos(2)+1:pos(3),2),'color','k','linewidth',1.0)
    plot(vss1(pos(3)+1:end,1),vss1(pos(3)+1:end,2),'color','k','linewidth',1.0)
elseif length(pos)==4
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:pos(2),1),vss1(pos(1)+1:pos(2),2),'color','k','linewidth',1.0)
    plot(vss1(pos(2)+1:pos(3),1),vss1(pos(2)+1:pos(3),2),'color','k','linewidth',1.0)
    plot(vss1(pos(3)+1:pos(4),1),vss1(pos(3)+1:pos(4),2),'color','k','linewidth',1.0)
    plot(vss1(pos(4)+1:end,1),vss1(pos(4)+1:end,2),'color','k','linewidth',1.0)
elseif length(pos)==5
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:pos(2),1),vss1(pos(1)+1:pos(2),2),'color','k','linewidth',1.0)
    plot(vss1(pos(2)+1:pos(3),1),vss1(pos(2)+1:pos(3),2),'color','k','linewidth',1.0)
    plot(vss1(pos(3)+1:pos(4),1),vss1(pos(3)+1:pos(4),2),'color','k','linewidth',1.0)
    plot(vss1(pos(4)+1:pos(5),1),vss1(pos(4)+1:pos(5),2),'color','k','linewidth',1.0)
    plot(vss1(pos(5)+1:end,1),vss1(pos(5)+1:end,2),'color','k','linewidth',1.0)
elseif length(pos)==6
    plot(vss1(1:pos(1),1),vss1(1:pos(1),2),'color','k','linewidth',1.0)
    plot(vss1(pos(1)+1:pos(2),1),vss1(pos(1)+1:pos(2),2),'color','k','linewidth',1.0)
    plot(vss1(pos(2)+1:pos(3),1),vss1(pos(2)+1:pos(3),2),'color','k','linewidth',1.0)
    plot(vss1(pos(3)+1:pos(4),1),vss1(pos(3)+1:pos(4),2),'color','k','linewidth',1.0)
    plot(vss1(pos(4)+1:pos(5),1),vss1(pos(4)+1:pos(5),2),'color','k','linewidth',1.0)
    plot(vss1(pos(5)+1:pos(6),1),vss1(pos(5)+1:pos(6),2),'color','k','linewidth',1.0)
    plot(vss1(pos(6)+1:end,1),vss1(pos(6)+1:end,2),'color','k','linewidth',1.0)
end
plot(vss1(:,1),vss1(:,3),'color','k','linewidth',1.0)
plot(vus1(:,1),vus1(:,2),'color','r','linewidth',1.0)