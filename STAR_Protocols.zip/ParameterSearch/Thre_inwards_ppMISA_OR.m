% *************************************************************************
% Calculation of threshold values (J_{XY}) in the Hill functions in the 
% bistable networks. The calculated threshold values ensure that the
% probability of transition in ultrasensitive switch is not baised either
% towards actiation or inhibition.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
% *************************************************************************
% Model: ppMISA
% Logic Gate: OR
% *************************************************************************

% *************************************************************************
% Caculation of steady state distributions of A, B and S from the unregulated
% networks: -> A -> ; -> B -> ; -> S -> 
% The threshold of signal, S, (J_{XS}) is calculated from unregulated S
% *************************************************************************

clear
clc
% sample size
nr=1000000;

% range for the unregulated synthesis rates
gsI=1.0;
gsL=10.0;

% range for the regulated synthesis rates
gsIr=1.0;
gsLr=100.0;

% range for the Hill coefficients
nI=1;
nL=10;

% range for the degradation rates
gdI=0.01;
gdL=0.1;

% sampling unregualted synthesis rates from uniform distribution
ga0=gsI+(gsL-gsI)*rand(nr,1);
gb0=gsI+(gsL-gsI)*rand(nr,1);
gs0=gsI+(gsL-gsI)*rand(nr,1);

% sampling degradation rates from uniform distribution
ga=gdI+(gdL-gdI)*rand(nr,1);
gb=gdI+(gdL-gdI)*rand(nr,1);
gs=gdI+(gdL-gdI)*rand(nr,1);

% steady state values of A, B and S
aa_iso=ga0./ga;             % A
bb_iso=gb0./gb;             % B
ss_iso=gs0./gs;             % S

% Converting the SS distributions into log scale
aisoLog=log2(aa_iso);
bisoLog=log2(bb_iso);
sisoLog=log2(ss_iso);

% Truncating the log distribution 
athreLog=aisoLog(aisoLog>0.02*median(aisoLog) & aisoLog<1.98*median(aisoLog));
bthreLog=bisoLog(bisoLog>0.02*median(bisoLog) & bisoLog<1.98*median(bisoLog));
sthreLog=sisoLog(sisoLog>0.02*median(sisoLog) & sisoLog<1.98*median(sisoLog));

% Converting it back to linear distribution
athre_iso=2.^athreLog;
bthre_iso=2.^bthreLog;
sthre_iso=2.^sthreLog;

% figure(1)
% subplot(2,2,1)
% hist(aisoLog,100)
% hold on
% hist(athreLog,100)
% subplot(2,2,2)
% hist(bisoLog,100)
% hold on
% hist(bthreLog,100)
% subplot(3,1,1)
% hist(sisoLog,100)
% hold on
% hist(sthre_iso,100)

% saving the threshold values of S regulation: J_{XS}
save -ascii jas_in_ppMISA_OR.dat sthre_iso

% *************************************************************************
% Calculation of threshold values of A regulation from the 'inward to A'
% network segment of ppMISA network (S -> A |- B)


nr1=min([length(athre_iso) length(bthre_iso) length(sthre_iso)]);

ga0=gsI+(gsL-gsI)*rand(nr1,1);
gas=gsIr+(gsLr-gsIr)*rand(nr1,1);
gab=gsIr+(gsLr-gsIr)*rand(nr1,1);
nas=randi([nI nL],nr1,1);
nab=randi([nI nL],nr1,1);
ga=gdI+(gdL-gdI)*rand(nr1,1);

AS_int=(ss_iso./sthre_iso).^nas./(1+(ss_iso./sthre_iso).^nas);
               
AB_int=1-(bb_iso./bthre_iso).^nab./(1+(bb_iso./bthre_iso).^nab);

aa_in=(ga0+gas.*AS_int+gab.*AB_int)./ga;   % SS equation of A  

% Converting into log
ainLog=log2(aa_in);

% Truncating the log distribution
athreLog_in=ainLog(ainLog>0.02*median(ainLog) & ainLog<1.98*median(ainLog));

% Reconverting log into linear distribution
athre_in=2.^athreLog_in;

% figure(1)
% subplot(3,1,2)
% hist(ainLog,100)
% hold on
% hist(athreLog_in,100)

% saving the threshold values of A regulation: J_{BA}
save -ascii jba_in_ppMISA_OR.dat athre_in

% *************************************************************************
% Calculation of threshold values of B regulation from the 'inward to B'
% network segment of ppMISA network (S -> B |- A)

gb0=gsI+(gsL-gsI)*rand(nr1,1);
gbs=gsIr+(gsLr-gsIr)*rand(nr1,1);
gba=gsIr+(gsLr-gsIr)*rand(nr1,1);
gbb=gsIr+(gsLr-gsIr)*rand(nr1,1);
nbs=randi([nI nL],nr1,1);
nba=randi([nI nL],nr1,1);
nbb=randi([nI nL],nr1,1);
gb=gdI+(gdL-gdI)*rand(nr1,1);

BS_int=(ss_iso./sthre_iso).^nbs./(1+(ss_iso./sthre_iso).^nbs);

BA_int=1-(aa_iso./athre_iso).^nba./(1+(aa_iso./athre_iso).^nba);

BB_int=(bb_iso./bthre_iso).^nbb./(1+(bb_iso./bthre_iso).^nbb);

bb_in=(gb0+gbs.*BS_int+gba.*BA_int+gbb.*BB_int)./gb;        % SS equation for B

% Converting into log distribution
binLog=log2(bb_in);

% Truncating the log distribution
bthreLog_in=binLog(binLog>0.02*median(binLog) & binLog<1.98*median(binLog));

% Reconverting into linear distribution
bthre_in=2.^bthreLog_in;

% figure(1)
% subplot(3,1,3)
% hist(binLog,100)
% hold on
% hist(bthreLog_in,100)

% saving the threshold values of B regulation: J_{AB}
save -ascii jab_in_ppMISA_OR.dat bthre_in