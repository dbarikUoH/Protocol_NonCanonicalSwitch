% *************************************************************************
% This functions stores the counts of the 189 bistable switches, both 
% reversible and irreversible, and their parameters in structured arrays.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [ppMISA_OR_dataR]=BS_saveCnt_189BS(Cnt)

tot_Is=Cnt.Is;
tot_BsB=Cnt.BsB;
tot_BsF=Cnt.BsF;
tot_InIs=Cnt.InIs;
tot_DIs=Cnt.DIs;
tot_BsB_Is=Cnt.BsB_Is;
tot_BsF_Is=Cnt.BsF_Is;
tot_Is_BsB=Cnt.Is_BsB;
tot_Is_BsF=Cnt.Is_BsF;
tot_InIs_Is=Cnt.InIs_Is;
tot_DBsB=Cnt.DBsB;
tot_InMsh=Cnt.InMsh;
tot_Msh=Cnt.Msh;
tot_DBsF=Cnt.DBsF;
tot_Is_InIs=Cnt.Is_InIs;
tot_InIs_BsB=Cnt.InIs_BsB;
tot_InIs_BsF=Cnt.InIs_BsF;
tot_BsB_InIs=Cnt.BsB_InIs;
tot_BsF_InIs=Cnt.BsF_InIs;
tot_DInIs=Cnt.DInIs;
tot_TIs=Cnt.TIs;
tot_BsB_DIs=Cnt.BsB_DIs;
tot_BsF_DIs=Cnt.BsF_DIs;
tot_Is_BsB_Is=Cnt.Is_BsB_Is;
tot_Is_BsF_Is=Cnt.Is_BsF_Is;
tot_DIs_BsB=Cnt.DIs_BsB;
tot_DIs_BsF=Cnt.DIs_BsF;
tot_InIs_DIs=Cnt.InIs_DIs;
tot_DBsB_Is=Cnt.DBsB_Is;
tot_InMsh_Is=Cnt.InMsh_Is;
tot_BsB_Is_BsB=Cnt.BsB_Is_BsB;
tot_BsB_Is_BsF=Cnt.BsB_Is_BsF;
tot_Msh_Is=Cnt.Msh_Is;
tot_DBsF_Is=Cnt.DBsF_Is;
tot_BsF_Is_BsB=Cnt.BsF_Is_BsB;
tot_BsF_Is_BsF=Cnt.BsF_Is_BsF;
tot_Is_InIs_Is=Cnt.Is_InIs_Is;
tot_Is_DBsB=Cnt.Is_DBsB;
tot_Is_InMsh=Cnt.Is_InMsh;
tot_Is_Msh=Cnt.Is_Msh;
tot_Is_DBsF=Cnt.Is_DBsF;
tot_DIs_Is=Cnt.DIs_Is;
tot_InIs_BsB_Is=Cnt.InIs_BsB_Is;
tot_InIs_BsF_Is=Cnt.InIs_BsF_Is;
tot_InIs_Is_BsB=Cnt.InIs_Is_BsB;
tot_InIs_Is_BsF=Cnt.InIs_Is_BsF;
tot_BsB_InIs_Is=Cnt.BsB_InIs_Is;
tot_TBsB=Cnt.TBsB;
tot_BsB_InMsh=Cnt.BsB_InMsh;
tot_InMsh_BsB=Cnt.InMsh_BsB;
tot_InMsh_BsF=Cnt.InMsh_BsF;
tot_BsB_Is_InIs=Cnt.BsB_Is_InIs;
tot_BsF_InIs_Is=Cnt.BsF_InIs_Is;
tot_Msh_BsB=Cnt.Msh_BsB;
tot_Msh_BsF=Cnt.Msh_BsF;
tot_BsF_Msh=Cnt.BsF_Msh;
tot_TBsF=Cnt.TBsF;
tot_BsF_Is_InIs=Cnt.BsF_Is_InIs;
tot_Is_InIs_BsB=Cnt.Is_InIs_BsB;
tot_Is_InIs_BsF=Cnt.Is_InIs_BsF;
tot_Is_BsB_InIs=Cnt.Is_BsB_InIs;
tot_Is_BsF_InIs=Cnt.Is_BsF_InIs;
tot_DInIs_Is=Cnt.DInIs_Is;
tot_InIs_DBsB=Cnt.InIs_DBsB;
tot_InIs_InMsh=Cnt.InIs_InMsh;
tot_InIs_Msh=Cnt.InIs_Msh;
tot_InIs_DBsF=Cnt.InIs_DBsF;
tot_InIs_Is_InIs=Cnt.InIs_Is_InIs;
tot_BsB_InIs_BsB=Cnt.BsB_InIs_BsB;
tot_BsB_InIs_BsF=Cnt.BsB_InIs_BsF;
tot_DBsB_InIs=Cnt.DBsB_InIs;
tot_InMsh_InIs=Cnt.InMsh_InIs;
tot_BsF_InIs_BsB=Cnt.BsF_InIs_BsB;
tot_BsF_InIs_BsF=Cnt.BsF_InIs_BsF;
tot_Msh_InIs=Cnt.Msh_InIs;
tot_DBsF_InIs=Cnt.DBsF_InIs;
tot_Is_DInIs=Cnt.Is_DInIs;
tot_DInIs_BsB=Cnt.DInIs_BsB;
tot_DInIs_BsF=Cnt.DInIs_BsF;
tot_InIs_BsB_InIs=Cnt.InIs_BsB_InIs;
tot_InIs_BsF_InIs=Cnt.InIs_BsF_InIs;
tot_BsB_DInIs=Cnt.BsB_DInIs;
tot_BsF_DInIs=Cnt.BsF_DInIs;
tot_TInIs=Cnt.TInIs;
tot_L_BsB=Cnt.L_BsB;
tot_L_BsF=Cnt.L_BsF;
tot_L_DIs=Cnt.L_DIs;
tot_L_BsF_Is=Cnt.L_BsF_Is;
tot_L_Is_BsB=Cnt.L_Is_BsB;
tot_L_Is_BsF=Cnt.L_Is_BsF;
tot_L_Msh=Cnt.L_Msh;
tot_L_DBsF=Cnt.L_DBsF;
tot_L_Is_InIs=Cnt.L_Is_InIs;
tot_L_BsF_InIs=Cnt.L_BsF_InIs;
tot_L_Tis=Cnt.L_Tis;
tot_L_BsF_DIs=Cnt.L_BsF_DIs;
tot_L_Is_BsB_Is=Cnt.L_Is_BsB_Is;
tot_L_Is_BsF_Is=Cnt.L_Is_BsF_Is;
tot_L_DIs_BsB=Cnt.L_DIs_BsB;
tot_L_DIs_BsF=Cnt.L_DIs_BsF;
tot_L_Msh_Is=Cnt.L_Msh_Is;
tot_L_DBsF_Is=Cnt.L_DBsF_Is;
tot_L_BsF_Is_BsB=Cnt.L_BsF_Is_BsB;
tot_L_BsF_Is_BsF=Cnt.L_BsF_Is_BsF;
tot_L_Is_InIs_Is=Cnt.L_Is_InIs_Is;
tot_L_Is_DBsB=Cnt.L_Is_DBsB;
tot_L_Is_InMsh=Cnt.L_Is_InMsh;
tot_L_Is_Msh=Cnt.L_Is_Msh;
tot_L_Is_DBsF=Cnt.L_Is_DBsF;
tot_L_DIs_Is=Cnt.L_DIs_Is;
tot_L_BsF_InIs_Is=Cnt.L_BsF_InIs_Is;
tot_L_Msh_BsB=Cnt.L_Msh_BsB;
tot_L_Msh_BsF=Cnt.L_Msh_BsF;
tot_L_BsF_Msh=Cnt.L_BsF_Msh;
tot_L_TBsF=Cnt.L_TBsF;
tot_L_BsF_Is_InIs=Cnt.L_BsF_Is_InIs;
tot_L_Is_InIs_BsB=Cnt.L_Is_InIs_BsB;
tot_L_Is_InIs_BsF=Cnt.L_Is_InIs_BsF;
tot_L_Is_BsB_InIs=Cnt.L_Is_BsB_InIs;
tot_L_Is_BsF_InIs=Cnt.L_Is_BsF_InIs;
tot_L_BsF_InIs_BsB=Cnt.L_BsF_InIs_BsB;
tot_L_BsF_InIs_BsF=Cnt.L_BsF_InIs_BsF;
tot_L_Msh_InIs=Cnt.L_Msh_InIs;
tot_L_DBsF_InIs=Cnt.L_DBsF_InIs;
tot_L_Is_DInIs=Cnt.L_Is_DInIs;
tot_L_BsF_DInIs=Cnt.L_BsF_DInIs;
tot_BsF_R=Cnt.BsF_R;
tot_BsB_R=Cnt.BsB_R;
tot_DIs_R=Cnt.DIs_R;
tot_BsB_Is_R=Cnt.BsB_Is_R;
tot_BsF_Is_R=Cnt.BsF_Is_R;
tot_Is_BsB_R=Cnt.Is_BsB_R;
tot_InIs_Is_R=Cnt.InIs_Is_R;
tot_DBsB_R=Cnt.DBsB_R;
tot_Msh_R=Cnt.Msh_R;
tot_InIs_BsB_R=Cnt.InIs_BsB_R;
tot_Tis_R=Cnt.Tis_R;
tot_BsB_DIs_R=Cnt.BsB_DIs_R;
tot_BsF_DIs_R=Cnt.BsF_DIs_R;
tot_Is_BsB_Is_R=Cnt.Is_BsB_Is_R;
tot_Is_BsF_Is_R=Cnt.Is_BsF_Is_R;
tot_DIs_BsB_R=Cnt.DIs_BsB_R;
tot_InIs_DIs_R=Cnt.InIs_DIs_R;
tot_DBsB_Is_R=Cnt.DBsB_Is_R;
tot_InMsh_Is_R=Cnt.InMsh_Is_R;
tot_BsB_Is_BsB_R=Cnt.BsB_Is_BsB_R;
tot_Msh_Is_R=Cnt.Msh_Is_R;
tot_DBsF_Is_R=Cnt.DBsF_Is_R;
tot_BsF_Is_BsB_R=Cnt.BsF_Is_BsB_R;
tot_Is_InIs_Is_R=Cnt.Is_InIs_Is_R;
tot_Is_DBsB_R=Cnt.Is_DBsB_R;
tot_Is_Msh_R=Cnt.Is_Msh_R;
tot_InIs_BsB_Is_R=Cnt.InIs_BsB_Is_R;
tot_InIs_BsF_Is_R=Cnt.InIs_BsF_Is_R;
tot_InIs_Is_BsB_R=Cnt.InIs_Is_BsB_R;
tot_BsB_InIs_Is_R=Cnt.BsB_InIs_Is_R;
tot_TBsB_R=Cnt.TBsB_R;
tot_InMsh_BsB_R=Cnt.InMsh_BsB_R;
tot_BsF_InIs_Is_R=Cnt.BsF_InIs_Is_R;
tot_Msh_BsB_R=Cnt.Msh_BsB_R;
tot_BsF_Msh_R=Cnt.BsF_Msh_R;
tot_Is_InIs_BsB_R=Cnt.Is_InIs_BsB_R;
tot_DInIs_Is_R=Cnt.DInIs_Is_R;
tot_InIs_DBsB_R=Cnt.InIs_DBsB_R;
tot_InIs_Msh_R=Cnt.InIs_Msh_R;
tot_BsB_InIs_BsB_R=Cnt.BsB_InIs_BsB_R;
tot_BsF_InIs_BsB_R=Cnt.BsF_InIs_BsB_R;
tot_DInIs_BsB_R=Cnt.DInIs_BsB_R;
tot_L_Bs_R=Cnt.L_Bs_R;
tot_L_DIs_R=Cnt.L_DIs_R;
tot_L_BsF_Is_R=Cnt.L_BsF_Is_R;
tot_L_Is_BsB_R=Cnt.L_Is_BsB_R;
tot_L_Msh_R=Cnt.L_Msh_R;
tot_L_TIs_R=Cnt.L_TIs_R;
tot_L_BsF_DIs_R=Cnt.L_BsF_DIs_R;
tot_L_Is_BsB_Is_R=Cnt.L_Is_BsB_Is_R;
tot_L_Is_BsF_Is_R=Cnt.L_Is_BsF_Is_R;
tot_L_DIs_BsB_R=Cnt.L_DIs_BsB_R;
tot_L_Msh_Is_R=Cnt.L_Msh_Is_R;
tot_L_DBsF_Is_R=Cnt.L_DBsF_Is_R;
tot_L_BsF_Is_BsB_R=Cnt.L_BsF_Is_BsB_R;
tot_L_Is_InIs_Is_R=Cnt.L_Is_InIs_Is_R;
tot_L_Is_DBsB_R=Cnt.L_Is_DBsB_R;
tot_L_Is_Msh_R=Cnt.L_Is_Msh_R;
tot_L_BsF_InIs_Is_R=Cnt.L_BsF_InIs_Is_R;
tot_L_Msh_BsB_R=Cnt.L_Msh_BsB_R;
tot_L_BsF_Msh_R=Cnt.L_BsF_Msh_R;
tot_L_Is_InIs_BsB_R=Cnt.L_Is_InIs_BsB_R;
tot_L_BsF_InIs_BsB_R=Cnt.L_BsF_InIs_BsB_R;

ppMISA_OR_dataR.total_bistability=[tot_Is tot_BsB tot_BsF tot_InIs ...
    tot_DIs tot_BsB_Is tot_BsF_Is tot_Is_BsB tot_Is_BsF tot_InIs_Is ...
    tot_DBsB tot_InMsh tot_Msh tot_DBsF tot_Is_InIs tot_InIs_BsB ...
    tot_InIs_BsF tot_BsB_InIs tot_BsF_InIs tot_DInIs tot_TIs tot_BsB_DIs ...
    tot_BsF_DIs tot_Is_BsB_Is tot_Is_BsF_Is tot_DIs_BsB tot_DIs_BsF ...
    tot_InIs_DIs tot_DBsB_Is tot_InMsh_Is tot_BsB_Is_BsB tot_BsB_Is_BsF ...
    tot_Msh_Is tot_DBsF_Is tot_BsF_Is_BsB tot_BsF_Is_BsF tot_Is_InIs_Is ...
    tot_Is_DBsB tot_Is_InMsh tot_Is_Msh tot_Is_DBsF tot_DIs_Is ...
    tot_InIs_BsB_Is tot_InIs_BsF_Is tot_InIs_Is_BsB tot_InIs_Is_BsF ...
    tot_BsB_InIs_Is tot_TBsB tot_BsB_InMsh tot_InMsh_BsB tot_InMsh_BsF ...
    tot_BsB_Is_InIs tot_BsF_InIs_Is tot_Msh_BsB tot_Msh_BsF tot_BsF_Msh ...
    tot_TBsF tot_BsF_Is_InIs tot_Is_InIs_BsB tot_Is_InIs_BsF tot_Is_BsB_InIs ...
    tot_Is_BsF_InIs tot_DInIs_Is tot_InIs_DBsB tot_InIs_InMsh tot_InIs_Msh ...
    tot_InIs_DBsF tot_InIs_Is_InIs tot_BsB_InIs_BsB tot_BsB_InIs_BsF ...
    tot_DBsB_InIs tot_InMsh_InIs tot_BsF_InIs_BsB tot_BsF_InIs_BsF tot_Msh_InIs ...
    tot_DBsF_InIs tot_Is_DInIs tot_DInIs_BsB tot_DInIs_BsF tot_InIs_BsB_InIs ...
    tot_InIs_BsF_InIs tot_BsB_DInIs tot_BsF_DInIs tot_TInIs ...
    tot_L_BsB tot_L_BsF tot_L_DIs tot_L_BsF_Is tot_L_Is_BsB tot_L_Is_BsF ...
    tot_L_Msh tot_L_DBsF tot_L_Is_InIs tot_L_BsF_InIs tot_L_Tis tot_L_BsF_DIs ...
    tot_L_Is_BsB_Is tot_L_Is_BsF_Is tot_L_DIs_BsB tot_L_DIs_BsF ...
    tot_L_Msh_Is tot_L_DBsF_Is tot_L_BsF_Is_BsB tot_L_BsF_Is_BsF ...
    tot_L_Is_InIs_Is tot_L_Is_DBsB tot_L_Is_InMsh tot_L_Is_Msh tot_L_Is_DBsF ...
    tot_L_DIs_Is tot_L_BsF_InIs_Is tot_L_Msh_BsB tot_L_Msh_BsF tot_L_BsF_Msh ...
    tot_L_TBsF tot_L_BsF_Is_InIs tot_L_Is_InIs_BsB tot_L_Is_InIs_BsF ...
    tot_L_Is_BsB_InIs tot_L_Is_BsF_InIs tot_L_BsF_InIs_BsB ...
    tot_L_BsF_InIs_BsF tot_L_Msh_InIs tot_L_DBsF_InIs tot_L_Is_DInIs ...
    tot_L_BsF_DInIs tot_BsF_R tot_BsB_R tot_DIs_R tot_BsB_Is_R ...
    tot_BsF_Is_R tot_Is_BsB_R tot_InIs_Is_R tot_DBsB_R tot_Msh_R ...
    tot_InIs_BsB_R tot_Tis_R tot_BsB_DIs_R tot_BsF_DIs_R tot_Is_BsB_Is_R ...
    tot_Is_BsF_Is_R tot_DIs_BsB_R tot_InIs_DIs_R tot_DBsB_Is_R tot_InMsh_Is_R ...
    tot_BsB_Is_BsB_R tot_Msh_Is_R tot_DBsF_Is_R ...
    tot_BsF_Is_BsB_R tot_Is_InIs_Is_R tot_Is_DBsB_R tot_Is_Msh_R ...
    tot_InIs_BsB_Is_R tot_InIs_BsF_Is_R tot_InIs_Is_BsB_R tot_BsB_InIs_Is_R ...
    tot_TBsB_R tot_InMsh_BsB_R tot_BsF_InIs_Is_R tot_Msh_BsB_R ...
    tot_BsF_Msh_R tot_Is_InIs_BsB_R tot_DInIs_Is_R tot_InIs_DBsB_R ...
    tot_InIs_Msh_R tot_BsB_InIs_BsB_R tot_BsF_InIs_BsB_R tot_DInIs_BsB_R ...
    tot_L_Bs_R tot_L_DIs_R tot_L_BsF_Is_R ...
    tot_L_Is_BsB_R tot_L_Msh_R tot_L_TIs_R ...
    tot_L_BsF_DIs_R tot_L_Is_BsB_Is_R tot_L_Is_BsF_Is_R tot_L_DIs_BsB_R ...
    tot_L_Msh_Is_R tot_L_DBsF_Is_R tot_L_BsF_Is_BsB_R tot_L_Is_InIs_Is_R ...
    tot_L_Is_DBsB_R tot_L_Is_Msh_R tot_L_BsF_InIs_Is_R tot_L_Msh_BsB_R ...
    tot_L_BsF_Msh_R tot_L_Is_InIs_BsB_R tot_L_BsF_InIs_BsB_R];