% *************************************************************************
% This function file defines the right hand side of the dynamical equation
% of the variable B after applying the quasi steady state approximation on
% the equation of A in the ppMISA network under OR gate configuration. 
% The right side of the equation defines the effective force in 1D.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [f]=BS_model_bifurcation(S0,b1,param)

ga0=param(1);
gas=param(2);
gab=param(3);
gb0=param(4);
gbs=param(5);
gba=param(6);
gbb=param(7);
Jas=param(8);
Jbs=param(9);
Jab=param(10);
Jba=param(11);
Jbb=param(12);
nas=param(13);
nbs=param(14);
nab=param(15);
nba=param(16);
nbb=param(17);
gma=param(18);
gmb=param(19);

AS1=(S0./Jas).^nas;
AS_int=AS1./(1+AS1);
BS1=(S0./Jbs).^nbs;
BS_int=BS1./(1+BS1);
AB1=(b1./Jab).^nab;
AB_int=1-AB1./(1+AB1);
Ass=(ga0+gas.*AS_int+gab.*AB_int)./gma;
BA1=(Ass./Jba).^nba;
BA_int=1-BA1./(1+BA1);
BB1=(b1./Jbb).^nbb;
BB_int=BB1./(1+BB1);

% force term in the euqation of B
f = gb0+gbs.*BS_int+gba.*BA_int+gbb.*BB_int-gmb.*b1;