% *************************************************************************
% This function calculates the number and locations of jumps of the steady 
% state at the bifurcation points. 
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [sum_diffss2,bfrSN,jmpN,jmpLocSN]=BS_jumpSS_SN(peaks_ss,vss,vuss)

% *************************************************************************
% Determination of jump numbers and jump locations in the bifurcation
% diagram
% *************************************************************************
% indirect determination of number of regions od bistability
% sum_diffss2=2 for each bistable region
% switches with single BS region: sum_diffss2=2
% switches with double BS region: sum_diffss2=4
% switches with tripple BS region: sum_diffss2=6
srt2=peaks_ss(cumsum(peaks_ss,2) > 0);
flipd2=flip(srt2);
rm_zero1=flipd2(cumsum(flipd2,2) > 0);
rm_zero2=flip(rm_zero1);
diff_ss2=diff(rm_zero2);
sum_diffss2=sum(abs(diff_ss2));

xpeak1=diff(vss(:,2));
%         figure(6)
%         plot(abs(xpeak1));
%         hold on
% The fluctuations in the difference (xpeak2) are removed in the BS regions
i1=0;
for i1=1:length(xpeak1)
    i2=i1+1;
    if vuss(i2,2)>0 && vuss(i2-1,2)>0
        xpeak1(i1)=0;
    end
end
%         figure(6)
%         plot(abs(xpeak1));

xpeak1(abs(xpeak1)<=4)=0;   % small jumps <=4 are removed
xpeak=xpeak1;
%         figure(6)
%         plot(abs(xpeak));

%         [Grd2mx Loc_grd2mx]=findpeaks(abs(xpeak));
[Grd2mx Loc_grd2mx]=findpeaks(xpeak);
[Grd2mn Loc_grd2mn]=findpeaks(-xpeak);
Grd2mx1=Grd2mx(Grd2mx~=0);
Grd2mn1=Grd2mn(Grd2mn~=0);
Loc_grd2mx1=Loc_grd2mx(Grd2mx~=0)+1;    % 1 is added to correct the location
Loc_grd2mn1=Loc_grd2mn(Grd2mn~=0)+1;    % 1 is added to correct the location
%         Grd2mn1=[];
%         Loc_grd2mn1=[];

i2=0;
mxDf=[];
locmx=[];
for i1=1:length(Loc_grd2mx1)
    if vuss(Loc_grd2mx1(i1)-1,2)>0
        i2=i2+1;
        mxDf(i2)=Grd2mx1(i1);
        locmx(i2)=Loc_grd2mx1(i1);
    end
end

i2=0;
mnDf=[];
locmn=[];
for i1=1:length(Loc_grd2mn1)
    if vuss(Loc_grd2mn1(i1),2)>0
        i2=i2+1;
        mnDf(i2)=Grd2mn1(i1);
        locmn(i2)=Loc_grd2mn1(i1);
    end
end

LoC=sort([locmx locmn])';               % location of jumps at the SN point
MxMn=[mxDf mnDf];
jmpN=length(LoC);                       % number of jumps

%**************************************************************************
% Finding SN points from the unstable branch
%**************************************************************************

nonNanUS=(~isnan(vuss(:,2)));
% bfrPt=find(diff(sign(nonNanUS)))+1;       % SN points from the unstable branch
bfrPt=find(diff(nonNanUS))+1;               % for 2015 verson of Matlab
chgSS=vss(bfrPt,2)-vss(bfrPt-1,2);
bfrSN=[bfrPt chgSS];                         % Bifurcation points
% jmp=bfrSN(abs(bfrSN(:,2))>=4,2);
% bfr=bfrSN(abs(bfrSN(:,2))>=4,1);
jmpLocSN=find(ismember(bfrSN(:,1),LoC));     % location of jump based on the ordering of SN points
jmpSN=bfrSN(jmpLocSN,2);                     % Direction of jump
%**************************************************************************