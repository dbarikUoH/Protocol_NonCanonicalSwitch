% *************************************************************************
% Potential energy based bifurcation analysis of feedback refulated systems
% and determination of types of reversible bistable switches
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************

% *************************************************************************
% Model: ppMISA network
% Logic Gate: OR
% *************************************************************************

clear
clc
tic

% *************************************************************************
% Numerical parameters for bifurcation calculations 
% *************************************************************************
sig_max=1000;           % Maximum value of bifurcation parameter (S)
dsig=0.1;               % step length of the bifurcation parameter
xE=10000;               % Maximum value of the dynamical variable (B)
dx2=1;                  % step length of the dynamical variable
b1=[0:dx2:xE];      
sig2=[0:dsig:sig_max];
% *************************************************************************

potE=ones(length(sig2),length(b1))*NaN;  % to store pseudo-potential energy

% *************************************************************************
% Model parameter values
% *************************************************************************
load parameter_Isola.mat            % Isola 
% load parameter_InvIsola.mat         % Inverted Isola
% load parameter_Mushroom.mat         % Mushroom
% load parameter_InvMushroom.mat      % Inverted Mushroom      

% *************************************************************************

% *************************************************************************
% Finding no. of stable and unstable steady states with variation of
% bifurcation parameter. Stable and unstable steady states are obtained
% from the minima and maxima in the potential energy function (PEF)
% *************************************************************************

peaks_ss=ones(1,length(sig2))*NaN;
peaks_us=ones(1,length(sig2))*NaN;
vss=ones(length(sig2),4)*NaN;
vuss=ones(length(sig2),4)*NaN;

% *************************************************************************
 % Loop for bifurcation parameter
% *************************************************************************
for j=1:length(sig2)     
    
    S0=sig2(j);

    [f]=BS_model_bifurcation(S0,b1,param);
    pot=dx2*cumtrapz(-f);               % pesudo potential energy V(S,B)
    z11=pot-min(pot);                   % scaling of energy minimum to 0
    z22=-z11;
    
    potE(j,:)=pot;
    
    peaks_ss(j)=numel(findpeaks(z22));      % no. of minima in PEF
    peaks_us(j)=numel(findpeaks(z11));      % no. of maxima in PEF
    
    % pks_stb: no. of stable steady states
    [pks_stb locs_stb] = findpeaks(z22);
    
    % storing of stable branches
    if length(locs_stb)==3
        vss(j,1)=S0;
        vss(j,2)=b1(locs_stb(1));
        vss(j,3)=b1(locs_stb(2));
        vss(j,4)=b1(locs_stb(3));
    elseif length(locs_stb)==2
        vss(j,1)=S0;
        vss(j,2)=b1(locs_stb(1));
        vss(j,3)=b1(locs_stb(2));
        vss(j,4)=NaN;
    elseif length(locs_stb)==1
        vss(j,1)=S0;
        vss(j,2)=b1(locs_stb(1));
        vss(j,3)=NaN;
        vss(j,4)=NaN;
    end
    
    % pks_stb: no. of unstable steady states
    [pks_us locs_us] = findpeaks(z11);
    
    % storing of unstable branches
    if length(locs_us)==2
        vuss(j,1)=S0;
        vuss(j,2)=b1(locs_us(1));
        vuss(j,3)=b1(locs_us(2));
        vuss(j,4)=NaN;
    elseif length(locs_us)==1
        vuss(j,1)=S0;
        vuss(j,2)=b1(locs_us(1));
        vuss(j,3)=NaN;
        vuss(j,4)=NaN;
    elseif length(locs_us)==0
        vuss(j,1)=S0;
        vuss(j,2)=NaN;
        vuss(j,3)=NaN;
        vuss(j,4)=NaN;
    end
end
% *************************************************************************

% *************************************************************************
% Determination of jump numbers and locations in the bifurcation diagram
% *************************************************************************
[sum_diffss2,bfrSN,jmpN,jmpLocSN]=BS_jumpSS_SN(peaks_ss,vss,vuss);
% *************************************************************************

% *************************************************************************
% Identification of bistable switches based on the number of SN points
% and jump patterns of the stable branch at the SN points
% *************************************************************************
BS_switchType_189BS(peaks_ss,sum_diffss2,jmpN,jmpLocSN)
% *************************************************************************

% *************************************************************************
% plot of bifurcation the diagram
% *************************************************************************
figure(1)
plot_bifurcation(bfrSN,vss,vuss)
set(gca,'Box','on')
xlabel('S')
ylabel('B')
% *************************************************************************

% *************************************************************************
% plot of bifurcation the diagram and energy contours
% *************************************************************************
% figure(2)
% En=potE-min(min(potE));   % global minimum of energy is scaled to zero
% Enlog=log(En);            % log of energy                  
% plot_bifurcation(bfrSN,vss,vuss)
% hold on
% contour(sig2,b1,Enlog','LevelStep',0.5)
% set(gca,'Box','on')
% xlabel('S')
% ylabel('B')
% *************************************************************************

toc

% quit
