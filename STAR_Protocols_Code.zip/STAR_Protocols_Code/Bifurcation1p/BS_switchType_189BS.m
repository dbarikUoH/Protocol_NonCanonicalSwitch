% *************************************************************************
% This function determines the type of bistable switches
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function BS_switchType_189BS(peaks_ss,sum_diffss2,jmpN,jmpLocSN)

if(peaks_ss(1)>1 && peaks_ss(end)>1)          % irreversible switch on Left & right
    if (sum_diffss2==0)
        disp('L-Bs-R')
    elseif (sum_diffss2==2)
        if jmpN==0
            disp('L-DIs-R')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-Is-R')
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-R')
            end
        elseif jmpN==2
            disp('L-Msh-R')
        end
    elseif (sum_diffss2==4)
        if jmpN==0
            disp('L-TIs-R')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-DIs-R')
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-Is-R')
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF-Is-R')
            elseif jmpLocSN(1)==4
                disp('L-DIs-BsB-R')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('L-BsF-Is-BsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs-Is-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('L-Is-DBsB-R')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('L-Is-Msh-R')
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('L-BsF-InIs-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('L-Msh-BsB-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-BsF-Msh-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-Is-InIs-BsB-R')
            end
        elseif jmpN==4
            disp('L-BsF-InIs-BsB-R')
        end
    end
end
if(peaks_ss(1)>1)          % irreversible switch on Left
    if (sum_diffss2==1)
        if jmpN==0
            disp('L-BsB')
        elseif jmpN==1
            disp('L-BsF')
        end
    elseif (sum_diffss2==3)
        if jmpN==0
            disp('L-DIs')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-Is')
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB')
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs')
            end
        elseif jmpN==3
            disp('L-BsF-InIs')
        end
    elseif (sum_diffss2==5)
        if jmpN==0
            disp('L-Tis')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-DIs')
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-Is')
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF-Is')
            elseif jmpLocSN(1)==4
                disp('L-DIs-BsB')
            elseif jmpLocSN(1)==5
                disp('L-DIs-BsF')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('L-BsF-Is-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('L-BsF-Is-BsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs-Is')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('L-Is-DBsB')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('L-Is-InMsh')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('L-Is-Msh')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('L-Is-DBsF')
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('L-DIs-Is')
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('L-BsF-InIs-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('L-Msh-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('L-Msh-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-BsF-Msh')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('L-TBsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-BsF-Is-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-Is-InIs-BsB')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('L-Is-InIs-BsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-Is-BsB-InIs')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-Is-BsF-InIs')
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4
                disp('L-BsF-InIs-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5
                disp('L-BsF-InIs-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-Msh-InIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-DBsF-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-Is-DInIs')
            end
        elseif jmpN==5
            disp('L-BsF-DInIs')
        end
    end
elseif (peaks_ss(end)>1)   % irreversible switch on Right
    if (sum_diffss2==1)
        if jmpN==0
            disp('BsF-R')
        elseif jmpN==1
            disp('BsB-R')
        end
    elseif (sum_diffss2==3)
        if jmpN==0
            disp('DIs-R')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-Is-R')
            elseif jmpLocSN(1)==2
                disp('BsF-Is-R')
            elseif jmpLocSN(1)==3
                disp('Is-BsB-R')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-R')
            end
        elseif jmpN==3
            disp('InIs-BsB-R')
        end
    elseif (sum_diffss2==5)
        if jmpN==0
            disp('Tis-R')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-DIs-R')
            elseif jmpLocSN(1)==2
                disp('BsF-DIs-R')
            elseif jmpLocSN(1)==3
                disp('Is-BsB-Is-R')
            elseif jmpLocSN(1)==4
                disp('Is-BsF-Is-R')
            elseif jmpLocSN(1)==5
                disp('DIs-BsB-R')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-DIs-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('BsB-Is-BsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-Is-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF-Is-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('BsF-Is-BsB-R')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs-Is-R')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('Is-DBsB-R')
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('Is-Msh-R')
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('InIs-Is-BsB-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('TBsB-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('InMsh-BsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs-Is-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('Msh-BsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('BsF-Msh-R')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('Is-InIs-BsB-R')
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(3)==4
                disp('DInIs-Is-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(3)==5
                disp('InIs-DBsB-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('InIs-Msh-R')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('BsB-InIs-BsB-R')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('BsF-InIs-BsB-R')
            end
        elseif jmpN==5
            disp('DInIs-BsB-R')
        end
    end
else
    if (max(peaks_ss)==2 && (sum_diffss2==2)) % Reversible bisatble switches
        if jmpN==0
            disp('Is')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB')
            elseif jmpLocSN(1)==2
                disp('BsF')
            end
        elseif jmpN==2
            disp('InIs')
        end
    elseif (max(peaks_ss)==2 && (sum_diffss2==4))
        if jmpN==0
            disp('DIs')
        elseif jmpN==1
            if jmpLocSN==1
                disp('BsB-Is')
            elseif jmpLocSN==2
                disp('BsF-Is')
            elseif jmpLocSN==3
                disp('Is-BsB')
            elseif jmpLocSN==4
                disp('Is-BsF')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs')
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs')
            end
        elseif jmpN==4
            disp('DInIs')
        end
    elseif (max(peaks_ss)==2 && (sum_diffss2==6))
        if jmpN==0
            disp('TIs')
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-DIs')
            elseif jmpLocSN(1)==2
                disp('BsF-DIs')
            elseif jmpLocSN(1)==3
                disp('Is-BsB-Is')
            elseif jmpLocSN(1)==4
                disp('Is-BsF-Is')
            elseif jmpLocSN(1)==5
                disp('DIs-BsB')
            elseif jmpLocSN(1)==6
                disp('DIs-BsF')
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-DIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('BsB-Is-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==6
                disp('BsB-Is-BsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-Is')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF-Is')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('BsF-Is-BsB')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==6
                disp('BsF-Is-BsF')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs-Is')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('Is-DBsB')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==6
                disp('Is-InMsh')
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('Is-Msh')
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==6
                disp('Is-DBsF')
            elseif jmpLocSN(1)==5 && jmpLocSN(2)==6
                disp('DIs-Is')
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('InIs-Is-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==6
                disp('InIs-Is-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('TBsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==6
                disp('BsB-InMsh')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('InMsh-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('InMsh-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('BsB-Is-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs-Is')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('Msh-BsB')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==6
                disp('Msh-BsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('BsF-Msh')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('TBsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('BsF-Is-InIs')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('Is-InIs-BsB')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('Is-InIs-BsF')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('Is-BsB-InIs')
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('Is-BsF-InIs')
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4
                disp('DInIs-Is')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5
                disp('InIs-DBsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==6
                disp('InIs-InMsh')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('InIs-Msh')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('InIs-DBsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('InIs-Is-InIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('BsB-InIs-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('BsB-InIs-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('DBsB-InIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('InMsh-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('BsF-InIs-BsB')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('BsF-InIs-BsF')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('Msh-InIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('DBsF-InIs')
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('Is-DInIs')
            end
        elseif jmpN==5
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4 && jmpLocSN(5)==5
                disp('DInIs-BsB')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4 && jmpLocSN(5)==6
                disp('DInIs-BsF')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('InIs-BsB-InIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('InIs-BsF-InIs')
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('BsB-DInIs')
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('BsF-DInIs')
            end
        elseif jmpN==6
            disp('TInIs')
        end
    end
end