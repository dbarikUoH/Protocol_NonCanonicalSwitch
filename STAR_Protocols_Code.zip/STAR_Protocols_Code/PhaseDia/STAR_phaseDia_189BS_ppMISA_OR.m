% *************************************************************************
% Bifurcation analysis of feedback refulated systems using potential
% energy function (PEF) calculation.
% *************************************************************************
% *************************************************************************
% Phase diagrams of canonical and noncanonical bistable switches
% *************************************************************************
% *************************************************************************
% Date: July 04, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************

% *************************************************************************
% Model: ppMISA_OR
% Logic Gate: OR
% *************************************************************************

clear
clc
tic

% *************************************************************************
% Initial counts of the counts of reversible and irreversible switches
% *************************************************************************
Cnt.Is=0;               % Switch: Is                            Sr. No.: 1
Cnt.BsB=0;              % Switch: BsB                           Sr. No.: 2
Cnt.BsF=0;              % Switch: BsF                           Sr. No.: 3
Cnt.InIs=0;             % Switch: InIs                          Sr. No.: 4
Cnt.DIs=0;              % Switch: DIs                           Sr. No.: 5
Cnt.BsB_Is=0;           % Switch: BsB-Is                        Sr. No.: 6
Cnt.BsF_Is=0;           % Switch: BsF-Is                        Sr. No.: 7
Cnt.Is_BsB=0;           % Switch: Is-BsB                        Sr. No.: 8
Cnt.Is_BsF=0;           % Switch: Is-BsF                        Sr. No.: 9
Cnt.InIs_Is=0;          % Switch: InIs-Is                       Sr. No.: 10
Cnt.DBsB=0;             % Switch: DBsB                          Sr. No.: 11
Cnt.InMsh=0;            % Switch: InMsh                         Sr. No.: 12
Cnt.Msh=0;              % Switch: Msh                           Sr. No.: 13
Cnt.DBsF=0;             % Switch: DBsF                          Sr. No.: 14
Cnt.Is_InIs=0;          % Switch: Is-InIs                       Sr. No.: 15
Cnt.InIs_BsB=0;         % Switch: InIs-BsB                      Sr. No.: 16
Cnt.InIs_BsF=0;         % Switch: InIs-BsF                      Sr. No.: 17
Cnt.BsB_InIs=0;         % Switch: BsB-InIs                      Sr. No.: 18
Cnt.BsF_InIs=0;         % Switch: BsF-InIs                      Sr. No.: 19
Cnt.DInIs=0;            % Switch: DInIs                         Sr. No.: 20
Cnt.TIs=0;              % Switch: TIs                           Sr. No.: 21
Cnt.BsB_DIs=0;          % Switch: BsB-DIs                       Sr. No.: 22
Cnt.BsF_DIs=0;          % Switch: BsF-DIs                       Sr. No.: 23
Cnt.Is_BsB_Is=0;        % Switch: Is-BsB-Is                     Sr. No.: 24
Cnt.Is_BsF_Is=0;        % Switch: Is-BsF-Is                     Sr. No.: 25
Cnt.DIs_BsB=0;          % Switch: DIs-BsB                       Sr. No.: 26
Cnt.DIs_BsF=0;          % Switch: DIs-BsF                       Sr. No.: 27
Cnt.InIs_DIs=0;         % Switch: InIs_DIs                      Sr. No.: 28
Cnt.DBsB_Is=0;          % Switch: DBsB-Is                       Sr. No.: 29
Cnt.InMsh_Is=0;         % Switch: InMsh-Is                      Sr. No.: 30
Cnt.BsB_Is_BsB=0;       % Switch: BsB-Is-BsB                    Sr. No.: 31
Cnt.BsB_Is_BsF=0;       % Switch: BsB-Is-BsF                    Sr. No.: 32
Cnt.Msh_Is=0;           % Switch: Msh-Is                        Sr. No.: 33
Cnt.DBsF_Is=0;          % Switch: DBsF-Is                       Sr. No.: 34    
Cnt.BsF_Is_BsB=0;       % Switch: BsF-Is-BsB                    Sr. No.: 35
Cnt.BsF_Is_BsF=0;       % Switch: BsF-Is-BsF                    Sr. No.: 36
Cnt.Is_InIs_Is=0;       % Switch: Is_InIs_Is                    Sr. No.: 37 
Cnt.Is_DBsB=0;          % Switch: Is-DBsB                       Sr. No.: 38
Cnt.Is_InMsh=0;         % Switch: Is-InMsh                      Sr. No.: 39    
Cnt.Is_Msh=0;           % Switch: Is-Msh                        Sr. No.: 40
Cnt.Is_DBsF=0;          % Switch: Is-DBsF                       Sr. No.: 41
Cnt.DIs_Is=0;           % Switch: DIs_Is                        Sr. No.: 42    
Cnt.InIs_BsB_Is=0;      % Switch: InIs_BsB_Is                   Sr. No.: 43
Cnt.InIs_BsF_Is=0;      % Switch: InIs_BsF_Is                   Sr. No.: 44
Cnt.InIs_Is_BsB=0;      % Switch: InIs_Is_BsB                   Sr. No.: 45
Cnt.InIs_Is_BsF=0;      % Switch: InIs_Is_BsF                   Sr. No.: 46
Cnt.BsB_InIs_Is=0;      % Switch: BsB_InIs_Is                   Sr. No.: 47
Cnt.TBsB=0;             % Switch: TBsB                          Sr. No.: 48
Cnt.BsB_InMsh=0;        % Switch: BsB-InMsh                     Sr. No.: 49
Cnt.InMsh_BsB=0;        % Switch: InMsh_BsB                     Sr. No.: 50
Cnt.InMsh_BsF=0;        % Switch: InMsh_BsF                     Sr. No.: 51
Cnt.BsB_Is_InIs=0;      % Switch: BsB_Is_InIs                   Sr. No.: 52
Cnt.BsF_InIs_Is=0;      % Switch: BsF_InIs_Is                   Sr. No.: 53
Cnt.Msh_BsB=0;          % Switch: Msh-BsB                       Sr. No.: 54
Cnt.Msh_BsF=0;          % Switch: Msh-BsF                       Sr. No.: 55
Cnt.BsF_Msh=0;          % Switch: BsF_Msh                       Sr. No.: 56
Cnt.TBsF=0;             % Switch: TBsF                          Sr. No.: 57
Cnt.BsF_Is_InIs=0;      % Switch: BsF_Is_InIs                   Sr. No.: 58
Cnt.Is_InIs_BsB=0;      % Switch: Is_InIs_BsB                   Sr. No.: 59
Cnt.Is_InIs_BsF=0;      % Switch: Is_InIs_BsF                   Sr. No.: 60
Cnt.Is_BsB_InIs=0;      % Switch: Is_BsB_InIs                   Sr. No.: 61
Cnt.Is_BsF_InIs=0;      % Switch: Is_BsF_InIs                   Sr. No.: 62
Cnt.DInIs_Is=0;         % Switch: DInIs_Is                      Sr. No.: 63
Cnt.InIs_DBsB=0;        % Switch: InIs-DBsB                     Sr. No.: 64    
Cnt.InIs_InMsh=0;       % Switch: InIs-InMsh                    Sr. No.: 65    
Cnt.InIs_Msh=0;         % Switch: InIs-Msh                      Sr. No.: 66
Cnt.InIs_DBsF=0;        % Switch: InIs-DBsF                     Sr. No.: 67    
Cnt.InIs_Is_InIs=0;     % Switch: InIs_Is_InIs                  Sr. No.: 68
Cnt.BsB_InIs_BsB=0;     % Switch: BsB-InIs-BsB                  Sr. No.: 69
Cnt.BsB_InIs_BsF=0;     % Switch: BsB-InIs-BsF                  Sr. No.: 70
Cnt.DBsB_InIs=0;        % Switch: DBsB-InIs                     Sr. No.: 71    
Cnt.InMsh_InIs=0;       % Switch: InMsh-InIs                    Sr. No.: 72
Cnt.BsF_InIs_BsB=0;     % Switch: BsF-InIs-BsB                  Sr. No.: 73
Cnt.BsF_InIs_BsF=0;     % Switch: BsF-InIs-BsF                  Sr. No.: 74
Cnt.Msh_InIs=0;         % Switch: Msh-InIs                      Sr. No.: 75
Cnt.DBsF_InIs=0;        % Switch: DBsF-InIs                     Sr. No.: 76
Cnt.Is_DInIs=0;         % Switch: Is_DInIs                      Sr. No.: 77
Cnt.DInIs_BsB=0;        % Switch: DInIs_BsB                     Sr. No.: 78
Cnt.DInIs_BsF=0;        % Switch: DInIs_BsF                     Sr. No.: 79
Cnt.InIs_BsB_InIs=0;    % Switch: InIs_BsB_InIs                 Sr. No.: 80
Cnt.InIs_BsF_InIs=0;    % Switch: InIs_BsF_InIs                 Sr. No.: 81
Cnt.BsB_DInIs=0;        % Switch: BsB_DInIs                     Sr. No.: 82
Cnt.BsF_DInIs=0;        % Switch: BsF_DInIs                     Sr. No.: 83
Cnt.TInIs=0;            % Switch: TInIs                         Sr. No.: 84
Cnt.L_BsB=0;            % Switch: L-BsB                         Sr. No.: 85
Cnt.L_BsF=0;            % Switch: L-BsF                         Sr. No.: 86
Cnt.L_DIs=0;            % Switch: L-DIs                         Sr. No.: 87
Cnt.L_BsF_Is=0;         % Switch: L-BsF-Is                      Sr. No.: 88
Cnt.L_Is_BsB=0;         % Switch: L_Is_BsB                      Sr. No.: 89
Cnt.L_Is_BsF=0;         % Switch: L_Is_BsF                      Sr. No.: 90
Cnt.L_Msh=0;            % Switch: L-Msh                         Sr. No.: 91
Cnt.L_DBsF=0;           % Switch: L-DBsF                        Sr. No.: 92
Cnt.L_Is_InIs=0;        % Switch: L_Is_InIs                     Sr. No.: 93
Cnt.L_BsF_InIs=0;       % Switch: L_BsF_InIs                    Sr. No.: 94
Cnt.L_Tis=0;            % Switch: L_Tis                         Sr. No.: 95
Cnt.L_BsF_DIs=0;        % Switch: L-BsF-DIs                     Sr. No.: 96
Cnt.L_Is_BsB_Is=0;      % Switch: L_Is_BsB_Is                   Sr. No.: 97
Cnt.L_Is_BsF_Is=0;      % Switch: L_Is_BsF_Is                   Sr. No.: 98
Cnt.L_DIs_BsB=0;        % Switch: L_DIs_BsB                     Sr. No.: 99
Cnt.L_DIs_BsF=0;        % Switch: L-DIs-BsF                     Sr. No.: 100
Cnt.L_Msh_Is=0;         % Switch: L-Msh-Is                      Sr. No.: 101
Cnt.L_DBsF_Is=0;        % Switch: L-DBsF-Is                     Sr. No.: 102
Cnt.L_BsF_Is_BsB=0;     % Switch: L-BsF-Is-BsB                  Sr. No.: 103
Cnt.L_BsF_Is_BsF=0;     % Switch: L-BsF-Is-BsF                  Sr. No.: 104
Cnt.L_Is_InIs_Is=0;     % Switch: L_Is_InIs_Is                  Sr. No.: 105
Cnt.L_Is_DBsB=0;        % Switch: L_Is_DBsB                     Sr. No.: 106
Cnt.L_Is_InMsh=0;       % Switch: L-Is-InMsh                    Sr. No.: 107
Cnt.L_Is_Msh=0;         % Switch: L-Is-Msh                      Sr. No.: 108
Cnt.L_Is_DBsF=0;        % Switch: L_Is_DBsF                     Sr. No.: 109
Cnt.L_DIs_Is=0;         % Switch: L_DIs_Is                      Sr. No.: 110
Cnt.L_BsF_InIs_Is=0;    % Switch: L_BsF_InIs_Is                 Sr. No.: 111
Cnt.L_Msh_BsB=0;        % Switch: L_Msh_BsB                     Sr. No.: 112
Cnt.L_Msh_BsF=0;        % Switch: L_Msh_BsF                     Sr. No.: 113
Cnt.L_BsF_Msh=0;        % Switch: L_BsF_Msh                     Sr. No.: 114
Cnt.L_TBsF=0;           % Switch: L_TBsF                        Sr. No.: 115
Cnt.L_BsF_Is_InIs=0;    % Switch: L_BsF_Is_InIs                 Sr. No.: 116
Cnt.L_Is_InIs_BsB=0;    % Switch: L_Is_InIs_BsB                 Sr. No.: 117
Cnt.L_Is_InIs_BsF=0;    % Switch: L_Is_InIs_BsF                 Sr. No.: 118
Cnt.L_Is_BsB_InIs=0;    % Switch: L_Is_BsB_InIs                 Sr. No.: 119
Cnt.L_Is_BsF_InIs=0;    % Switch: L_Is_BsF_InIs                 Sr. No.: 120
Cnt.L_BsF_InIs_BsB=0;   % Switch: L_BsF_InIs_BsB                Sr. No.: 121
Cnt.L_BsF_InIs_BsF=0;   % Switch: L_BsF_InIs_BsF                Sr. No.: 122
Cnt.L_Msh_InIs=0;       % Switch: L_Msh_InIs                    Sr. No.: 123
Cnt.L_DBsF_InIs=0;      % Switch: L_DBsF_InIs                   Sr. No.: 124
Cnt.L_Is_DInIs=0;       % Switch: L_Is_DInIs                    Sr. No.: 125
Cnt.L_BsF_DInIs=0;      % Switch: L_BsF_DInIs                   Sr. No.: 126
Cnt.BsF_R=0;            % Switch: BsF-R                         Sr. No.: 127
Cnt.BsB_R=0;            % Switch: BsB-R                         Sr. No.: 128
Cnt.DIs_R=0;            % Switch: DIs_R                         Sr. No.: 129
Cnt.BsB_Is_R=0;         % Switch: BsB_Is_R                      Sr. No.: 130
Cnt.BsF_Is_R=0;         % Switch: BsF_Is_R                      Sr. No.: 131
Cnt.Is_BsB_R=0;         % Switch: Is-BsB-R                      Sr. No.: 132
Cnt.InIs_Is_R=0;        % Switch: InIs-BsF-R                    Sr. No.: 133
Cnt.DBsB_R=0;           % Switch: DBsB-R                        Sr. No.: 134
Cnt.Msh_R=0;            % Switch: Msh-R                         Sr. No.: 135
Cnt.InIs_BsB_R=0;       % Switch: InIs_BsB_R                    Sr. No.: 136
Cnt.Tis_R=0;            % Switch: Tis_R                         Sr. No.: 137
Cnt.BsB_DIs_R=0;        % Switch: BsB-DIs-R                     Sr. No.: 138
Cnt.BsF_DIs_R=0;        % Switch: BsF_DIs_R                     Sr. No.: 139
Cnt.Is_BsB_Is_R=0;      % Switch: Is-BsB-Is-R                   Sr. No.: 140
Cnt.Is_BsF_Is_R=0;      % Switch: Is_BsF_Is_R                   Sr. No.: 141
Cnt.DIs_BsB_R=0;        % Switch: DIs-BsB-R                     Sr. No.: 142
Cnt.InIs_DIs_R=0;       % Switch: InIs_DIs_R                    Sr. No.: 143
Cnt.DBsB_Is_R=0;        % Switch: DBsB-Is-R                     Sr. No.: 144
Cnt.InMsh_Is_R=0;       % Switch: InMsh-Is-R                    Sr. No.: 145
Cnt.BsB_Is_BsB_R=0;     % Switch: BsB-Is-BsB-R                  Sr. No.: 146
Cnt.Msh_Is_R=0;         % Switch: Msh-Is-R                      Sr. No.: 147
Cnt.DBsF_Is_R=0;        % Switch: DBsF_Is_R                     Sr. No.: 148
Cnt.BsF_Is_BsB_R=0;     % Switch: BsF-Is-BsB-R                  Sr. No.: 149
Cnt.Is_InIs_Is_R=0;     % Switch: Is_InIs_Is_R                  Sr. No.: 150
Cnt.Is_DBsB_R=0;        % Switch: Is-DBsB-R                     Sr. No.: 151
Cnt.Is_Msh_R=0;         % Switch: Is-Msh-R                      Sr. No.: 152
Cnt.InIs_BsB_Is_R=0;    % Switch: InIs_BsB_Is_R                 Sr. No.: 153
Cnt.InIs_BsF_Is_R=0;    % Switch: InIs_BsF_Is_R                 Sr. No.: 154
Cnt.InIs_Is_BsB_R=0;    % Switch: InIs_Is_BsB_R                 Sr. No.: 155
Cnt.BsB_InIs_Is_R=0;    % Switch: BsB_InIs_Is_R                 Sr. No.: 156
Cnt.TBsB_R=0;           % Switch: TBsB_R                        Sr. No.: 157
Cnt.InMsh_BsB_R=0;      % Switch: InMsh_BsB_R                   Sr. No.: 158
Cnt.BsF_InIs_Is_R=0;    % Switch: BsF_InIs_Is_R                 Sr. No.: 159
Cnt.Msh_BsB_R=0;        % Switch: Msh_BsB_R                     Sr. No.: 160
Cnt.BsF_Msh_R=0;        % Switch: BsF_Msh_R                     Sr. No.: 161
Cnt.Is_InIs_BsB_R=0;    % Switch: Is_InIs_BsB_R                 Sr. No.: 162
Cnt.DInIs_Is_R=0;       % Switch: DInIs_Is_R                    Sr. No.: 163
Cnt.InIs_DBsB_R=0;      % Switch: InIs_DBsB_R                   Sr. No.: 164
Cnt.InIs_Msh_R=0;       % Switch: InIs_Msh_R                    Sr. No.: 165
Cnt.BsB_InIs_BsB_R=0;   % Switch: BsB_InIs_BsB_R                Sr. No.: 166
Cnt.BsF_InIs_BsB_R=0;   % Switch: BsF_InIs_BsB_R                Sr. No.: 167
Cnt.DInIs_BsB_R=0;      % Switch: DInIs_BsB_R                   Sr. No.: 168
Cnt.L_Bs_R=0;           % Switch: L-Bs-R                        Sr. No.: 169
Cnt.L_DIs_R=0;          % Switch: L_DIs_R                       Sr. No.: 170
Cnt.L_BsF_Is_R=0;       % Switch: L_BsF_Is_R                    Sr. No.: 171
Cnt.L_Is_BsB_R=0;       % Switch: L_Is_BsB_R                    Sr. No.: 172
Cnt.L_Msh_R=0;          % Switch: L_Msh_R                       Sr. No.: 173
Cnt.L_TIs_R=0;          % Switch: L_TIs_R                       Sr. No.: 174
Cnt.L_BsF_DIs_R=0;      % Switch: L_BsF_DIs_R                   Sr. No.: 175
Cnt.L_Is_BsB_Is_R=0;    % Switch: L_Is_BsB_Is_R                 Sr. No.: 176
Cnt.L_Is_BsF_Is_R=0;    % Switch: L_Is_BsF_Is_R                 Sr. No.: 177
Cnt.L_DIs_BsB_R=0;      % Switch: L_DIs_BsB_R                   Sr. No.: 178
Cnt.L_Msh_Is_R=0;       % Switch: L-Msh-Is-R                    Sr. No.: 179
Cnt.L_DBsF_Is_R=0;      % Switch: L_DBsF_Is_R                   Sr. No.: 180
Cnt.L_BsF_Is_BsB_R=0;   % Switch: L_BsF_Is_BsB_R                Sr. No.: 181
Cnt.L_Is_InIs_Is_R=0;   % Switch: L_Is_InIs_Is_R                Sr. No.: 182
Cnt.L_Is_DBsB_R=0;      % Switch: L_Is_DBsB_R                   Sr. No.: 183
Cnt.L_Is_Msh_R=0;       % Switch: L_Is_Msh_R                    Sr. No.: 184
Cnt.L_BsF_InIs_Is_R=0;  % Switch: L_BsF_InIs_Is_R               Sr. No.: 185
Cnt.L_Msh_BsB_R=0;      % Switch: L_Msh_BsB_R                   Sr. No.: 186
Cnt.L_BsF_Msh_R=0;      % Switch: L_BsF_Msh_R                   Sr. No.: 187
Cnt.L_Is_InIs_BsB_R=0;  % Switch: L_Is_InIs_BsB_R               Sr. No.: 188
Cnt.L_BsF_InIs_BsB_R=0; % Switch: L-BsF-InIs-BsB-R              Sr. No.: 189
% *************************************************************************

% *************************************************************************
% Parameter for the initial phase (bistable switch)
% *************************************************************************
load parameter_phaseDia.mat    % loading the parameter for the inital phase
% *************************************************************************

% *************************************************************************
% Parameter for the 2-p scan
% *************************************************************************
gba0=15.0;
gab0=25.0;
dp=5;
dim1=25;
dim2=25;
phaseDia=ones(dim1,dim2)*NaN;
Val_gba=ones(dim1,dim2)*NaN;
Val_gab=ones(dim1,dim2)*NaN;
% *************************************************************************

% *************************************************************************
% Numerical parameters for bifurcation calculations 
% *************************************************************************
sig_max=1000;   % The maximum value of the bifurcation parameter (S)
dsig1=0.5;      % bifurcation parameter step length (dS) in low-res run
dsig2=0.1;      % bifurcation parameter step length (dS) in high-res run
sigE1=sig_max/dsig1;    % # of signal values in low-res calculation      
sigE2=sig_max/dsig2;    % # of signal points in high-res calculation
dx1=8;          % step length of the dynamical variable in low-res run    
dx2=1;          % step length of the dynamical variable in high-res run
xE=10000;       % Maximum value of the dynamical variable     
b1=[0:dx1:xE];      
b2=[0:dx2:xE];
sig1=[1:sigE1];
sig2=[1:sigE2];
% *************************************************************************
% *************************************************************************
% Numerical parameters to speed up high-res bifurcation calculations
% *************************************************************************
% dSr: different chosen values of bistable regions to modify dS as needed
dSr=[5 50 200 400];
% dSn: step length depending on the bistable region in the low-res run
% fac: a factor to adjust step length as needed in high-res run
fac=1;              
dSn=[0.025 0.05 0.1 0.2 0.5].*fac;
% for dS <= dSr(1): new dS=dSn(1)
% for dSr(1) < dS <= dSr(2): new dS=dSn(2)
% for dSr(2) < dS <= dSr(3): new dS=dSn(3)
% for dSr(3) < dS <= dSr(4): new dS=dSn(4)
% for dS> dSr(4): new dS=dSn(5)

% parameters to run high-res run only around the bistable region to seed up
% runtime
dSc=[50 100 200];
Sct=[15 25 50 100];
% *************************************************************************
 
% *************************************************************************
% Calculation of phase diagram begins here
% *************************************************************************    
fcnt=0;
for kp1=1:dim1                          % loop for gba starts here
    gba=gba0+(kp1-1)*dp;
    fnt1=dim1*(dim2-kp1);
    for kp2=1:dim2                      % loop for gab starts here
        [kp1 kp2]
        fnt2=fnt1+kp2;
        gab=gab0+(kp2-1)*dp;
        Val_gba(kp1,kp2)=gba;
        Val_gab(kp1,kp2)=gab;
        param(3)=gab;
        param(6)=gba;
        fcnt=fcnt+1;
        nmbr_peaks_ss=ones(1,sigE1)*NaN;
        nmbr_peaks_us=ones(1,sigE1)*NaN;
%         [gba gab];
        
        PotEr=[];
        xss=ones(length(sigE1),3)*NaN;
        xus=ones(length(sigE1),3)*NaN;
        dsig2=0.1;
        
        % *****************************************************************
        % Low-res bifurcation run starts here
        % *****************************************************************
        for jj=1:sigE1                  % loop for bifurcation parameter
            
            S0=sig1(jj)*dsig1;
            [f]=BS_model_phaseD(S0,b1,param);
            
            z=dx1*cumtrapz(-f);   % z: pseudo-potential energy function
            z1=z-min(z);          % rescaling of potential against the global
            % minima of the pontential function
            z2=-z1;
            
            nmbr_peaks_ss(jj)=numel(findpeaks(z2));     % no. of minima in PEF
            nmbr_peaks_us(jj)=numel(findpeaks(z1));     % no. of mamima in PEF
            [stb_pks stb_locs] = findpeaks(z2);
            [ustb_pks ustb_locs] = findpeaks(z1);
            if length(stb_locs)==2
                xss(jj,1)=S0;
                xss(jj,2)=b1(stb_locs(1));
                xss(jj,3)=b1(stb_locs(2));
            elseif length(stb_locs)==1
                xss(jj,1)=S0;
                xss(jj,2)=b1(stb_locs(1));
                xss(jj,3)=NaN;
            end
            if length(ustb_locs)==1
                xus(jj,1)=S0;
                xus(jj,2)=b1(ustb_locs(1));
                xus(jj,3)=NaN;
            elseif isempty(ustb_locs)==0
                xus(jj,1)=S0;
                xus(jj,2)=NaN;
                xus(jj,3)=NaN;
            end
        end
        % *****************************************************************
        % Low-res run ends here
        % *****************************************************************
        
        % *****************************************************************
        % Determination of no. of bifurcation points
        % *****************************************************************
        srt=nmbr_peaks_ss(cumsum(nmbr_peaks_ss,2) > 0);
        flipdiff=flip(srt);
        end_zero=flipdiff(cumsum(flipdiff,2) > 0);
        final_diff=flip(end_zero);
        diff_ss=diff(final_diff);
        sum_diffss=sum(abs(diff_ss));
        % *****************************************************************
        
        % *****************************************************************
        % Adjustment of maximum value of the dynamical variable based
        % on low-res run
        % *****************************************************************
        xmax=max(max(xss(:,2)),max(xss(:,3)));
        %   Setting new range of X based on maximum X_ss
        xE1=round(xmax,-3)+500;
        b2=[0:dx2:xE1];
        % *****************************************************************
        
        % *****************************************************************
        % Running bifurcation only for the parameter combination that
        % resulted multistability in the low-res run
        % *****************************************************************
        
        % Counting the no. of stable steady state
        if max(nmbr_peaks_ss)==1
            phaseDia(kp1,kp2)=0;       % for monostability
        elseif max(nmbr_peaks_ss)>=2
            
            % *************************************************************
            % Determination of step length, minimum and maximum values
            % of the bifurcation paramters for the high-res run to
            % speed up calculation by runnig bifurcation only around
            % the bistable region obtained from the low-res run
            % *********************************************************
            [sigE3,sigE3F1,dsig2nw,dsig2]=ParRegion_highres(nmbr_peaks_ss,sum_diffss,dSc,Sct,dSr,dSn,sigE1,sigE2,dsig2);
            % *********************************************************
            sZ=sigE3-sigE3F1;
            peaks_ss=ones(1,sZ)*NaN;
            peaks_us=ones(1,sZ)*NaN;
            vss=ones(sZ,4)*NaN;
            vuss=ones(sZ,4)*NaN;
            sig2=[1:sigE3];
            
            % *************************************************************
            % High-res bifurcation run starts here
            % *************************************************************
            for j=1:sZ             % Loop for the bifurcation parameter
                
                j1=sigE3F1+(j-1);
                S0=sig2(j1)*dsig2;
                [f]=BS_model_phaseD(S0,b2,param);
                
                z0=dx2*cumtrapz(-f);    % z0: pseudo-potential energy function
                z11=z0-min(z0);         % rescaled PEF
                z22=-z11;
                
                peaks_ss(j)=numel(findpeaks(z22));  % no. of minima in PEF
                peaks_us(j)=numel(findpeaks(z11));  % no. of maxima in PEF
                
                [pks_stb locs_stb] = findpeaks(z22); % pks_stb: no. of stable ss
                
                if length(locs_stb)==3
                    vss(j,1)=S0;
                    vss(j,2)=b2(locs_stb(1));
                    vss(j,3)=b2(locs_stb(2));
                    vss(j,4)=b2(locs_stb(3));
                elseif length(locs_stb)==2
                    vss(j,1)=S0;
                    vss(j,2)=b2(locs_stb(1));
                    vss(j,3)=b2(locs_stb(2));
                    vss(j,4)=NaN;
                elseif length(locs_stb)==1
                    vss(j,1)=S0;
                    vss(j,2)=b2(locs_stb(1));
                    vss(j,3)=NaN;
                    vss(j,4)=NaN;
                end
                
                [pks_us locs_us] = findpeaks(z11);   % pks_stb: no. of unstable ss
                
                if length(locs_us)==2
                    vuss(j,1)=S0;
                    vuss(j,2)=b2(locs_us(1));
                    vuss(j,3)=b2(locs_us(2));
                    vuss(j,4)=NaN;
                elseif length(locs_us)==1
                    vuss(j,1)=S0;
                    vuss(j,2)=b2(locs_us(1));
                    vuss(j,3)=NaN;
                    vuss(j,4)=NaN;
                    %                     elseif length(locs_us)==0
                elseif isempty(locs_us)==0
                    vuss(j,1)=S0;
                    vuss(j,2)=NaN;
                    vuss(j,3)=NaN;
                    vuss(j,4)=NaN;
                end
            end
            % *************************************************************
            
            % *************************************************************
            % Discarded: in case the high res run genrates tristability
            % *************************************************************
            if max(peaks_ss)>=3
                phaseDia(kp1,kp2)=200;     % for tristablity
                continue
            end
            % *************************************************************
            
            % *************************************************************
            % Discarded: if the bifurcation in truncated in the Y axis
            % *************************************************************
            unF=find(~isnan(vuss(:,2)), 1, 'first');
            unL=find(~isnan(vuss(:,2)), 1, 'last');
            sbF=find(~isnan(vss(:,2)), 1, 'first');
            sbL=find(~isnan(vss(:,2)), 1, 'last');
            
            if peaks_us(1)>0
                if isnan(vss(unF,2)) | isnan(vss(unF,3))
                    continue
                end
            elseif peaks_us(end)>0
                if isnan(vss(unL,2)) | isnan(vss(unL,3))
                    continue
                end
            elseif peaks_us(1)>1 && peaks_us(end)>1
                if isnan(vss(unL,2)) | isnan(vss(unL,3)) | isnan(vss(unF,3)) | isnan(vss(unL,3))
                    continue
                end
            else
                if isnan(vss(unF,3)) | isnan(vss(unL,3))
                    continue
                end
            end
            % *************************************************************
            
            % *************************************************************
            % To determine jump pattern of SS at the bifurcation points
            % steady states values away from the bifurcation points are
            % discared to minimize error in calculation
            % *************************************************************
            if (dsig2nw==dSn(5))
                nCut=10;
            elseif (dsig2nw==dSn(4))
                nCut=20;
            elseif (dsig2nw==dSn(3))
                nCut=30;
            elseif (dsig2nw==dSn(2))
                nCut=40;
            else
                nCut=50;
            end
            nF=max(unF-nCut,1);
            nL=min(unL+nCut,sZ);
            nSize=nL-nF+1;
            
            vss1=vss(nF:nL,:);
            vus1=vuss(nF:nL,:);
            % *************************************************************
            
            % *************************************************************
            % Determination of number of jumps and locations in the
            % bifurcation diagram
            % *************************************************************
            [sum_diffss2,bfrSN,jmpN,jmpLocSN]=BS_jumpSS_SN(peaks_ss,vss1,vus1);
            % *************************************************************
            
            % *************************************************************
            % plot of bifurcation diagrams
            % *************************************************************
%             fig1=figure(1);
%             subplot(dim1,dim2,fnt2)
%             plot_bifurcation(bfrSN,vss1,vus1)
%             set(gca,'XtickLabel',[])
%             set(gca,'YtickLabel',[])
            % *************************************************************
            
            % *************************************************************
            % Determination of types of bistable switches based on the
            % number and location of jumps in stable branch at the
            % bifurcation points
            % *************************************************************
            [Cnt,phaseIndx]=BS_switchSegregationPhDia_189BS(peaks_ss,sum_diffss2,jmpN,jmpLocSN,Cnt);
            % *************************************************************
            
            phaseDia(kp1,kp2)=phaseIndx;
            
            %                 clear stbss unsss vss vuss vss1 vssN vus1 Grd2mn Grd2mn1 Grd2mx ...
            %                     Grd2mx1 Loc_grd2mn Loc_grd2mn1 Loc_grd2mx Loc_grd2mx1 ...
            %                     mxDf mnDf locmn locmx LoC MxMn
            
        end
    end
end
% *************************************************************************
% Calculation of phase diagram ends here
% *************************************************************************

%**************************************************************************
% Saving counts and parameters of segregated 189 BS switches 
%**************************************************************************
[ppMISA_OR_189BS]=BS_saveCnt_189BS(Cnt);
%**************************************************************************

%**************************************************************************
% plot of phase diagram
%**************************************************************************
plot_phaseDia(Val_gba,Val_gab,phaseDia)
%**************************************************************************

%**************************************************************************
% plot of phase diagram after rescaling phase indices between 1 and total
% no. of phases
%**************************************************************************
plot_phaseDia_Rscl(Val_gba,Val_gab,phaseDia)
%**************************************************************************

%**************************************************************************
% saving data files for the phase diagram calculations
%**************************************************************************
% save phaseDia_189BS_ppMISA_gab_gba.mat phaseDia Val_gab Val_gba ppMISA_OR_189BS
%**************************************************************************
% savefig(fig1,'phaseDia_ppMISA_r1p6')
% saveas(fig1,'phaseDia_ppMISA_r1p6','png')

toc

% quit

