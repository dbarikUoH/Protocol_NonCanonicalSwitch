% *************************************************************************
% This function plots the 2D phase surface plot of the bistable switches
% *************************************************************************
% Date: July 04, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function plot_phaseDia(Val_gba,Val_gab,phaseDia)

phaseDia(phaseDia==0)=NaN;

figure(2)
surf(Val_gba(:,1),Val_gab(1,:),phaseDia','EdgeColor','none'),view(2)
set(gca,'ylim',[min(min(Val_gab)) max(max(Val_gab))],'xlim',[min(min(Val_gba)) max(max(Val_gba))])
set(gca,'xtick',linspace(min(min(Val_gba)),max(max(Val_gba)),6))
set(gca,'ytick',linspace(min(min(Val_gab)),max(max(Val_gab)),6))
set(gca,'box','on','XGrid','off','YGrid','off','fontsize',14)
set(gca,'Clim',[1 max(unique(phaseDia))]);
xlabel('g_{BA}','fontsize',16)
ylabel('g_{AB}','fontsize',16)

