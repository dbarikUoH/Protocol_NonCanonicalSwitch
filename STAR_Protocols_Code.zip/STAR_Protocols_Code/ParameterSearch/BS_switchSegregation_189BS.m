% *************************************************************************
% This function determines the type of 189 bistable switches, counts their 
% numbers and segregates their parameters accoriding to the type of the 
% switch.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [Cnt,Indx,Par]=BS_switchSegregation_189BS(kk,ic1,data,peaks_ss,sum_diffss2,jmpN,jmpLocSN,Cnt,Indx,Par)

if(peaks_ss(1)>1 && peaks_ss(end)>1)          % irreversible switch on Left & right
    if (sum_diffss2==0)
        disp('L-Bs-R')
        Cnt.L_Bs_R=Cnt.L_Bs_R+1;
        Indx.L_Bs_R_par(Cnt.L_Bs_R,1)=kk;
        Par.para_L_Bs_R(Cnt.L_Bs_R,:)=data(kk,:);
        phaseIndx(ic1)=169;
    elseif (sum_diffss2==2)
        if jmpN==0
            disp('L-DIs-R')
            Cnt.L_DIs_R=Cnt.L_DIs_R+1;
            Indx.L_DIs_R_par(Cnt.L_DIs_R,1)=kk;
            Par.para_L_DIs_R(Cnt.L_DIs_R,:)=data(kk,:);
            phaseIndx(ic1)=170;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-Is-R')
                Cnt.L_BsF_Is_R=Cnt.L_BsF_Is_R+1;
                Indx.L_BsF_Is_R_par(Cnt.L_BsF_Is_R,1)=kk;
                Par.para_L_BsF_Is_R(Cnt.L_BsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=171;
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-R')
                Cnt.L_Is_BsB_R=Cnt.L_Is_BsB_R+1;
                Indx.L_Is_BsB_R_par(Cnt.L_Is_BsB_R,1)=kk;
                Par.para_L_Is_BsB_R(Cnt.L_Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=172;
            end
        elseif jmpN==2
            disp('L-Msh-R')
            Cnt.L_Msh_R=Cnt.L_Msh_R+1;
            Indx.L_Msh_R_par(Cnt.L_Msh_R,1)=kk;
            Par.para_L_Msh_R(Cnt.L_Msh_R,:)=data(kk,:);
            phaseIndx(ic1)=173;
        end
    elseif (sum_diffss2==4)
        if jmpN==0
            disp('L-TIs-R')
            Cnt.L_TIs_R=Cnt.L_TIs_R+1;
            Indx.L_TIs_R_par(Cnt.L_TIs_R,1)=kk;
            Par.para_L_TIs_R(Cnt.L_TIs_R,:)=data(kk,:);
            phaseIndx(ic1)=174;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-DIs-R')
                Cnt.L_BsF_DIs_R=Cnt.L_BsF_DIs_R+1;
                Indx.L_BsF_DIs_R_par(Cnt.L_BsF_DIs_R,1)=kk;
                Par.para_L_BsF_DIs_R(Cnt.L_BsF_DIs_R,:)=data(kk,:);
                phaseIndx(ic1)=175;
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-Is-R')
                Cnt.L_Is_BsB_Is_R=Cnt.L_Is_BsB_Is_R+1;
                Indx.L_Is_BsB_Is_R_par(Cnt.L_Is_BsB_Is_R,1)=kk;
                Par.para_L_Is_BsB_Is_R(Cnt.L_Is_BsB_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=176;
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF-Is-R')
                Cnt.L_Is_BsF_Is_R=Cnt.L_Is_BsF_Is_R+1;
                Indx.L_Is_BsF_Is_R_par(Cnt.L_Is_BsF_Is_R,1)=kk;
                Par.para_L_Is_BsF_Is_R(Cnt.L_Is_BsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=177;
            elseif jmpLocSN(1)==4
                disp('L-DIs-BsB-R')
                Cnt.L_DIs_BsB_R=Cnt.L_DIs_BsB_R+1;
                Indx.L_DIs_BsB_R_par(Cnt.L_DIs_BsB_R,1)=kk;
                Par.para_L_DIs_BsB_R(Cnt.L_DIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=178;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh-Is-R')
                Cnt.L_Msh_Is_R=Cnt.L_Msh_Is_R+1;
                Indx.L_Msh_Is_R_par(Cnt.L_Msh_Is_R,1)=kk;
                Par.para_L_Msh_Is_R(Cnt.L_Msh_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=179;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF-Is-R')
                Cnt.L_DBsF_Is_R=Cnt.L_DBsF_Is_R+1;
                Indx.L_DBsF_Is_R_par(Cnt.L_DBsF_Is_R,1)=kk;
                Par.para_L_DBsF_Is_R(Cnt.L_DBsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=180;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('L-BsF-Is-BsB-R')
                Cnt.L_BsF_Is_BsB_R=Cnt.L_BsF_Is_BsB_R+1;
                Indx.L_BsF_Is_BsB_R_par(Cnt.L_BsF_Is_BsB_R,1)=kk;
                Par.para_L_BsF_Is_BsB_R(Cnt.L_BsF_Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=181;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs-Is-R')
                Cnt.L_Is_InIs_Is_R=Cnt.L_Is_InIs_Is_R+1;
                Indx.L_Is_InIs_Is_R_par(Cnt.L_Is_InIs_Is_R,1)=kk;
                Par.para_L_Is_InIs_Is_R(Cnt.L_Is_InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=182;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('L-Is-DBsB-R')
                Cnt.L_Is_DBsB_R=Cnt.L_Is_DBsB_R+1;
                Indx.L_Is_DBsB_R_par(Cnt.L_Is_DBsB_R,1)=kk;
                Par.para_L_Is_DBsB_R(Cnt.L_Is_DBsB_R,:)=data(kk,:);
                phaseIndx(ic1)=183;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('L-Is-Msh-R')
                Cnt.L_Is_Msh_R=Cnt.L_Is_Msh_R+1;
                Indx.L_Is_Msh_R_par(Cnt.L_Is_Msh_R,1)=kk;
                Par.para_L_Is_Msh_R(Cnt.L_Is_Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=184;
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('L-BsF-InIs-Is-R')
                Cnt.L_BsF_InIs_Is_R=Cnt.L_BsF_InIs_Is_R+1;
                Indx.L_BsF_InIs_Is_R_par(Cnt.L_BsF_InIs_Is_R,1)=kk;
                Par.para_L_BsF_InIs_Is_R(Cnt.L_BsF_InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=185;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('L-Msh-BsB-R')
                Cnt.L_Msh_BsB_R=Cnt.L_Msh_BsB_R+1;
                Indx.L_Msh_BsB_R_par(Cnt.L_Msh_BsB_R,1)=kk;
                Par.para_L_Msh_BsB_R(Cnt.L_Msh_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=186;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-BsF-Msh-R')
                Cnt.L_BsF_Msh_R=Cnt.L_BsF_Msh_R+1;
                Indx.L_BsF_Msh_R_par(Cnt.L_BsF_Msh_R,1)=kk;
                Par.para_L_BsF_Msh_R(Cnt.L_BsF_Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=187;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-Is-InIs-BsB-R')
                Cnt.L_Is_InIs_BsB_R=Cnt.L_Is_InIs_BsB_R+1;
                Indx.L_Is_InIs_BsB_R_par(Cnt.L_Is_InIs_BsB_R,1)=kk;
                Par.para_L_Is_InIs_BsB_R(Cnt.L_Is_InIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=188;
            end
        elseif jmpN==4
            disp('L-BsF-InIs-BsB-R')
            Cnt.L_BsF_InIs_BsB_R=Cnt.L_BsF_InIs_BsB_R+1;
            Indx.L_BsF_InIs_BsB_R_par(Cnt.L_BsF_InIs_BsB_R,1)=kk;
            Par.para_L_BsF_InIs_BsB_R(Cnt.L_BsF_InIs_BsB_R,:)=data(kk,:);
            phaseIndx(ic1)=189;
        end
    end
end
if(peaks_ss(1)>1)          % irreversible switch on Left
    if (sum_diffss2==1)
        if jmpN==0
            disp('L-BsB')
            Cnt.L_BsB=Cnt.L_BsB+1;
            Indx.L_BsB_par(Cnt.L_BsB,1)=kk;
            Par.para_L_BsB(Cnt.L_BsB,:)=data(kk,:);
            phaseIndx(ic1)=85;
        elseif jmpN==1
            disp('L-BsF')
            Cnt.L_BsF=Cnt.L_BsF+1;
            Indx.L_BsF_par(Cnt.L_BsF,1)=kk;
            Par.para_L_BsF(Cnt.L_BsF,:)=data(kk,:);
            phaseIndx(ic1)=86;
        end
    elseif (sum_diffss2==3)
        if jmpN==0
            disp('L-DIs')
            Cnt.L_DIs=Cnt.L_DIs+1;
            Indx.L_DIs_par(Cnt.L_DIs,1)=kk;
            Par.para_L_DIs(Cnt.L_DIs,:)=data(kk,:);
            phaseIndx(ic1)=87;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-Is')
                Cnt.L_BsF_Is=Cnt.L_BsF_Is+1;
                Indx.L_BsF_Is_par(Cnt.L_BsF_Is,1)=kk;
                Par.para_L_BsF_Is(Cnt.L_BsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=88;
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB')
                Cnt.L_Is_BsB=Cnt.L_Is_BsB+1;
                Indx.L_Is_BsB_par(Cnt.L_Is_BsB,1)=kk;
                Par.para_L_Is_BsB(Cnt.L_Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=89;
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF')
                Cnt.L_Is_BsF=Cnt.L_Is_BsF+1;
                Indx.L_Is_BsF_par(Cnt.L_Is_BsF,1)=kk;
                Par.para_L_Is_BsF(Cnt.L_Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=90;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh')
                Cnt.L_Msh=Cnt.L_Msh+1;
                Indx.L_Msh_par(Cnt.L_Msh,1)=kk;
                Par.para_L_Msh(Cnt.L_Msh,:)=data(kk,:);
                phaseIndx(ic1)=91;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF')
                Cnt.L_DBsF=Cnt.L_DBsF+1;
                Indx.L_DBsF_par(Cnt.L_DBsF,1)=kk;
                Par.para_L_DBsF(Cnt.L_DBsF,:)=data(kk,:);
                phaseIndx(ic1)=92;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs')
                Cnt.L_Is_InIs=Cnt.L_Is_InIs+1;
                Indx.L_Is_InIs_par(Cnt.L_Is_InIs,1)=kk;
                Par.para_L_Is_InIs(Cnt.L_Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=93;
            end
        elseif jmpN==3
            disp('L-BsF-InIs')
            Cnt.L_BsF_InIs=Cnt.L_BsF_InIs+1;
            Indx.L_BsF_InIs_par(Cnt.L_BsF_InIs,1)=kk;
            Par.para_L_BsF_InIs(Cnt.L_BsF_InIs,:)=data(kk,:);
            phaseIndx(ic1)=94;
        end
    elseif (sum_diffss2==5)
        if jmpN==0
            disp('L-Tis')
            Cnt.L_Tis=Cnt.L_Tis+1;
            Indx.L_Tis_par(Cnt.L_Tis,1)=kk;
            Par.para_L_Tis(Cnt.L_Tis,:)=data(kk,:);
            phaseIndx(ic1)=95;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('L-BsF-DIs')
                Cnt.L_BsF_DIs=Cnt.L_BsF_DIs+1;
                Indx.L_BsF_DIs_par(Cnt.L_BsF_DIs,1)=kk;
                Par.para_L_BsF_DIs(Cnt.L_BsF_DIs,:)=data(kk,:);
                phaseIndx(ic1)=96;
            elseif jmpLocSN(1)==2
                disp('L-Is-BsB-Is')
                Cnt.L_Is_BsB_Is=Cnt.L_Is_BsB_Is+1;
                Indx.L_Is_BsB_Is_par(Cnt.L_Is_BsB_Is,1)=kk;
                Par.para_L_Is_BsB_Is(Cnt.L_Is_BsB_Is,:)=data(kk,:);
                phaseIndx(ic1)=97;
            elseif jmpLocSN(1)==3
                disp('L-Is-BsF-Is')
                Cnt.L_Is_BsF_Is=Cnt.L_Is_BsF_Is+1;
                Indx.L_Is_BsF_Is_par(Cnt.L_Is_BsF_Is,1)=kk;
                Par.para_L_Is_BsF_Is(Cnt.L_Is_BsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=98;
            elseif jmpLocSN(1)==4
                disp('L-DIs-BsB')
                Cnt.L_DIs_BsB=Cnt.L_DIs_BsB+1;
                Indx.L_DIs_BsB_par(Cnt.L_DIs_BsB,1)=kk;
                Par.para_L_DIs_BsB(Cnt.L_DIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=99;
            elseif jmpLocSN(1)==5
                disp('L-DIs-BsF')
                Cnt.L_DIs_BsF=Cnt.L_DIs_BsF+1;
                Indx.L_DIs_BsF_par(Cnt.L_DIs_BsF,1)=kk;
                Par.para_L_DIs_BsF(Cnt.L_DIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=100;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('L-Msh-Is')
                Cnt.L_Msh_Is=Cnt.L_Msh_Is+1;
                Indx.L_Msh_Is_par(Cnt.L_Msh_Is,1)=kk;
                Par.para_L_Msh_Is(Cnt.L_Msh_Is,:)=data(kk,:);
                phaseIndx(ic1)=101;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('L-DBsF-Is')
                Cnt.L_DBsF_Is=Cnt.L_DBsF_Is+1;
                Indx.L_DBsF_Is_par(Cnt.L_DBsF_Is,1)=kk;
                Par.para_L_DBsF_Is(Cnt.L_DBsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=102;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('L-BsF-Is-BsB')
                Cnt.L_BsF_Is_BsB=Cnt.L_BsF_Is_BsB+1;
                Indx.L_BsF_Is_BsB_par(Cnt.L_BsF_Is_BsB,1)=kk;
                Par.para_L_BsF_Is_BsB(Cnt.L_BsF_Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=103;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('L-BsF-Is-BsF')
                Cnt.L_BsF_Is_BsF=Cnt.L_BsF_Is_BsF+1;
                Indx.L_BsF_Is_BsF_par(Cnt.L_BsF_Is_BsF,1)=kk;
                Par.para_L_BsF_Is_BsF(Cnt.L_BsF_Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=104;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('L-Is-InIs-Is')
                Cnt.L_Is_InIs_Is=Cnt.L_Is_InIs_Is+1;
                Indx.L_Is_InIs_Is_par(Cnt.L_Is_InIs_Is,1)=kk;
                Par.para_L_Is_InIs_Is(Cnt.L_Is_InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=105;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('L-Is-DBsB')
                Cnt.L_Is_DBsB=Cnt.L_Is_DBsB+1;
                Indx.L_Is_DBsB_par(Cnt.L_Is_DBsB,1)=kk;
                Par.para_L_Is_DBsB(Cnt.L_Is_DBsB,:)=data(kk,:);
                phaseIndx(ic1)=106;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('L-Is-InMsh')
                Cnt.L_Is_InMsh=Cnt.L_Is_InMsh+1;
                Indx.L_Is_InMsh_par(Cnt.L_Is_InMsh,1)=kk;
                Par.para_L_Is_InMsh(Cnt.L_Is_InMsh,:)=data(kk,:);
                phaseIndx(ic1)=107;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('L-Is-Msh')
                Cnt.L_Is_Msh=Cnt.L_Is_Msh+1;
                Indx.L_Is_Msh_par(Cnt.L_Is_Msh,1)=kk;
                Par.para_L_Is_Msh(Cnt.L_Is_Msh,:)=data(kk,:);
                phaseIndx(ic1)=108;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('L-Is-DBsF')
                Cnt.L_Is_DBsF=Cnt.L_Is_DBsF+1;
                Indx.L_Is_DBsF_par(Cnt.L_Is_DBsF,1)=kk;
                Par.para_L_Is_DBsF(Cnt.L_Is_DBsF,:)=data(kk,:);
                phaseIndx(ic1)=109;
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('L-DIs-Is')
                Cnt.L_DIs_Is=Cnt.L_DIs_Is+1;
                Indx.L_DIs_Is_par(Cnt.L_DIs_Is,1)=kk;
                Par.para_L_DIs_Is(Cnt.L_DIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=110;
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('L-BsF-InIs-Is')
                Cnt.L_BsF_InIs_Is=Cnt.L_BsF_InIs_Is+1;
                Indx.L_BsF_InIs_Is_par(Cnt.L_BsF_InIs_Is,1)=kk;
                Par.para_L_BsF_InIs_Is(Cnt.L_BsF_InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=111;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('L-Msh-BsB')
                Cnt.L_Msh_BsB=Cnt.L_Msh_BsB+1;
                Indx.L_Msh_BsB_par(Cnt.L_Msh_BsB,1)=kk;
                Par.para_L_Msh_BsB(Cnt.L_Msh_BsB,:)=data(kk,:);
                phaseIndx(ic1)=112;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('L-Msh-BsF')
                Cnt.L_Msh_BsF=Cnt.L_Msh_BsF+1;
                Indx.L_Msh_BsF_par(Cnt.L_Msh_BsF,1)=kk;
                Par.para_L_Msh_BsF(Cnt.L_Msh_BsF,:)=data(kk,:);
                phaseIndx(ic1)=113;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-BsF-Msh')
                Cnt.L_BsF_Msh=Cnt.L_BsF_Msh+1;
                Indx.L_BsF_Msh_par(Cnt.L_BsF_Msh,1)=kk;
                Par.para_L_BsF_Msh(Cnt.L_BsF_Msh,:)=data(kk,:);
                phaseIndx(ic1)=114;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('L-TBsF')
                Cnt.L_TBsF=Cnt.L_TBsF+1;
                Indx.L_TBsF_par(Cnt.L_TBsF,1)=kk;
                Par.para_L_TBsF(Cnt.L_TBsF,:)=data(kk,:);
                phaseIndx(ic1)=115;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-BsF-Is-InIs')
                Cnt.L_BsF_Is_InIs=Cnt.L_BsF_Is_InIs+1;
                Indx.L_BsF_Is_InIs_par(Cnt.L_BsF_Is_InIs,1)=kk;
                Par.para_L_BsF_Is_InIs(Cnt.L_BsF_Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=116;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('L-Is-InIs-BsB')
                Cnt.L_Is_InIs_BsB=Cnt.L_Is_InIs_BsB+1;
                Indx.L_Is_InIs_BsB_par(Cnt.L_Is_InIs_BsB,1)=kk;
                Par.para_L_Is_InIs_BsB(Cnt.L_Is_InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=117;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('L-Is-InIs-BsF')
                Cnt.L_Is_InIs_BsF=Cnt.L_Is_InIs_BsF+1;
                Indx.L_Is_InIs_BsF_par(Cnt.L_Is_InIs_BsF,1)=kk;
                Par.para_L_Is_InIs_BsF(Cnt.L_Is_InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=118;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-Is-BsB-InIs')
                Cnt.L_Is_BsB_InIs=Cnt.L_Is_BsB_InIs+1;
                Indx.L_Is_BsB_InIs_par(Cnt.L_Is_BsB_InIs,1)=kk;
                Par.para_L_Is_BsB_InIs(Cnt.L_Is_BsB_InIs,:)=data(kk,:);
                phaseIndx(ic1)=119;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('L-Is-BsF-InIs')
                Cnt.L_Is_BsF_InIs=Cnt.L_Is_BsF_InIs+1;
                Indx.L_Is_BsF_InIs_par(Cnt.L_Is_BsF_InIs,1)=kk;
                Par.para_L_Is_BsF_InIs(Cnt.L_Is_BsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=120;
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4
                disp('L-BsF-InIs-BsB')
                Cnt.L_BsF_InIs_BsB=Cnt.L_BsF_InIs_BsB+1;
                Indx.L_BsF_InIs_BsB_par(Cnt.L_BsF_InIs_BsB,1)=kk;
                Par.para_L_BsF_InIs_BsB(Cnt.L_BsF_InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=121;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5
                disp('L-BsF-InIs-BsF')
                Cnt.L_BsF_InIs_BsF=Cnt.L_BsF_InIs_BsF+1;
                Indx.L_BsF_InIs_BsF_par(Cnt.L_BsF_InIs_BsF,1)=kk;
                Par.para_L_BsF_InIs_BsF(Cnt.L_BsF_InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=122;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-Msh-InIs')
                Cnt.L_Msh_InIs=Cnt.L_Msh_InIs+1;
                Indx.L_Msh_InIs_par(Cnt.L_Msh_InIs,1)=kk;
                Par.para_L_Msh_InIs(Cnt.L_Msh_InIs,:)=data(kk,:);
                phaseIndx(ic1)=123;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-DBsF-InIs')
                Cnt.L_DBsF_InIs=Cnt.L_DBsF_InIs+1;
                Indx.L_DBsF_InIs_par(Cnt.L_DBsF_InIs,1)=kk;
                Par.para_L_DBsF_InIs(Cnt.L_DBsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=124;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('L-Is-DInIs')
                Cnt.L_Is_DInIs=Cnt.L_Is_DInIs+1;
                Indx.L_Is_DInIs_par(Cnt.L_Is_DInIs,1)=kk;
                Par.para_L_Is_DInIs(Cnt.L_Is_DInIs,:)=data(kk,:);
                phaseIndx(ic1)=125;
            end
        elseif jmpN==5
            disp('L-BsF-DInIs')
            Cnt.L_BsF_DInIs=Cnt.L_BsF_DInIs+1;
            Indx.L_BsF_DInIs_par(Cnt.L_BsF_DInIs,1)=kk;
            Par.para_L_BsF_DInIs(Cnt.L_BsF_DInIs,:)=data(kk,:);
            phaseIndx(ic1)=126;
        end
    end
elseif (peaks_ss(end)>1)   % irreversible switch on Right
    if (sum_diffss2==1)
        if jmpN==0
            disp('BsF-R')
            Cnt.BsF_R=Cnt.BsF_R+1;
            Indx.BsF_R_par(Cnt.BsF_R,1)=kk;
            Par.para_BsF_R(Cnt.BsF_R,:)=data(kk,:);
            phaseIndx(ic1)=127;
        elseif jmpN==1
            disp('BsB-R')
            Cnt.BsB_R=Cnt.BsB_R+1;
            Indx.BsB_R_par(Cnt.BsB_R,1)=kk;
            Par.para_BsB_R(Cnt.BsB_R,:)=data(kk,:);
            phaseIndx(ic1)=128;
        end
    elseif (sum_diffss2==3)
        if jmpN==0
            disp('DIs-R')
            Cnt.DIs_R=Cnt.DIs_R+1;
            Indx.DIs_R_par(Cnt.DIs_R,1)=kk;
            Par.para_DIs_R(Cnt.DIs_R,:)=data(kk,:);
            phaseIndx(ic1)=129;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-Is-R')
                Cnt.BsB_Is_R=Cnt.BsB_Is_R+1;
                Indx.BsB_Is_R_par(Cnt.BsB_Is_R,1)=kk;
                Par.para_BsB_Is_R(Cnt.BsB_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=130;
            elseif jmpLocSN(1)==2
                disp('BsF-Is-R')
                Cnt.BsF_Is_R=Cnt.BsF_Is_R+1;
                Indx.BsF_Is_R_par(Cnt.BsF_Is_R,1)=kk;
                Par.para_BsF_Is_R(Cnt.BsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=131;
            elseif jmpLocSN(1)==3
                disp('Is-BsB-R')
                Cnt.Is_BsB_R=Cnt.Is_BsB_R+1;
                Indx.Is_BsB_R_par(Cnt.Is_BsB_R,1)=kk;
                Par.para_Is_BsB_R(Cnt.Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=132;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-Is-R')
                Cnt.InIs_Is_R=Cnt.InIs_Is_R+1;
                Indx.InIs_Is_R_par(Cnt.InIs_Is_R,1)=kk;
                Par.para_InIs_Is_R(Cnt.InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=133;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-R')
                Cnt.DBsB_R=Cnt.DBsB_R+1;
                Indx.DBsB_R_par(Cnt.DBsB_R,1)=kk;
                Par.para_DBsB_R(Cnt.DBsB_R,:)=data(kk,:);
                phaseIndx(ic1)=134;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-R')
                Cnt.Msh_R=Cnt.Msh_R+1;
                Indx.Msh_R_par(Cnt.Msh_R,1)=kk;
                Par.para_Msh_R(Cnt.Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=135;
            end
        elseif jmpN==3
            disp('InIs-BsB-R')
            Cnt.InIs_BsB_R=Cnt.InIs_BsB_R+1;
            Indx.InIs_BsB_R_par(Cnt.InIs_BsB_R,1)=kk;
            Par.para_InIs_BsB_R(Cnt.InIs_BsB_R,:)=data(kk,:);
            phaseIndx(ic1)=136;
        end
    elseif (sum_diffss2==5)
        if jmpN==0
            disp('Tis-R')
            Cnt.Tis_R=Cnt.Tis_R+1;
            Indx.Tis_R_par(Cnt.Tis_R,1)=kk;
            Par.para_Tis_R(Cnt.Tis_R,:)=data(kk,:);
            phaseIndx(ic1)=137;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-DIs-R')
                Cnt.BsB_DIs_R=Cnt.BsB_DIs_R+1;
                Indx.BsB_DIs_R_par(Cnt.BsB_DIs_R,1)=kk;
                Par.para_BsB_DIs_R(Cnt.BsB_DIs_R,:)=data(kk,:);
                phaseIndx(ic1)=138;
            elseif jmpLocSN(1)==2
                disp('BsF-DIs-R')
                Cnt.BsF_DIs_R=Cnt.BsF_DIs_R+1;
                Indx.BsF_DIs_R_par(Cnt.BsF_DIs_R,1)=kk;
                Par.para_BsF_DIs_R(Cnt.BsF_DIs_R,:)=data(kk,:);
                phaseIndx(ic1)=139;
            elseif jmpLocSN(1)==3
                disp('Is-BsB-Is-R')
                Cnt.Is_BsB_Is_R=Cnt.Is_BsB_Is_R+1;
                Indx.Is_BsB_Is_R_par(Cnt.Is_BsB_Is_R,1)=kk;
                Par.para_Is_BsB_Is_R(Cnt.Is_BsB_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=140;
            elseif jmpLocSN(1)==4
                disp('Is-BsF-Is-R')
                Cnt.Is_BsF_Is_R=Cnt.Is_BsF_Is_R+1;
                Indx.Is_BsF_Is_R_par(Cnt.Is_BsF_Is_R,1)=kk;
                Par.para_Is_BsF_Is_R(Cnt.Is_BsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=141;
            elseif jmpLocSN(1)==5
                disp('DIs-BsB-R')
                Cnt.DIs_BsB_R=Cnt.DIs_BsB_R+1;
                Indx.DIs_BsB_R_par(Cnt.DIs_BsB_R,1)=kk;
                Par.para_DIs_BsB_R(Cnt.DIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=142;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-DIs-R')
                Cnt.InIs_DIs_R=Cnt.InIs_DIs_R+1;
                Indx.InIs_DIs_R_par(Cnt.InIs_DIs_R,1)=kk;
                Par.para_InIs_DIs_R(Cnt.InIs_DIs_R,:)=data(kk,:);
                phaseIndx(ic1)=143;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-Is-R')
                Cnt.DBsB_Is_R=Cnt.DBsB_Is_R+1;
                Indx.DBsB_Is_R_par(Cnt.DBsB_Is_R,1)=kk;
                Par.para_DBsB_Is_R(Cnt.DBsB_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=144;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh-Is-R')
                Cnt.InMsh_Is_R=Cnt.InMsh_Is_R+1;
                Indx.InMsh_Is_R_par(Cnt.InMsh_Is_R,1)=kk;
                Par.para_InMsh_Is_R(Cnt.InMsh_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=145;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('BsB-Is-BsB-R')
                Cnt.BsB_Is_BsB_R=Cnt.BsB_Is_BsB_R+1;
                Indx.BsB_Is_BsB_R_par(Cnt.BsB_Is_BsB_R,1)=kk;
                Par.para_BsB_Is_BsB_R(Cnt.BsB_Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=146;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-Is-R')
                Cnt.Msh_Is_R=Cnt.Msh_Is_R+1;
                Indx.Msh_Is_R_par(Cnt.Msh_Is_R,1)=kk;
                Par.para_Msh_Is_R(Cnt.Msh_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=147;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF-Is-R')
                Cnt.DBsF_Is_R=Cnt.DBsF_Is_R+1;
                Indx.DBsF_Is_R_par(Cnt.DBsF_Is_R,1)=kk;
                Par.para_DBsF_Is_R(Cnt.DBsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=148;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('BsF-Is-BsB-R')
                Cnt.BsF_Is_BsB_R=Cnt.BsF_Is_BsB_R+1;
                Indx.BsF_Is_BsB_R_par(Cnt.BsF_Is_BsB_R,1)=kk;
                Par.para_BsF_Is_BsB_R(Cnt.BsF_Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=149;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs-Is-R')
                Cnt.Is_InIs_Is_R=Cnt.Is_InIs_Is_R+1;
                Indx.Is_InIs_Is_R_par(Cnt.Is_InIs_Is_R,1)=kk;
                Par.para_Is_InIs_Is_R(Cnt.Is_InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=150;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('Is-DBsB-R')
                Cnt.Is_DBsB_R=Cnt.Is_DBsB_R+1;
                Indx.Is_DBsB_R_par(Cnt.Is_DBsB_R,1)=kk;
                Par.para_Is_DBsB_R(Cnt.Is_DBsB_R,:)=data(kk,:);
                phaseIndx(ic1)=151;
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('Is-Msh-R')
                Cnt.Is_Msh_R=Cnt.Is_Msh_R+1;
                Indx.Is_Msh_R_par(Cnt.Is_Msh_R,1)=kk;
                Par.para_Is_Msh_R(Cnt.Is_Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=152;
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB-Is-R')
                Cnt.InIs_BsB_Is_R=Cnt.InIs_BsB_Is_R+1;
                Indx.InIs_BsB_Is_R_par(Cnt.InIs_BsB_Is_R,1)=kk;
                Par.para_InIs_BsB_Is_R(Cnt.InIs_BsB_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=153;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF-Is-R')
                Cnt.InIs_BsF_Is_R=Cnt.InIs_BsF_Is_R+1;
                Indx.InIs_BsF_Is_R_par(Cnt.InIs_BsF_Is_R,1)=kk;
                Par.para_InIs_BsF_Is_R(Cnt.InIs_BsF_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=154;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('InIs-Is-BsB-R')
                Cnt.InIs_Is_BsB_R=Cnt.InIs_Is_BsB_R+1;
                Indx.InIs_Is_BsB_R_par(Cnt.InIs_Is_BsB_R,1)=kk;
                Par.para_InIs_Is_BsB_R(Cnt.InIs_Is_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=155;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs-Is-R')
                Cnt.BsB_InIs_Is_R=Cnt.BsB_InIs_Is_R+1;
                Indx.BsB_InIs_Is_R_par(Cnt.BsB_InIs_Is_R,1)=kk;
                Par.para_BsB_InIs_Is_R(Cnt.BsB_InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=156;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('TBsB-R')
                Cnt.TBsB_R=Cnt.TBsB_R+1;
                Indx.TBsB_R_par(Cnt.TBsB_R,1)=kk;
                Par.para_TBsB_R(Cnt.TBsB_R,:)=data(kk,:);
                phaseIndx(ic1)=157;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('InMsh-BsB-R')
                Cnt.InMsh_BsB_R=Cnt.InMsh_BsB_R+1;
                Indx.InMsh_BsB_R_par(Cnt.InMsh_BsB_R,1)=kk;
                Par.para_InMsh_BsB_R(Cnt.InMsh_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=158;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs-Is-R')
                Cnt.BsF_InIs_Is_R=Cnt.BsF_InIs_Is_R+1;
                Indx.BsF_InIs_Is_R_par(Cnt.BsF_InIs_Is_R,1)=kk;
                Par.para_BsF_InIs_Is_R(Cnt.BsF_InIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=159;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('Msh-BsB-R')
                Cnt.Msh_BsB_R=Cnt.Msh_BsB_R+1;
                Indx.Msh_BsB_R_par(Cnt.Msh_BsB_R,1)=kk;
                Par.para_Msh_BsB_R(Cnt.Msh_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=160;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('BsF-Msh-R')
                Cnt.BsF_Msh_R=Cnt.BsF_Msh_R+1;
                Indx.BsF_Msh_R_par(Cnt.BsF_Msh_R,1)=kk;
                Par.para_BsF_Msh_R(Cnt.BsF_Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=161;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('Is-InIs-BsB-R')
                Cnt.Is_InIs_BsB_R=Cnt.Is_InIs_BsB_R+1;
                Indx.Is_InIs_BsB_R_par(Cnt.Is_InIs_BsB_R,1)=kk;
                Par.para_Is_InIs_BsB_R(Cnt.Is_InIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=162;
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(3)==4
                disp('DInIs-Is-R')
                Cnt.DInIs_Is_R=Cnt.DInIs_Is_R+1;
                Indx.DInIs_Is_R_par(Cnt.DInIs_Is_R,1)=kk;
                Par.para_DInIs_Is_R(Cnt.DInIs_Is_R,:)=data(kk,:);
                phaseIndx(ic1)=163;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(3)==5
                disp('InIs-DBsB-R')
                Cnt.InIs_DBsB_R=Cnt.InIs_DBsB_R+1;
                Indx.InIs_DBsB_R_par(Cnt.InIs_DBsB_R,1)=kk;
                Par.para_InIs_DBsB_R(Cnt.InIs_DBsB_R,:)=data(kk,:);
                phaseIndx(ic1)=164;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('InIs-Msh-R')
                Cnt.InIs_Msh_R=Cnt.InIs_Msh_R+1;
                Indx.InIs_Msh_R_par(Cnt.InIs_Msh_R,1)=kk;
                Par.para_InIs_Msh_R(Cnt.InIs_Msh_R,:)=data(kk,:);
                phaseIndx(ic1)=165;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('BsB-InIs-BsB-R')
                Cnt.BsB_InIs_BsB_R=Cnt.BsB_InIs_BsB_R+1;
                Indx.BsB_InIs_BsB_R_par(Cnt.BsB_InIs_BsB_R,1)=kk;
                Par.para_BsB_InIs_BsB_R(Cnt.BsB_InIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=166;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(3)==5
                disp('BsF-InIs-BsB-R')
                Cnt.BsF_InIs_BsB_R=Cnt.BsF_InIs_BsB_R+1;
                Indx.BsF_InIs_BsB_R_par(Cnt.BsF_InIs_BsB_R,1)=kk;
                Par.para_BsF_InIs_BsB_R(Cnt.BsF_InIs_BsB_R,:)=data(kk,:);
                phaseIndx(ic1)=167;
            end
        elseif jmpN==5
            disp('DInIs-BsB-R')
            Cnt.DInIs_BsB_R=Cnt.DInIs_BsB_R+1;
            Indx.DInIs_BsB_R_par(Cnt.DInIs_BsB_R,1)=kk;
            Par.para_DInIs_BsB_R(Cnt.DInIs_BsB_R,:)=data(kk,:);
            phaseIndx(ic1)=168;
        end
    end
else
    
    if (max(peaks_ss)==2 && (sum_diffss2==2))
        if jmpN==0
            disp('Is')
            Cnt.Is=Cnt.Is+1;
            Indx.Is_par(Cnt.Is,1)=kk;
            Par.para_Is(Cnt.Is,:)=data(kk,:);
            phaseIndx(ic1)=1;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB')
                Cnt.BsB=Cnt.BsB+1;
                Indx.BsB_par(Cnt.BsB,1)=kk;
                Par.para_BsB(Cnt.BsB,:)=data(kk,:);
                phaseIndx(ic1)=2;
            elseif jmpLocSN(1)==2
                disp('BsF')
                Cnt.BsF=Cnt.BsF+1;
                Indx.BsF_par(Cnt.BsF,1)=kk;
                Par.para_BsF(Cnt.BsF,:)=data(kk,:);
                phaseIndx(ic1)=3;
            end
        elseif jmpN==2
            disp('InIs')
            Cnt.InIs=Cnt.InIs+1;
            Indx.InIs_par(Cnt.InIs,1)=kk;
            Par.para_InIs(Cnt.InIs,:)=data(kk,:);
            phaseIndx(ic1)=4;
        end
    elseif (max(peaks_ss)==2 && (sum_diffss2==4))
        if jmpN==0
            disp('DIs')
            Cnt.DIs=Cnt.DIs+1;
            Indx.DIs_par(Cnt.DIs,1)=kk;
            Par.para_DIs(Cnt.DIs,:)=data(kk,:);
            phaseIndx(ic1)=5;
        elseif jmpN==1
            if jmpLocSN==1
                disp('BsB-Is')
                Cnt.BsB_Is=Cnt.BsB_Is+1;
                Indx.BsB_Is_par(Cnt.BsB_Is,1)=kk;
                Par.para_BsB_Is(Cnt.BsB_Is,:)=data(kk,:);
                phaseIndx(ic1)=6;
            elseif jmpLocSN==2
                disp('BsF-Is')
                Cnt.BsF_Is=Cnt.BsF_Is+1;
                Indx.BsF_Is_par(Cnt.BsF_Is,1)=kk;
                Par.para_BsF_Is(Cnt.BsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=7;
            elseif jmpLocSN==3
                disp('Is-BsB')
                Cnt.Is_BsB=Cnt.Is_BsB+1;
                Indx.Is_BsB_par(Cnt.Is_BsB,1)=kk;
                Par.para_Is_BsB(Cnt.Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=8;
            elseif jmpLocSN==4
                disp('Is-BsF')
                Cnt.Is_BsF=Cnt.Is_BsF+1;
                Indx.Is_BsF_par(Cnt.Is_BsF,1)=kk;
                Par.para_Is_BsF(Cnt.Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=9;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-Is')
                Cnt.InIs_Is=Cnt.InIs_Is+1;
                Indx.InIs_Is_par(Cnt.InIs_Is,1)=kk;
                Par.para_InIs_Is(Cnt.InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=10;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB')
                Cnt.DBsB=Cnt.DBsB+1;
                Indx.DBsB_par(Cnt.DBsB,1)=kk;
                Par.para_DBsB(Cnt.DBsB,:)=data(kk,:);
                phaseIndx(ic1)=11;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh')
                Cnt.InMsh=Cnt.InMsh+1;
                Indx.InMsh_par(Cnt.InMsh,1)=kk;
                Par.para_InMsh(Cnt.InMsh,:)=data(kk,:);
                phaseIndx(ic1)=12;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh')
                Cnt.Msh=Cnt.Msh+1;
                Indx.Msh_par(Cnt.Msh,1)=kk;
                Par.para_Msh(Cnt.Msh,:)=data(kk,:);
                phaseIndx(ic1)=13;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF')
                Cnt.DBsF=Cnt.DBsF+1;
                Indx.DBsF_par(Cnt.DBsF,1)=kk;
                Par.para_DBsF(Cnt.DBsF,:)=data(kk,:);
                phaseIndx(ic1)=14;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs')
                Cnt.Is_InIs=Cnt.Is_InIs+1;
                Indx.Is_InIs_par(Cnt.Is_InIs,1)=kk;
                Par.para_Is_InIs(Cnt.Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=15;
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB')
                Cnt.InIs_BsB=Cnt.InIs_BsB+1;
                Indx.InIs_BsB_par(Cnt.InIs_BsB,1)=kk;
                Par.para_InIs_BsB(Cnt.InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=16;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF')
                Cnt.InIs_BsF=Cnt.InIs_BsF+1;
                Indx.InIs_BsF_par(Cnt.InIs_BsF,1)=kk;
                Par.para_InIs_BsF(Cnt.InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=17;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs')
                Cnt.BsB_InIs=Cnt.BsB_InIs+1;
                Indx.BsB_InIs_par(Cnt.BsB_InIs,1)=kk;
                Par.para_BsB_InIs(Cnt.BsB_InIs,:)=data(kk,:);
                phaseIndx(ic1)=18;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs')
                Cnt.BsF_InIs=Cnt.BsF_InIs+1;
                Indx.BsF_InIs_par(Cnt.BsF_InIs,1)=kk;
                Par.para_BsF_InIs(Cnt.BsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=19;
            end
        elseif jmpN==4
            disp('DInIs')
            Cnt.DInIs=Cnt.DInIs+1;
            Indx.DInIs_par(Cnt.DInIs,1)=kk;
            Par.para_DInIs(Cnt.DInIs,:)=data(kk,:);
            phaseIndx(ic1)=20;
        end
    elseif (max(peaks_ss)==2 && (sum_diffss2==6))
        if jmpN==0
            disp('TIs')
            Cnt.TIs=Cnt.TIs+1;
            Indx.TIs_par(Cnt.TIs,1)=kk;
            Par.para_TIs(Cnt.TIs,:)=data(kk,:);
            phaseIndx(ic1)=21;
        elseif jmpN==1
            if jmpLocSN(1)==1
                disp('BsB-DIs')
                Cnt.BsB_DIs=Cnt.BsB_DIs+1;
                Indx.BsB_DIs_par(Cnt.BsB_DIs,1)=kk;
                Par.para_BsB_DIs(Cnt.BsB_DIs,:)=data(kk,:);
                phaseIndx(ic1)=22;
            elseif jmpLocSN(1)==2
                disp('BsF-DIs')
                Cnt.BsF_DIs=Cnt.BsF_DIs+1;
                Indx.BsF_DIs_par(Cnt.BsF_DIs,1)=kk;
                Par.para_BsF_DIs(Cnt.BsF_DIs,:)=data(kk,:);
                phaseIndx(ic1)=23;
            elseif jmpLocSN(1)==3
                disp('Is-BsB-Is')
                Cnt.Is_BsB_Is=Cnt.Is_BsB_Is+1;
                Indx.Is_BsB_Is_par(Cnt.Is_BsB_Is,1)=kk;
                Par.para_Is_BsB_Is(Cnt.Is_BsB_Is,:)=data(kk,:);
                phaseIndx(ic1)=24;
            elseif jmpLocSN(1)==4
                disp('Is-BsF-Is')
                Cnt.Is_BsF_Is=Cnt.Is_BsF_Is+1;
                Indx.Is_BsF_Is_par(Cnt.Is_BsF_Is,1)=kk;
                Par.para_Is_BsF_Is(Cnt.Is_BsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=25;
            elseif jmpLocSN(1)==5
                disp('DIs-BsB')
                Cnt.DIs_BsB=Cnt.DIs_BsB+1;
                Indx.DIs_BsB_par(Cnt.DIs_BsB,1)=kk;
                Par.para_DIs_BsB(Cnt.DIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=26;
            elseif jmpLocSN(1)==6
                disp('DIs-BsF')
                Cnt.DIs_BsF=Cnt.DIs_BsF+1;
                Indx.DIs_BsF_par(Cnt.DIs_BsF,1)=kk;
                Par.para_DIs_BsF(Cnt.DIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=27;
            end
        elseif jmpN==2
            if jmpLocSN(1)==1 && jmpLocSN(2)==2
                disp('InIs-DIs')
                Cnt.InIs_DIs=Cnt.InIs_DIs+1;
                Indx.InIs_DIs_par(Cnt.InIs_DIs,1)=kk;
                Par.para_InIs_DIs(Cnt.InIs_DIs,:)=data(kk,:);
                phaseIndx(ic1)=28;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3
                disp('DBsB-Is')
                Cnt.DBsB_Is=Cnt.DBsB_Is+1;
                Indx.DBsB_Is_par(Cnt.DBsB_Is,1)=kk;
                Par.para_DBsB_Is(Cnt.DBsB_Is,:)=data(kk,:);
                phaseIndx(ic1)=29;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
                disp('InMsh-Is')
                Cnt.InMsh_Is=Cnt.InMsh_Is+1;
                Indx.InMsh_Is_par(Cnt.InMsh_Is,1)=kk;
                Par.para_InMsh_Is(Cnt.InMsh_Is,:)=data(kk,:);
                phaseIndx(ic1)=30;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
                disp('BsB-Is-BsB')
                Cnt.BsB_Is_BsB=Cnt.BsB_Is_BsB+1;
                Indx.BsB_Is_BsB_par(Cnt.BsB_Is_BsB,1)=kk;
                Par.para_BsB_Is_BsB(Cnt.BsB_Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=31;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==6
                disp('BsB-Is-BsF')
                Cnt.BsB_Is_BsF=Cnt.BsB_Is_BsF+1;
                Indx.BsB_Is_BsF_par(Cnt.BsB_Is_BsF,1)=kk;
                Par.para_BsB_Is_BsF(Cnt.BsB_Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=32;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
                disp('Msh-Is')
                Cnt.Msh_Is=Cnt.Msh_Is+1;
                Indx.Msh_Is_par(Cnt.Msh_Is,1)=kk;
                Par.para_Msh_Is(Cnt.Msh_Is,:)=data(kk,:);
                phaseIndx(ic1)=33;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
                disp('DBsF-Is')
                Cnt.DBsF_Is=Cnt.DBsF_Is+1;
                Indx.DBsF_Is_par(Cnt.DBsF_Is,1)=kk;
                Par.para_DBsF_Is(Cnt.DBsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=34;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
                disp('BsF-Is-BsB')
                Cnt.BsF_Is_BsB=Cnt.BsF_Is_BsB+1;
                Indx.BsF_Is_BsB_par(Cnt.BsF_Is_BsB,1)=kk;
                Par.para_BsF_Is_BsB(Cnt.BsF_Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=35;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==6
                disp('BsF-Is-BsF')
                Cnt.BsF_Is_BsF=Cnt.BsF_Is_BsF+1;
                Indx.BsF_Is_BsF_par(Cnt.BsF_Is_BsF,1)=kk;
                Par.para_BsF_Is_BsF(Cnt.BsF_Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=36;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4
                disp('Is-InIs-Is')
                Cnt.Is_InIs_Is=Cnt.Is_InIs_Is+1;
                Indx.Is_InIs_Is_par(Cnt.Is_InIs_Is,1)=kk;
                Par.para_Is_InIs_Is(Cnt.Is_InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=37;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
                disp('Is-DBsB')
                Cnt.Is_DBsB=Cnt.Is_DBsB+1;
                Indx.Is_DBsB_par(Cnt.Is_DBsB,1)=kk;
                Par.para_Is_DBsB(Cnt.Is_DBsB,:)=data(kk,:);
                phaseIndx(ic1)=38;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==6
                disp('Is-InMsh')
                Cnt.Is_InMsh=Cnt.Is_InMsh+1;
                Indx.Is_InMsh_par(Cnt.Is_InMsh,1)=kk;
                Par.para_Is_InMsh(Cnt.Is_InMsh,:)=data(kk,:);
                phaseIndx(ic1)=39;
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
                disp('Is-Msh')
                Cnt.Is_Msh=Cnt.Is_Msh+1;
                Indx.Is_Msh_par(Cnt.Is_Msh,1)=kk;
                Par.para_Is_Msh(Cnt.Is_Msh,:)=data(kk,:);
                phaseIndx(ic1)=40;
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==6
                disp('Is-DBsF')
                Cnt.Is_DBsF=Cnt.Is_DBsF+1;
                Indx.Is_DBsF_par(Cnt.Is_DBsF,1)=kk;
                Par.para_Is_DBsF(Cnt.Is_DBsF,:)=data(kk,:);
                phaseIndx(ic1)=41;
            elseif jmpLocSN(1)==5 && jmpLocSN(2)==6
                disp('DIs-Is')
                Cnt.DIs_Is=Cnt.DIs_Is+1;
                Indx.DIs_Is_par(Cnt.DIs_Is,1)=kk;
                Par.para_DIs_Is(Cnt.DIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=42;
            end
        elseif jmpN==3
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
                disp('InIs-BsB-Is')
                Cnt.InIs_BsB_Is=Cnt.InIs_BsB_Is+1;
                Indx.InIs_BsB_Is_par(Cnt.InIs_BsB_Is,1)=kk;
                Par.para_InIs_BsB_Is(Cnt.InIs_BsB_Is,:)=data(kk,:);
                phaseIndx(ic1)=43;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
                disp('InIs-BsF-Is')
                Cnt.InIs_BsF_Is=Cnt.InIs_BsF_Is+1;
                Indx.InIs_BsF_Is_par(Cnt.InIs_BsF_Is,1)=kk;
                Par.para_InIs_BsF_Is(Cnt.InIs_BsF_Is,:)=data(kk,:);
                phaseIndx(ic1)=44;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5
                disp('InIs-Is-BsB')
                Cnt.InIs_Is_BsB=Cnt.InIs_Is_BsB+1;
                Indx.InIs_Is_BsB_par(Cnt.InIs_Is_BsB,1)=kk;
                Par.para_InIs_Is_BsB(Cnt.InIs_Is_BsB,:)=data(kk,:);
                phaseIndx(ic1)=45;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==6
                disp('InIs-Is-BsF')
                Cnt.InIs_Is_BsF=Cnt.InIs_Is_BsF+1;
                Indx.InIs_Is_BsF_par(Cnt.InIs_Is_BsF,1)=kk;
                Par.para_InIs_Is_BsF(Cnt.InIs_Is_BsF,:)=data(kk,:);
                phaseIndx(ic1)=46;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsB-InIs-Is')
                Cnt.BsB_InIs_Is=Cnt.BsB_InIs_Is+1;
                Indx.BsB_InIs_Is_par(Cnt.BsB_InIs_Is,1)=kk;
                Par.para_BsB_InIs_Is(Cnt.BsB_InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=47;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('TBsB')
                Cnt.TBsB=Cnt.TBsB+1;
                Indx.TBsB_par(Cnt.TBsB,1)=kk;
                Par.para_TBsB(Cnt.TBsB,:)=data(kk,:);
                phaseIndx(ic1)=48;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==6
                disp('BsB-InMsh')
                Cnt.BsB_InMsh=Cnt.BsB_InMsh+1;
                Indx.BsB_InMsh_par(Cnt.BsB_InMsh,1)=kk;
                Par.para_BsB_InMsh(Cnt.BsB_InMsh,:)=data(kk,:);
                phaseIndx(ic1)=49;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('InMsh-BsB')
                Cnt.InMsh_BsB=Cnt.InMsh_BsB+1;
                Indx.InMsh_BsB_par(Cnt.InMsh_BsB,1)=kk;
                Par.para_InMsh_BsB(Cnt.InMsh_BsB,:)=data(kk,:);
                phaseIndx(ic1)=50;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('InMsh-BsF')
                Cnt.InMsh_BsF=Cnt.InMsh_BsF+1;
                Indx.InMsh_BsF_par(Cnt.InMsh_BsF,1)=kk;
                Par.para_InMsh_BsF(Cnt.InMsh_BsF,:)=data(kk,:);
                phaseIndx(ic1)=51;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('BsB-Is-InIs')
                Cnt.BsB_Is_InIs=Cnt.BsB_Is_InIs+1;
                Indx.BsB_Is_InIs_par(Cnt.BsB_Is_InIs,1)=kk;
                Par.para_BsB_Is_InIs(Cnt.BsB_Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=52;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
                disp('BsF-InIs-Is')
                Cnt.BsF_InIs_Is=Cnt.BsF_InIs_Is+1;
                Indx.BsF_InIs_Is_par(Cnt.BsF_InIs_Is,1)=kk;
                Par.para_BsF_InIs_Is(Cnt.BsF_InIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=53;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
                disp('Msh-BsB')
                Cnt.Msh_BsB=Cnt.Msh_BsB+1;
                Indx.Msh_BsB_par(Cnt.Msh_BsB,1)=kk;
                Par.para_Msh_BsB(Cnt.Msh_BsB,:)=data(kk,:);
                phaseIndx(ic1)=54;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==6
                disp('Msh-BsF')
                Cnt.Msh_BsF=Cnt.Msh_BsF+1;
                Indx.Msh_BsF_par(Cnt.Msh_BsF,1)=kk;
                Par.para_Msh_BsF(Cnt.Msh_BsF,:)=data(kk,:);
                phaseIndx(ic1)=55;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('BsF-Msh')
                Cnt.BsF_Msh=Cnt.BsF_Msh+1;
                Indx.BsF_Msh_par(Cnt.BsF_Msh,1)=kk;
                Par.para_BsF_Msh(Cnt.BsF_Msh,:)=data(kk,:);
                phaseIndx(ic1)=56;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('TBsF')
                Cnt.TBsF=Cnt.TBsF+1;
                Indx.TBsF_par(Cnt.TBsF,1)=kk;
                Par.para_TBsF(Cnt.TBsF,:)=data(kk,:);
                phaseIndx(ic1)=57;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('BsF-Is-InIs')
                Cnt.BsF_Is_InIs=Cnt.BsF_Is_InIs+1;
                Indx.BsF_Is_InIs_par(Cnt.BsF_Is_InIs,1)=kk;
                Par.para_BsF_Is_InIs(Cnt.BsF_Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=58;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5
                disp('Is-InIs-BsB')
                Cnt.Is_InIs_BsB=Cnt.Is_InIs_BsB+1;
                Indx.Is_InIs_BsB_par(Cnt.Is_InIs_BsB,1)=kk;
                Par.para_Is_InIs_BsB(Cnt.Is_InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=59;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==6
                disp('Is-InIs-BsF')
                Cnt.Is_InIs_BsF=Cnt.Is_InIs_BsF+1;
                Indx.Is_InIs_BsF_par(Cnt.Is_InIs_BsF,1)=kk;
                Par.para_Is_InIs_BsF(Cnt.Is_InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=60;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('Is-BsB-InIs')
                Cnt.Is_BsB_InIs=Cnt.Is_BsB_InIs+1;
                Indx.Is_BsB_InIs_par(Cnt.Is_BsB_InIs,1)=kk;
                Par.para_Is_BsB_InIs(Cnt.Is_BsB_InIs,:)=data(kk,:);
                phaseIndx(ic1)=61;
            elseif jmpLocSN(1)==4 && jmpLocSN(2)==5 && jmpLocSN(3)==6
                disp('Is-BsF-InIs')
                Cnt.Is_BsF_InIs=Cnt.Is_BsF_InIs+1;
                Indx.Is_BsF_InIs_par(Cnt.Is_BsF_InIs,1)=kk;
                Par.para_Is_BsF_InIs(Cnt.Is_BsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=62;
            end
        elseif jmpN==4
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4
                disp('DInIs-Is')
                Cnt.DInIs_Is=Cnt.DInIs_Is+1;
                Indx.DInIs_Is_par(Cnt.DInIs_Is,1)=kk;
                Par.para_DInIs_Is(Cnt.DInIs_Is,:)=data(kk,:);
                phaseIndx(ic1)=63;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5
                disp('InIs-DBsB')
                Cnt.InIs_DBsB=Cnt.InIs_DBsB+1;
                Indx.InIs_DBsB_par(Cnt.InIs_DBsB,1)=kk;
                Par.para_InIs_DBsB(Cnt.InIs_DBsB,:)=data(kk,:);
                phaseIndx(ic1)=64;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==6
                disp('InIs-InMsh')
                Cnt.InIs_InMsh=Cnt.InIs_InMsh+1;
                Indx.InIs_InMsh_par(Cnt.InIs_InMsh,1)=kk;
                Par.para_InIs_InMsh(Cnt.InIs_InMsh,:)=data(kk,:);
                phaseIndx(ic1)=65;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('InIs-Msh')
                Cnt.InIs_Msh=Cnt.InIs_Msh+1;
                Indx.InIs_Msh_par(Cnt.InIs_Msh,1)=kk;
                Par.para_InIs_Msh(Cnt.InIs_Msh,:)=data(kk,:);
                phaseIndx(ic1)=66;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('InIs-DBsF')
                Cnt.InIs_DBsF=Cnt.InIs_DBsF+1;
                Indx.InIs_DBsF_par(Cnt.InIs_DBsF,1)=kk;
                Par.para_InIs_DBsF(Cnt.InIs_DBsF,:)=data(kk,:);
                phaseIndx(ic1)=67;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('InIs-Is-InIs')
                Cnt.InIs_Is_InIs=Cnt.InIs_Is_InIs+1;
                Indx.InIs_Is_InIs_par(Cnt.InIs_Is_InIs,1)=kk;
                Par.para_InIs_Is_InIs(Cnt.InIs_Is_InIs,:)=data(kk,:);
                phaseIndx(ic1)=68;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('BsB-InIs-BsB')
                Cnt.BsB_InIs_BsB=Cnt.BsB_InIs_BsB+1;
                Indx.BsB_InIs_BsB_par(Cnt.BsB_InIs_BsB,1)=kk;
                Par.para_BsB_InIs_BsB(Cnt.BsB_InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=69;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('BsB-InIs-BsF')
                Cnt.BsB_InIs_BsF=Cnt.BsB_InIs_BsF+1;
                Indx.BsB_InIs_BsF_par(Cnt.BsB_InIs_BsF,1)=kk;
                Par.para_BsB_InIs_BsF(Cnt.BsB_InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=70;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('DBsB-InIs')
                Cnt.DBsB_InIs=Cnt.DBsB_InIs+1;
                Indx.DBsB_InIs_par(Cnt.DBsB_InIs,1)=kk;
                Par.para_DBsB_InIs(Cnt.DBsB_InIs,:)=data(kk,:);
                phaseIndx(ic1)=71;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('InMsh-InIs')
                Cnt.InMsh_InIs=Cnt.InMsh_InIs+1;
                Indx.InMsh_InIs_par(Cnt.InMsh_InIs,1)=kk;
                Par.para_InMsh_InIs(Cnt.InMsh_InIs,:)=data(kk,:);
                phaseIndx(ic1)=72;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
                disp('BsF-InIs-BsB')
                Cnt.BsF_InIs_BsB=Cnt.BsF_InIs_BsB+1;
                Indx.BsF_InIs_BsB_par(Cnt.BsF_InIs_BsB,1)=kk;
                Par.para_BsF_InIs_BsB(Cnt.BsF_InIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=73;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
                disp('BsF-InIs-BsF')
                Cnt.BsF_InIs_BsF=Cnt.BsF_InIs_BsF+1;
                Indx.BsF_InIs_BsF_par(Cnt.BsF_InIs_BsF,1)=kk;
                Par.para_BsF_InIs_BsF(Cnt.BsF_InIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=74;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('Msh-InIs')
                Cnt.Msh_InIs=Cnt.Msh_InIs+1;
                Indx.Msh_InIs_par(Cnt.Msh_InIs,1)=kk;
                Par.para_Msh_InIs(Cnt.Msh_InIs,:)=data(kk,:);
                phaseIndx(ic1)=75;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('DBsF-InIs')
                Cnt.DBsF_InIs=Cnt.DBsF_InIs+1;
                Indx.DBsF_InIs_par(Cnt.DBsF_InIs,1)=kk;
                Par.para_DBsF_InIs(Cnt.DBsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=76;
            elseif jmpLocSN(1)==3 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
                disp('Is-DInIs')
                Cnt.Is_DInIs=Cnt.Is_DInIs+1;
                Indx.Is_DInIs_par(Cnt.Is_DInIs,1)=kk;
                Par.para_Is_DInIs(Cnt.Is_DInIs,:)=data(kk,:);
                phaseIndx(ic1)=77;
            end
        elseif jmpN==5
            if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4 && jmpLocSN(5)==5
                disp('DInIs-BsB')
                Cnt.DInIs_BsB=Cnt.DInIs_BsB+1;
                Indx.DInIs_BsB_par(Cnt.DInIs_BsB,1)=kk;
                Par.para_DInIs_BsB(Cnt.DInIs_BsB,:)=data(kk,:);
                phaseIndx(ic1)=78;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==4 && jmpLocSN(5)==6
                disp('DInIs-BsF')
                Cnt.DInIs_BsF=Cnt.DInIs_BsF+1;
                Indx.DInIs_BsF_par(Cnt.DInIs_BsF,1)=kk;
                Par.para_DInIs_BsF(Cnt.DInIs_BsF,:)=data(kk,:);
                phaseIndx(ic1)=79;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('InIs-BsB-InIs')
                Cnt.InIs_BsB_InIs=Cnt.InIs_BsB_InIs+1;
                Indx.InIs_BsB_InIs_par(Cnt.InIs_BsB_InIs,1)=kk;
                Par.para_InIs_BsB_InIs(Cnt.InIs_BsB_InIs,:)=data(kk,:);
                phaseIndx(ic1)=80;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('InIs-BsF-InIs')
                Cnt.InIs_BsF_InIs=Cnt.InIs_BsF_InIs+1;
                Indx.InIs_BsF_InIs_par(Cnt.InIs_BsF_InIs,1)=kk;
                Par.para_InIs_BsF_InIs(Cnt.InIs_BsF_InIs,:)=data(kk,:);
                phaseIndx(ic1)=81;
            elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('BsB-DInIs')
                Cnt.BsB_DInIs=Cnt.BsB_DInIs+1;
                Indx.BsB_DInIs_par(Cnt.BsB_DInIs,1)=kk;
                Par.para_BsB_DInIs(Cnt.BsB_DInIs,:)=data(kk,:);
                phaseIndx(ic1)=82;
            elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5 && jmpLocSN(5)==6
                disp('BsF-DInIs')
                Cnt.BsF_DInIs=Cnt.BsF_DInIs+1;
                Indx.BsF_DInIs_par(Cnt.BsF_DInIs,1)=kk;
                Par.para_BsF_DInIs(Cnt.BsF_DInIs,:)=data(kk,:);
                phaseIndx(ic1)=83;
            end
        elseif jmpN==6
            disp('TInIs')
            Cnt.TInIs=Cnt.TInIs+1;
            Indx.TInIs_par(Cnt.TInIs,1)=kk;
            Par.para_TInIs(Cnt.TInIs,:)=data(kk,:);
            phaseIndx(ic1)=84;
        end
    end
end

if isempty(Cnt)
    Cnt.Unkown=1;
elseif isempty(Indx)
    Indx.Unkown=1;
elseif isempty(Par)
    Par.Unkown=1;
end