% *************************************************************************
% This function plos the counts and occurrence probabilities of a group of 
% 14 reversible switches
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function plot_counts_14BS(ppMISA_OR_14BS)

BS_1R={'Is', 'Bs', 'InIs'};

BS_2R={'DIs', 'Msh', 'InMsh', 'Bs-Is', 'DBs', 'Bs-InIs'};

BS_3R={'DBs-Is', 'Is-Msh', 'Bs-Msh', 'DBs-InIs', 'InIs-Msh'};

total_14BS=sum(ppMISA_OR_14BS.total_14BS);

% Counts plot of bistable switches
figure(3)
subplot(131)
barh(ppMISA_OR_14BS.total_14BS(1:3))
set(gca,'Ytick',[1:3],'YtickLabel',BS_1R,'YTickLabelRotation',30)
title('BS switch: one bistable region')
xlabel('Count','Fontsize',14)

subplot(132)
barh(ppMISA_OR_14BS.total_14BS(4:9))
set(gca,'Ytick',[1:6],'YtickLabel',BS_2R,'YTickLabelRotation',30)
title('BS switch: two bistable regions')
xlabel('Count','Fontsize',14)

subplot(133)
barh(ppMISA_OR_14BS.total_14BS(10:14))
set(gca,'Ytick',[1:5],'YtickLabel',BS_3R,'YTickLabelRotation',30)
title('BS switch: three bistable regions')
xlabel('Count','Fontsize',14)

% Probability plot of bistable switches
figure(4)
subplot(131)
barh((ppMISA_OR_14BS.total_14BS(1:3)/total_14BS)*100)
set(gca,'Ytick',[1:3],'YtickLabel',BS_1R,'YTickLabelRotation',30)
title('BS switch: one bistable region')
xlabel({'% chance'},'Fontsize',12)

subplot(132)
barh((ppMISA_OR_14BS.total_14BS(4:9)/total_14BS)*100)
set(gca,'Ytick',[1:6],'YtickLabel',BS_2R,'YTickLabelRotation',30)
title('BS switch: two bistable regions')
xlabel({'% chance'},'Fontsize',12)

subplot(133)
barh((ppMISA_OR_14BS.total_14BS(10:14)/total_14BS)*100)
set(gca,'Ytick',[1:5],'YtickLabel',BS_3R,'YTickLabelRotation',30)
title('BS switch: three bistable regions')
xlabel({'% chance'},'Fontsize',12)