% *************************************************************************
% This function creates a group of 14 reversible bistable switches from a
% group of 84 reversible switches
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [Cnt,Indx,Par,phaseIndx]=BS_switchSegregation_14BS(kk,ic1,data,peaks_ss,sum_diffss2,jmpN,jmpLocSN,Cnt,Indx,Par)

if (max(peaks_ss)==2 && (sum_diffss2==2))
    if jmpN==0
        disp('Is')
        Cnt.Is=Cnt.Is+1;
        Indx.Is_par(Cnt.Is,1)=kk;
        Par.Par.para_Is(Cnt.Is,:)=data(kk,:);
        phaseIndx(ic1)=1;
    elseif jmpN==1
        if jmpLocSN(1)==1
            disp('BsB')
            Cnt.BsB=Cnt.BsB+1;
            Indx.BsB_par(Cnt.BsB,1)=kk;
            Par.para_BsB(Cnt.BsB,:)=data(kk,:);
            phaseIndx(ic1)=2;
        elseif jmpLocSN(1)==2
            disp('BsF')
            Cnt.BsF=Cnt.BsF+1;
            Indx.BsF_par(Cnt.BsF,1)=kk;
            Par.para_BsF(Cnt.BsF,:)=data(kk,:);
            phaseIndx(ic1)=3;
        end
    elseif jmpN==2
        disp('InIs')
        Cnt.InIs=Cnt.InIs+1;
        Indx.InIs_par(Cnt.InIs,1)=kk;
        Par.para_InIs(Cnt.InIs,:)=data(kk,:);
        phaseIndx(ic1)=4;
    end
elseif (max(peaks_ss)==2 && (sum_diffss2==4))
    if jmpN==0
        disp('DIs')
        Cnt.DIs=Cnt.DIs+1;
        Indx.DIs_par(Cnt.DIs,1)=kk;
        Par.para_DIs(Cnt.DIs,:)=data(kk,:);
        phaseIndx(ic1)=5;
    elseif jmpN==1
        if jmpLocSN==1
            disp('BsB-Is')
            Cnt.BsB_Is=Cnt.BsB_Is+1;
            Indx.BsB_Is_par(Cnt.BsB_Is,1)=kk;
            Par.para_BsB_Is(Cnt.BsB_Is,:)=data(kk,:);
            phaseIndx(ic1)=6;
        elseif jmpLocSN==2
            disp('BsF-Is')
            Cnt.BsF_Is=Cnt.BsF_Is+1;
            Indx.BsF_Is_par(Cnt.BsF_Is,1)=kk;
            Par.para_BsF_Is(Cnt.BsF_Is,:)=data(kk,:);
            phaseIndx(ic1)=7;
        elseif jmpLocSN==3
            disp('Is-BsB')
            Cnt.Is_BsB=Cnt.Is_BsB+1;
            Indx.Is_BsB_par(Cnt.Is_BsB,1)=kk;
            Par.para_Is_BsB(Cnt.Is_BsB,:)=data(kk,:);
            phaseIndx(ic1)=8;
        elseif jmpLocSN==4
            disp('Is-BsF')
            Cnt.Is_BsF=Cnt.Is_BsF+1;
            Indx.Is_BsF_par(Cnt.Is_BsF,1)=kk;
            Par.para_Is_BsF(Cnt.Is_BsF,:)=data(kk,:);
            phaseIndx(ic1)=9;
        end
    elseif jmpN==2
        if jmpLocSN(1)==1 && jmpLocSN(2)==3
            disp('DBsB')
            Cnt.DBsB=Cnt.DBsB+1;
            Indx.DBsB_par(Cnt.DBsB,1)=kk;
            Par.para_DBsB(Cnt.DBsB,:)=data(kk,:);
            phaseIndx(ic1)=11;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
            disp('InMsh')
            Cnt.InMsh=Cnt.InMsh+1;
            Indx.InMsh_par(Cnt.InMsh,1)=kk;
            Par.para_InMsh(Cnt.InMsh,:)=data(kk,:);
            phaseIndx(ic1)=12;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
            disp('Msh')
            Cnt.Msh=Cnt.Msh+1;
            Indx.Msh_par(Cnt.Msh,1)=kk;
            Par.para_Msh(Cnt.Msh,:)=data(kk,:);
            phaseIndx(ic1)=13;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
            disp('DBsF')
            Cnt.DBsF=Cnt.DBsF+1;
            Indx.DBsF_par(Cnt.DBsF,1)=kk;
            Par.para_DBsF(Cnt.DBsF,:)=data(kk,:);
            phaseIndx(ic1)=14;
        end
    elseif jmpN==3
        if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3
            disp('InIs-BsB')
            Cnt.InIs_BsB=Cnt.InIs_BsB+1;
            Indx.InIs_BsB_par(Cnt.InIs_BsB,1)=kk;
            Par.para_InIs_BsB(Cnt.InIs_BsB,:)=data(kk,:);
            phaseIndx(ic1)=16;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4
            disp('InIs-BsF')
            Cnt.InIs_BsF=Cnt.InIs_BsF+1;
            Indx.InIs_BsF_par(Cnt.InIs_BsF,1)=kk;
            Par.para_InIs_BsF(Cnt.InIs_BsF,:)=data(kk,:);
            phaseIndx(ic1)=17;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4
            disp('BsB-InIs')
            Cnt.BsB_InIs=Cnt.BsB_InIs+1;
            Indx.BsB_InIs_par(Cnt.BsB_InIs,1)=kk;
            Par.para_BsB_InIs(Cnt.BsB_InIs,:)=data(kk,:);
            phaseIndx(ic1)=18;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4
            disp('BsF-InIs')
            Cnt.BsF_InIs=Cnt.BsF_InIs+1;
            Indx.BsF_InIs_par(Cnt.BsF_InIs,1)=kk;
            Par.para_BsF_InIs(Cnt.BsF_InIs,:)=data(kk,:);
            phaseIndx(ic1)=19;
        end
    end
elseif (max(peaks_ss)==2 && (sum_diffss2==6))
    if jmpN==2
        if jmpLocSN(1)==1 && jmpLocSN(2)==3
            disp('DBsB-Is')
            Cnt.DBsB_Is=Cnt.DBsB_Is+1;
            Indx.DBsB_Is_par(Cnt.DBsB_Is,1)=kk;
            Par.para_DBsB_Is(Cnt.DBsB_Is,:)=data(kk,:);
            phaseIndx(ic1)=29;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==4
            disp('InMsh-Is')
            Cnt.InMsh_Is=Cnt.InMsh_Is+1;
            Indx.InMsh_Is_par(Cnt.InMsh_Is,1)=kk;
            Par.para_InMsh_Is(Cnt.InMsh_Is,:)=data(kk,:);
            phaseIndx(ic1)=30;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==5
            disp('BsB-Is-BsB')
            Cnt.BsB_Is_BsB=Cnt.BsB_Is_BsB+1;
            Indx.BsB_Is_BsB_par(Cnt.BsB_Is_BsB,1)=kk;
            Par.para_BsB_Is_BsB(Cnt.BsB_Is_BsB,:)=data(kk,:);
            phaseIndx(ic1)=31;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==6
            disp('BsB-Is-BsF')
            Cnt.BsB_Is_BsF=Cnt.BsB_Is_BsF+1;
            Indx.BsB_Is_BsF_par(Cnt.BsB_Is_BsF,1)=kk;
            Par.para_BsB_Is_BsF(Cnt.BsB_Is_BsF,:)=data(kk,:);
            phaseIndx(ic1)=32;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3
            disp('Msh-Is')
            Cnt.Msh_Is=Cnt.Msh_Is+1;
            Indx.Msh_Is_par(Cnt.Msh_Is,1)=kk;
            Par.para_Msh_Is(Cnt.Msh_Is,:)=data(kk,:);
            phaseIndx(ic1)=33;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==4
            disp('DBsF-Is')
            Cnt.DBsF_Is=Cnt.DBsF_Is+1;
            Indx.DBsF_Is_par(Cnt.DBsF_Is,1)=kk;
            Par.para_DBsF_Is(Cnt.DBsF_Is,:)=data(kk,:);
            phaseIndx(ic1)=34;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==5
            disp('BsF-Is-BsB')
            Cnt.BsF_Is_BsB=Cnt.BsF_Is_BsB+1;
            Indx.BsF_Is_BsB_par(Cnt.BsF_Is_BsB,1)=kk;
            Par.para_BsF_Is_BsB(Cnt.BsF_Is_BsB,:)=data(kk,:);
            phaseIndx(ic1)=35;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==6
            disp('BsF-Is-BsF')
            Cnt.BsF_Is_BsF=Cnt.BsF_Is_BsF+1;
            Indx.BsF_Is_BsF_par(Cnt.BsF_Is_BsF,1)=kk;
            Par.para_BsF_Is_BsF(Cnt.BsF_Is_BsF,:)=data(kk,:);
            phaseIndx(ic1)=36;
        elseif jmpLocSN(1)==3 && jmpLocSN(2)==5
            disp('Is-DBsB')
            Cnt.Is_DBsB=Cnt.Is_DBsB+1;
            Indx.Is_DBsB_par(Cnt.Is_DBsB,1)=kk;
            Par.para_Is_DBsB(Cnt.Is_DBsB,:)=data(kk,:);
            phaseIndx(ic1)=38;
        elseif jmpLocSN(1)==3 && jmpLocSN(2)==6
            disp('Is-InMsh')
            Cnt.Is_InMsh=Cnt.Is_InMsh+1;
            Indx.Is_InMsh_par(Cnt.Is_InMsh,1)=kk;
            Par.para_Is_InMsh(Cnt.Is_InMsh,:)=data(kk,:);
            phaseIndx(ic1)=39;
        elseif jmpLocSN(1)==4 && jmpLocSN(2)==5
            disp('Is-Msh')
            Cnt.Is_Msh=Cnt.Is_Msh+1;
            Indx.Is_Msh_par(Cnt.Is_Msh,1)=kk;
            Par.para_Is_Msh(Cnt.Is_Msh,:)=data(kk,:);
            phaseIndx(ic1)=40;
        elseif jmpLocSN(1)==4 && jmpLocSN(2)==6
            disp('Is-DBsF')
            Cnt.Is_DBsF=Cnt.Is_DBsF+1;
            Indx.Is_DBsF_par(Cnt.Is_DBsF,1)=kk;
            Par.para_Is_DBsF(Cnt.Is_DBsF,:)=data(kk,:);
            phaseIndx(ic1)=41;
        end
    elseif jmpN==3
        if jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==6
            disp('BsB-InMsh')
            Cnt.BsB_InMsh=Cnt.BsB_InMsh+1;
            Indx.BsB_InMsh_par(Cnt.BsB_InMsh,1)=kk;
            Par.para_BsB_InMsh(Cnt.BsB_InMsh,:)=data(kk,:);
            phaseIndx(ic1)=49;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5
            disp('InMsh-BsB')
            Cnt.InMsh_BsB=Cnt.InMsh_BsB+1;
            Indx.InMsh_BsB_par(Cnt.InMsh_BsB,1)=kk;
            Par.para_InMsh_BsB(Cnt.InMsh_BsB,:)=data(kk,:);
            phaseIndx(ic1)=50;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==6
            disp('InMsh-BsF')
            Cnt.InMsh_BsF=Cnt.InMsh_BsF+1;
            Indx.InMsh_BsF_par(Cnt.InMsh_BsF,1)=kk;
            Par.para_InMsh_BsF(Cnt.InMsh_BsF,:)=data(kk,:);
            phaseIndx(ic1)=51;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5
            disp('Msh-BsB')
            Cnt.Msh_BsB=Cnt.Msh_BsB+1;
            Indx.Msh_BsB_par(Cnt.Msh_BsB,1)=kk;
            Par.para_Msh_BsB(Cnt.Msh_BsB,:)=data(kk,:);
            phaseIndx(ic1)=54;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==6
            disp('Msh-BsF')
            Cnt.Msh_BsF=Cnt.Msh_BsF+1;
            Indx.Msh_BsF_par(Cnt.Msh_BsF,1)=kk;
            Par.para_Msh_BsF(Cnt.Msh_BsF,:)=data(kk,:);
            phaseIndx(ic1)=55;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5
            disp('BsF-Msh')
            Cnt.BsF_Msh=Cnt.BsF_Msh+1;
            Indx.BsF_Msh_par(Cnt.BsF_Msh,1)=kk;
            Par.para_BsF_Msh(Cnt.BsF_Msh,:)=data(kk,:);
            phaseIndx(ic1)=56;
        end
    elseif jmpN==4
        if jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==5
            disp('InIs-DBsB')
            Cnt.InIs_DBsB=Cnt.InIs_DBsB+1;
            Indx.InIs_DBsB_par(Cnt.InIs_DBsB,1)=kk;
            Par.para_InIs_DBsB(Cnt.InIs_DBsB,:)=data(kk,:);
            phaseIndx(ic1)=64;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==3 && jmpLocSN(4)==6
            disp('InIs-InMsh')
            Cnt.InIs_InMsh=Cnt.InIs_InMsh+1;
            Indx.InIs_InMsh_par(Cnt.InIs_InMsh,1)=kk;
            Par.para_InIs_InMsh(Cnt.InIs_InMsh,:)=data(kk,:);
            phaseIndx(ic1)=65;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==5
            disp('InIs-Msh')
            Cnt.InIs_Msh=Cnt.InIs_Msh+1;
            Indx.InIs_Msh_par(Cnt.InIs_Msh,1)=kk;
            Par.para_InIs_Msh(Cnt.InIs_Msh,:)=data(kk,:);
            phaseIndx(ic1)=66;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==2 && jmpLocSN(3)==4 && jmpLocSN(4)==6
            disp('InIs-DBsF')
            Cnt.InIs_DBsF=Cnt.InIs_DBsF+1;
            Indx.InIs_DBsF_par(Cnt.InIs_DBsF,1)=kk;
            Par.para_InIs_DBsF(Cnt.InIs_DBsF,:)=data(kk,:);
            phaseIndx(ic1)=67;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
            disp('BsB-InIs-BsB')
            Cnt.BsB_InIs_BsB=Cnt.BsB_InIs_BsB+1;
            Indx.BsB_InIs_BsB_par(Cnt.BsB_InIs_BsB,1)=kk;
            Par.para_BsB_InIs_BsB(Cnt.BsB_InIs_BsB,:)=data(kk,:);
            phaseIndx(ic1)=69;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
            disp('BsB-InIs-BsF')
            Cnt.BsB_InIs_BsF=Cnt.BsB_InIs_BsF+1;
            Indx.BsB_InIs_BsF_par(Cnt.BsB_InIs_BsF,1)=kk;
            Par.para_BsB_InIs_BsF(Cnt.BsB_InIs_BsF,:)=data(kk,:);
            phaseIndx(ic1)=70;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
            disp('DBsB-InIs')
            Cnt.DBsB_InIs=Cnt.DBsB_InIs+1;
            Indx.DBsB_InIs_par(Cnt.DBsB_InIs,1)=kk;
            Par.para_DBsB_InIs(Cnt.DBsB_InIs,:)=data(kk,:);
            phaseIndx(ic1)=71;
        elseif jmpLocSN(1)==1 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
            disp('InMsh-InIs')
            Cnt.InMsh_InIs=Cnt.InMsh_InIs+1;
            Indx.InMsh_InIs_par(Cnt.InMsh_InIs,1)=kk;
            Par.para_InMsh_InIs(Cnt.InMsh_InIs,:)=data(kk,:);
            phaseIndx(ic1)=72;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==5
            disp('BsF-InIs-BsB')
            Cnt.BsF_InIs_BsB=Cnt.BsF_InIs_BsB+1;
            Indx.BsF_InIs_BsB_par(Cnt.BsF_InIs_BsB,1)=kk;
            Par.para_BsF_InIs_BsB(Cnt.BsF_InIs_BsB,:)=data(kk,:);
            phaseIndx(ic1)=73;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==4 && jmpLocSN(4)==6
            disp('BsF-InIs-BsF')
            Cnt.BsF_InIs_BsF=Cnt.BsF_InIs_BsF+1;
            Indx.BsF_InIs_BsF_par(Cnt.BsF_InIs_BsF,1)=kk;
            Par.para_BsF_InIs_BsF(Cnt.BsF_InIs_BsF,:)=data(kk,:);
            phaseIndx(ic1)=74;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==3 && jmpLocSN(3)==5 && jmpLocSN(4)==6
            disp('Msh-InIs')
            Cnt.Msh_InIs=Cnt.Msh_InIs+1;
            Indx.Msh_InIs_par(Cnt.Msh_InIs,1)=kk;
            Par.para_Msh_InIs(Cnt.Msh_InIs,:)=data(kk,:);
            phaseIndx(ic1)=75;
        elseif jmpLocSN(1)==2 && jmpLocSN(2)==4 && jmpLocSN(3)==5 && jmpLocSN(4)==6
            disp('DBsF-InIs')
            Cnt.DBsF_InIs=Cnt.DBsF_InIs+1;
            Indx.DBsF_InIs_par(Cnt.DBsF_InIs,1)=kk;
            Par.para_DBsF_InIs(Cnt.DBsF_InIs,:)=data(kk,:);
            phaseIndx(ic1)=76;
        end
    end
end