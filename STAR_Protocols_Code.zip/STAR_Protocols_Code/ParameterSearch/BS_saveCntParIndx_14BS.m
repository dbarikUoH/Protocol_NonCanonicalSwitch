% *************************************************************************
% Function to save the counts of 14 bistable switches obtained from groping
% of topologically similar switches. The parameters are also grouped.
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [ppMISA_OR_14BS]=BS_saveCntParIndx_14BS(Cnt,Par)

tot_Is=Cnt.Is;
% Bistable switch
tot_Bs=Cnt.BsB+Cnt.BsF;

tot_InIs=Cnt.InIs;
tot_DIs=Cnt.DIs;
tot_Msh=Cnt.Msh;
tot_InMsh=Cnt.InMsh;
% Bistable-Isola
tot_BsIs=Cnt.BsB_Is+Cnt.BsF_Is+Cnt.Is_BsB+Cnt.Is_BsF;
% Dual bistable
tot_DBs=Cnt.DBsB+Cnt.DBsF;
% Bistable-Inverted Isola
tot_BsInIs=Cnt.InIs_BsB+Cnt.InIs_BsF+Cnt.BsB_InIs+Cnt.BsF_InIs;
% Dual bistbale-Isola
tot_DBsIs=Cnt.DBsB_Is+Cnt.BsB_Is_BsB+Cnt.DBsF_Is+Cnt.BsF_Is_BsF+Cnt.Is_DBsB+Cnt.Is_DBsF;
% Isola-Mushroom
tot_IsMsh=Cnt.InMsh_Is+Cnt.BsB_Is_BsF+Cnt.Msh_Is+Cnt.BsF_Is_BsB+Cnt.Is_InMsh+Cnt.Is_Msh;
% Bistable-Mushroom
tot_BsMsh=Cnt.BsB_InMsh+Cnt.InMsh_BsB+Cnt.InMsh_BsF+Cnt.Msh_BsB+Cnt.Msh_BsF+Cnt.BsF_Msh;
% Dual bistbale-Inverted Isola
tot_DBsInIs=Cnt.InIs_DBsB+Cnt.InIs_DBsF+Cnt.BsB_InIs_BsB+Cnt.DBsB_InIs+Cnt.BsF_InIs_BsF+Cnt.DBsF_InIs;
% Inverted Isola-Mushroom
tot_InIsMsh=Cnt.InIs_InMsh+Cnt.InIs_Msh+Cnt.BsB_InIs_BsF+Cnt.InMsh_InIs+Cnt.BsF_InIs_BsB+Cnt.Msh_InIs;

ppMISA_OR_14BS.total_14BS=[tot_Is tot_Bs tot_InIs tot_DIs tot_Msh tot_InMsh ...
    tot_BsIs tot_DBs tot_BsInIs tot_DBsIs tot_IsMsh tot_BsMsh tot_DBsInIs ...
    tot_InIsMsh];
ppMISA_OR_14BS.total_Is=tot_Is;
ppMISA_OR_14BS.total_Bs=tot_Bs;
ppMISA_OR_14BS.total_InIs=tot_InIs;
ppMISA_OR_14BS.total_DIs=tot_DIs;
ppMISA_OR_14BS.total_Msh=tot_Msh;
ppMISA_OR_14BS.total_InMsh=tot_InMsh;
ppMISA_OR_14BS.total_BsIs=tot_BsIs;
ppMISA_OR_14BS.total_DBs=tot_DBs;
ppMISA_OR_14BS.total_BsInIs=tot_BsInIs;
ppMISA_OR_14BS.total_DBsIs=tot_DBsIs;
ppMISA_OR_14BS.total_IsMsh=tot_IsMsh;
ppMISA_OR_14BS.total_BsMsh=tot_BsMsh;
ppMISA_OR_14BS.total_DBsInIs=tot_DBsInIs;
ppMISA_OR_14BS.total_InIsMsh=tot_InIsMsh;

ppMISA_OR_14BS.para_Is=Par.para_Is;
% parameters Bistable switch
ppMISA_OR_14BS.para_Bs=[Par.para_BsB; Par.para_BsF];

ppMISA_OR_14BS.para_InIs=Par.para_InIs;
ppMISA_OR_14BS.para_DIs=Par.para_DIs;
ppMISA_OR_14BS.para_Msh=Par.para_Msh;
ppMISA_OR_14BS.para_InMsh=Par.para_InMsh;
% parameters Bistable-Isola switch
ppMISA_OR_14BS.para_BsIs=[Par.para_BsB_Is; Par.para_BsF_Is; Par.para_Is_BsB; Par.para_Is_BsF];

% parameters Dual bistable switch
ppMISA_OR_14BS.para_DBs=[Par.para_DBsB; Par.para_DBsF];

% parameters Bistable-Inverted Isola switch
ppMISA_OR_14BS.para_BsInIs=[Par.para_InIs_BsB; Par.para_InIs_BsF; Par.para_BsB_InIs; ...
    Par.para_BsF_InIs];

% parameters Dual bistable-Isola switch
ppMISA_OR_14BS.para_DBsIs=[Par.para_DBsB_Is; Par.para_BsB_Is_BsB; Par.para_DBsF_Is; ...
    Par.para_BsF_Is_BsF; Par.para_Is_DBsB; Par.para_Is_DBsF];

% parameters Isola-Mushroom switch
ppMISA_OR_14BS.para_IsMsh=[Par.para_InMsh_Is; Par.para_BsB_Is_BsF; Par.para_Msh_Is; ...
    Par.para_BsF_Is_BsB; Par.para_Is_InMsh; Par.para_Is_Msh];

% parameters Bistable-Mushroom switch
ppMISA_OR_14BS.para_BsMsh=[Par.para_BsB_InMsh; Par.para_InMsh_BsB; Par.para_InMsh_BsF; ...
    Par.para_Msh_BsB; Par.para_Msh_BsF; Par.para_BsF_Msh];

% parameters Dual bistable-Inverted Isola switch
ppMISA_OR_14BS.para_DBsInIs=[Par.para_InIs_DBsB; Par.para_InIs_DBsF; Par.para_BsB_InIs_BsB; ...
    Par.para_DBsB_InIs; Par.para_BsF_InIs_BsF; Par.para_DBsF_InIs];

% parameters Inveerted Isola-Mushroom switch
ppMISA_OR_14BS.para_InIsMsh=[Par.para_InIs_InMsh; Par.para_InIs_Msh; Par.para_BsB_InIs_BsF; ...
    Par.para_InMsh_InIs; Par.para_BsF_InIs_BsB; Par.para_Msh_InIs];