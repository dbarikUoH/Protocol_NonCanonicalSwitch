% *************************************************************************
% This function file determines the new range and the step length of the
% bifurcation parameter based on the locations of the first and last 
% bifurcation points obtained from the low-resolution bifurcation run.
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
function [sigE3,sigE3F1,dsig2nw,dsig2]=ParRegion_highres(nmbr_peaks_ss,sum_diffss,dSc,Sct,dSr,dSn,sigE1,sigE2,dsig2)

kk0=find(nmbr_peaks_ss==2,1,'first');
kk1=find(nmbr_peaks_ss==2,1,'last');
dS=abs(kk0-kk1);
if (dS <= dSc(1))
    sCut=Sct(1);
elseif (dSc(1) < dS && dS <= dSc(2))
    sCut=Sct(2);
elseif (dSc(2) < dS && dS <= dSc(3))
    sCut=Sct(3);
elseif (dS > dSc(3))
    sCut=Sct(4);
end
kk3=kk0-sCut;
kk4=kk1+sCut;
kkF=round(kk3*(sigE2/sigE1),0);
kkL=round(kk4*(sigE2/sigE1),0);
sigE3F=max(kkF,1);
sigE3=min(kkL,sigE2);
%         sigE3=sigE2;

if sum_diffss == 0
    dsig2nw=10;
    factr=dsig2nw/dsig2;
    dsig2=dsig2nw;
    sigE3=round(sigE3/factr,0);
    sigE3F1=round(sigE3F/factr,0);
elseif sum_diffss == 2
    if (dS <= dSr(1))
        dsig2nw=dSn(1);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    elseif (dSr(1) < dS && dS <= dSr(2))
        dsig2nw=dSn(2);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    elseif (dSr(2) < dS && dS <= dSr(3))
        dsig2nw=dSn(3);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    elseif (dSr(3) < dS && dS <= dSr(4))
        dsig2nw=dSn(4);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    else
        dsig2nw=dSn(5);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    end
elseif sum_diffss ~ 2;
    if (dS <= dSr(1))
        dsig2nw=dSn(1);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    elseif (dSr(1) < dS && dS <= dSr(2))
        dsig2nw=dSn(2);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    elseif (dSr(2) < dS && dS <= dSr(3))
        dsig2nw=dSn(3);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    else
        dsig2nw=dSn(4);
        factr=dsig2nw/dsig2;
        dsig2=dsig2nw;
        sigE3=round(sigE3/factr,0);
        sigE3F1=round(sigE3F/factr,0);
    end
end

%         [sum_diffss dS dsig2];

if(sigE3F==1)
    sigE3F1=sigE3F;
elseif (sigE3F1==0)
    sigE3F1=sigE3F;
end