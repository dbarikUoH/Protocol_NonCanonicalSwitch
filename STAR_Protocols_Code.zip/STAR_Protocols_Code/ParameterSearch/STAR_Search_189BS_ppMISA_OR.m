% *************************************************************************
% Search of parameters for canonical and noncanonical bistable switches
% Counts and occurrence probabilities of different types of switches
% Segragation of parameters for different types of switches 
% *************************************************************************
% *************************************************************************
% Date: July 4, 2023
% Debashis Barik, School of Chemistry, University of Hyderabad, India
% dbariksc@uohyd.ac.in
% *************************************************************************
% *************************************************************************
% Model: ppMISA
% Logic Gate: OR
% *************************************************************************

clear
clc
tic

% *************************************************************************
% Sample size of parameter combinations
% *************************************************************************
nr=10000;
% *************************************************************************

% *************************************************************************
% Initialization of the counts of reversible and irreversible switches
% *************************************************************************
Cnt.Is=0;               % Switch: Is                            Sr. No.: 1
Cnt.BsB=0;              % Switch: BsB                           Sr. No.: 2
Cnt.BsF=0;              % Switch: BsF                           Sr. No.: 3
Cnt.InIs=0;             % Switch: InIs                          Sr. No.: 4
Cnt.DIs=0;              % Switch: DIs                           Sr. No.: 5
Cnt.BsB_Is=0;           % Switch: BsB-Is                        Sr. No.: 6
Cnt.BsF_Is=0;           % Switch: BsF-Is                        Sr. No.: 7
Cnt.Is_BsB=0;           % Switch: Is-BsB                        Sr. No.: 8
Cnt.Is_BsF=0;           % Switch: Is-BsF                        Sr. No.: 9
Cnt.InIs_Is=0;          % Switch: InIs-Is                       Sr. No.: 10
Cnt.DBsB=0;             % Switch: DBsB                          Sr. No.: 11
Cnt.InMsh=0;            % Switch: InMsh                         Sr. No.: 12
Cnt.Msh=0;              % Switch: Msh                           Sr. No.: 13
Cnt.DBsF=0;             % Switch: DBsF                          Sr. No.: 14
Cnt.Is_InIs=0;          % Switch: Is-InIs                       Sr. No.: 15
Cnt.InIs_BsB=0;         % Switch: InIs-BsB                      Sr. No.: 16
Cnt.InIs_BsF=0;         % Switch: InIs-BsF                      Sr. No.: 17
Cnt.BsB_InIs=0;         % Switch: BsB-InIs                      Sr. No.: 18
Cnt.BsF_InIs=0;         % Switch: BsF-InIs                      Sr. No.: 19
Cnt.DInIs=0;            % Switch: DInIs                         Sr. No.: 20
Cnt.TIs=0;              % Switch: TIs                           Sr. No.: 21
Cnt.BsB_DIs=0;          % Switch: BsB-DIs                       Sr. No.: 22
Cnt.BsF_DIs=0;          % Switch: BsF-DIs                       Sr. No.: 23
Cnt.Is_BsB_Is=0;        % Switch: Is-BsB-Is                     Sr. No.: 24
Cnt.Is_BsF_Is=0;        % Switch: Is-BsF-Is                     Sr. No.: 25
Cnt.DIs_BsB=0;          % Switch: DIs-BsB                       Sr. No.: 26
Cnt.DIs_BsF=0;          % Switch: DIs-BsF                       Sr. No.: 27
Cnt.InIs_DIs=0;         % Switch: InIs_DIs                      Sr. No.: 28
Cnt.DBsB_Is=0;          % Switch: DBsB-Is                       Sr. No.: 29
Cnt.InMsh_Is=0;         % Switch: InMsh-Is                      Sr. No.: 30
Cnt.BsB_Is_BsB=0;       % Switch: BsB-Is-BsB                    Sr. No.: 31
Cnt.BsB_Is_BsF=0;       % Switch: BsB-Is-BsF                    Sr. No.: 32
Cnt.Msh_Is=0;           % Switch: Msh-Is                        Sr. No.: 33
Cnt.DBsF_Is=0;          % Switch: DBsF-Is                       Sr. No.: 34    
Cnt.BsF_Is_BsB=0;       % Switch: BsF-Is-BsB                    Sr. No.: 35
Cnt.BsF_Is_BsF=0;       % Switch: BsF-Is-BsF                    Sr. No.: 36
Cnt.Is_InIs_Is=0;       % Switch: Is_InIs_Is                    Sr. No.: 37 
Cnt.Is_DBsB=0;          % Switch: Is-DBsB                       Sr. No.: 38
Cnt.Is_InMsh=0;         % Switch: Is-InMsh                      Sr. No.: 39    
Cnt.Is_Msh=0;           % Switch: Is-Msh                        Sr. No.: 40
Cnt.Is_DBsF=0;          % Switch: Is-DBsF                       Sr. No.: 41
Cnt.DIs_Is=0;           % Switch: DIs_Is                        Sr. No.: 42    
Cnt.InIs_BsB_Is=0;      % Switch: InIs_BsB_Is                   Sr. No.: 43
Cnt.InIs_BsF_Is=0;      % Switch: InIs_BsF_Is                   Sr. No.: 44
Cnt.InIs_Is_BsB=0;      % Switch: InIs_Is_BsB                   Sr. No.: 45
Cnt.InIs_Is_BsF=0;      % Switch: InIs_Is_BsF                   Sr. No.: 46
Cnt.BsB_InIs_Is=0;      % Switch: BsB_InIs_Is                   Sr. No.: 47
Cnt.TBsB=0;             % Switch: TBsB                          Sr. No.: 48
Cnt.BsB_InMsh=0;        % Switch: BsB-InMsh                     Sr. No.: 49
Cnt.InMsh_BsB=0;        % Switch: InMsh_BsB                     Sr. No.: 50
Cnt.InMsh_BsF=0;        % Switch: InMsh_BsF                     Sr. No.: 51
Cnt.BsB_Is_InIs=0;      % Switch: BsB_Is_InIs                   Sr. No.: 52
Cnt.BsF_InIs_Is=0;      % Switch: BsF_InIs_Is                   Sr. No.: 53
Cnt.Msh_BsB=0;          % Switch: Msh-BsB                       Sr. No.: 54
Cnt.Msh_BsF=0;          % Switch: Msh-BsF                       Sr. No.: 55
Cnt.BsF_Msh=0;          % Switch: BsF_Msh                       Sr. No.: 56
Cnt.TBsF=0;             % Switch: TBsF                          Sr. No.: 57
Cnt.BsF_Is_InIs=0;      % Switch: BsF_Is_InIs                   Sr. No.: 58
Cnt.Is_InIs_BsB=0;      % Switch: Is_InIs_BsB                   Sr. No.: 59
Cnt.Is_InIs_BsF=0;      % Switch: Is_InIs_BsF                   Sr. No.: 60
Cnt.Is_BsB_InIs=0;      % Switch: Is_BsB_InIs                   Sr. No.: 61
Cnt.Is_BsF_InIs=0;      % Switch: Is_BsF_InIs                   Sr. No.: 62
Cnt.DInIs_Is=0;         % Switch: DInIs_Is                      Sr. No.: 63
Cnt.InIs_DBsB=0;        % Switch: InIs-DBsB                     Sr. No.: 64    
Cnt.InIs_InMsh=0;       % Switch: InIs-InMsh                    Sr. No.: 65    
Cnt.InIs_Msh=0;         % Switch: InIs-Msh                      Sr. No.: 66
Cnt.InIs_DBsF=0;        % Switch: InIs-DBsF                     Sr. No.: 67    
Cnt.InIs_Is_InIs=0;     % Switch: InIs_Is_InIs                  Sr. No.: 68
Cnt.BsB_InIs_BsB=0;     % Switch: BsB-InIs-BsB                  Sr. No.: 69
Cnt.BsB_InIs_BsF=0;     % Switch: BsB-InIs-BsF                  Sr. No.: 70
Cnt.DBsB_InIs=0;        % Switch: DBsB-InIs                     Sr. No.: 71    
Cnt.InMsh_InIs=0;       % Switch: InMsh-InIs                    Sr. No.: 72
Cnt.BsF_InIs_BsB=0;     % Switch: BsF-InIs-BsB                  Sr. No.: 73
Cnt.BsF_InIs_BsF=0;     % Switch: BsF-InIs-BsF                  Sr. No.: 74
Cnt.Msh_InIs=0;         % Switch: Msh-InIs                      Sr. No.: 75
Cnt.DBsF_InIs=0;        % Switch: DBsF-InIs                     Sr. No.: 76
Cnt.Is_DInIs=0;         % Switch: Is_DInIs                      Sr. No.: 77
Cnt.DInIs_BsB=0;        % Switch: DInIs_BsB                     Sr. No.: 78
Cnt.DInIs_BsF=0;        % Switch: DInIs_BsF                     Sr. No.: 79
Cnt.InIs_BsB_InIs=0;    % Switch: InIs_BsB_InIs                 Sr. No.: 80
Cnt.InIs_BsF_InIs=0;    % Switch: InIs_BsF_InIs                 Sr. No.: 81
Cnt.BsB_DInIs=0;        % Switch: BsB_DInIs                     Sr. No.: 82
Cnt.BsF_DInIs=0;        % Switch: BsF_DInIs                     Sr. No.: 83
Cnt.TInIs=0;            % Switch: TInIs                         Sr. No.: 84
Cnt.L_BsB=0;            % Switch: L-BsB                         Sr. No.: 85
Cnt.L_BsF=0;            % Switch: L-BsF                         Sr. No.: 86
Cnt.L_DIs=0;            % Switch: L-DIs                         Sr. No.: 87
Cnt.L_BsF_Is=0;         % Switch: L-BsF-Is                      Sr. No.: 88
Cnt.L_Is_BsB=0;         % Switch: L_Is_BsB                      Sr. No.: 89
Cnt.L_Is_BsF=0;         % Switch: L_Is_BsF                      Sr. No.: 90
Cnt.L_Msh=0;            % Switch: L-Msh                         Sr. No.: 91
Cnt.L_DBsF=0;           % Switch: L-DBsF                        Sr. No.: 92
Cnt.L_Is_InIs=0;        % Switch: L_Is_InIs                     Sr. No.: 93
Cnt.L_BsF_InIs=0;       % Switch: L_BsF_InIs                    Sr. No.: 94
Cnt.L_Tis=0;            % Switch: L_Tis                         Sr. No.: 95
Cnt.L_BsF_DIs=0;        % Switch: L-BsF-DIs                     Sr. No.: 96
Cnt.L_Is_BsB_Is=0;      % Switch: L_Is_BsB_Is                   Sr. No.: 97
Cnt.L_Is_BsF_Is=0;      % Switch: L_Is_BsF_Is                   Sr. No.: 98
Cnt.L_DIs_BsB=0;        % Switch: L_DIs_BsB                     Sr. No.: 99
Cnt.L_DIs_BsF=0;        % Switch: L-DIs-BsF                     Sr. No.: 100
Cnt.L_Msh_Is=0;         % Switch: L-Msh-Is                      Sr. No.: 101
Cnt.L_DBsF_Is=0;        % Switch: L-DBsF-Is                     Sr. No.: 102
Cnt.L_BsF_Is_BsB=0;     % Switch: L-BsF-Is-BsB                  Sr. No.: 103
Cnt.L_BsF_Is_BsF=0;     % Switch: L-BsF-Is-BsF                  Sr. No.: 104
Cnt.L_Is_InIs_Is=0;     % Switch: L_Is_InIs_Is                  Sr. No.: 105
Cnt.L_Is_DBsB=0;        % Switch: L_Is_DBsB                     Sr. No.: 106
Cnt.L_Is_InMsh=0;       % Switch: L-Is-InMsh                    Sr. No.: 107
Cnt.L_Is_Msh=0;         % Switch: L-Is-Msh                      Sr. No.: 108
Cnt.L_Is_DBsF=0;        % Switch: L_Is_DBsF                     Sr. No.: 109
Cnt.L_DIs_Is=0;         % Switch: L_DIs_Is                      Sr. No.: 110
Cnt.L_BsF_InIs_Is=0;    % Switch: L_BsF_InIs_Is                 Sr. No.: 111
Cnt.L_Msh_BsB=0;        % Switch: L_Msh_BsB                     Sr. No.: 112
Cnt.L_Msh_BsF=0;        % Switch: L_Msh_BsF                     Sr. No.: 113
Cnt.L_BsF_Msh=0;        % Switch: L_BsF_Msh                     Sr. No.: 114
Cnt.L_TBsF=0;           % Switch: L_TBsF                        Sr. No.: 115
Cnt.L_BsF_Is_InIs=0;    % Switch: L_BsF_Is_InIs                 Sr. No.: 116
Cnt.L_Is_InIs_BsB=0;    % Switch: L_Is_InIs_BsB                 Sr. No.: 117
Cnt.L_Is_InIs_BsF=0;    % Switch: L_Is_InIs_BsF                 Sr. No.: 118
Cnt.L_Is_BsB_InIs=0;    % Switch: L_Is_BsB_InIs                 Sr. No.: 119
Cnt.L_Is_BsF_InIs=0;    % Switch: L_Is_BsF_InIs                 Sr. No.: 120
Cnt.L_BsF_InIs_BsB=0;   % Switch: L_BsF_InIs_BsB                Sr. No.: 121
Cnt.L_BsF_InIs_BsF=0;   % Switch: L_BsF_InIs_BsF                Sr. No.: 122
Cnt.L_Msh_InIs=0;       % Switch: L_Msh_InIs                    Sr. No.: 123
Cnt.L_DBsF_InIs=0;      % Switch: L_DBsF_InIs                   Sr. No.: 124
Cnt.L_Is_DInIs=0;       % Switch: L_Is_DInIs                    Sr. No.: 125
Cnt.L_BsF_DInIs=0;      % Switch: L_BsF_DInIs                   Sr. No.: 126
Cnt.BsF_R=0;            % Switch: BsF-R                         Sr. No.: 127
Cnt.BsB_R=0;            % Switch: BsB-R                         Sr. No.: 128
Cnt.DIs_R=0;            % Switch: DIs_R                         Sr. No.: 129
Cnt.BsB_Is_R=0;         % Switch: BsB_Is_R                      Sr. No.: 130
Cnt.BsF_Is_R=0;         % Switch: BsF_Is_R                      Sr. No.: 131
Cnt.Is_BsB_R=0;         % Switch: Is-BsB-R                      Sr. No.: 132
Cnt.InIs_Is_R=0;        % Switch: InIs-BsF-R                    Sr. No.: 133
Cnt.DBsB_R=0;           % Switch: DBsB-R                        Sr. No.: 134
Cnt.Msh_R=0;            % Switch: Msh-R                         Sr. No.: 135
Cnt.InIs_BsB_R=0;       % Switch: InIs_BsB_R                    Sr. No.: 136
Cnt.Tis_R=0;            % Switch: Tis_R                         Sr. No.: 137
Cnt.BsB_DIs_R=0;        % Switch: BsB-DIs-R                     Sr. No.: 138
Cnt.BsF_DIs_R=0;        % Switch: BsF_DIs_R                     Sr. No.: 139
Cnt.Is_BsB_Is_R=0;      % Switch: Is-BsB-Is-R                   Sr. No.: 140
Cnt.Is_BsF_Is_R=0;      % Switch: Is_BsF_Is_R                   Sr. No.: 141
Cnt.DIs_BsB_R=0;        % Switch: DIs-BsB-R                     Sr. No.: 142
Cnt.InIs_DIs_R=0;       % Switch: InIs_DIs_R                    Sr. No.: 143
Cnt.DBsB_Is_R=0;        % Switch: DBsB-Is-R                     Sr. No.: 144
Cnt.InMsh_Is_R=0;       % Switch: InMsh-Is-R                    Sr. No.: 145
Cnt.BsB_Is_BsB_R=0;     % Switch: BsB-Is-BsB-R                  Sr. No.: 146
Cnt.Msh_Is_R=0;         % Switch: Msh-Is-R                      Sr. No.: 147
Cnt.DBsF_Is_R=0;        % Switch: DBsF_Is_R                     Sr. No.: 148
Cnt.BsF_Is_BsB_R=0;     % Switch: BsF-Is-BsB-R                  Sr. No.: 149
Cnt.Is_InIs_Is_R=0;     % Switch: Is_InIs_Is_R                  Sr. No.: 150
Cnt.Is_DBsB_R=0;        % Switch: Is-DBsB-R                     Sr. No.: 151
Cnt.Is_Msh_R=0;         % Switch: Is-Msh-R                      Sr. No.: 152
Cnt.InIs_BsB_Is_R=0;    % Switch: InIs_BsB_Is_R                 Sr. No.: 153
Cnt.InIs_BsF_Is_R=0;    % Switch: InIs_BsF_Is_R                 Sr. No.: 154
Cnt.InIs_Is_BsB_R=0;    % Switch: InIs_Is_BsB_R                 Sr. No.: 155
Cnt.BsB_InIs_Is_R=0;    % Switch: BsB_InIs_Is_R                 Sr. No.: 156
Cnt.TBsB_R=0;           % Switch: TBsB_R                        Sr. No.: 157
Cnt.InMsh_BsB_R=0;      % Switch: InMsh_BsB_R                   Sr. No.: 158
Cnt.BsF_InIs_Is_R=0;    % Switch: BsF_InIs_Is_R                 Sr. No.: 159
Cnt.Msh_BsB_R=0;        % Switch: Msh_BsB_R                     Sr. No.: 160
Cnt.BsF_Msh_R=0;        % Switch: BsF_Msh_R                     Sr. No.: 161
Cnt.Is_InIs_BsB_R=0;    % Switch: Is_InIs_BsB_R                 Sr. No.: 162
Cnt.DInIs_Is_R=0;       % Switch: DInIs_Is_R                    Sr. No.: 163
Cnt.InIs_DBsB_R=0;      % Switch: InIs_DBsB_R                   Sr. No.: 164
Cnt.InIs_Msh_R=0;       % Switch: InIs_Msh_R                    Sr. No.: 165
Cnt.BsB_InIs_BsB_R=0;   % Switch: BsB_InIs_BsB_R                Sr. No.: 166
Cnt.BsF_InIs_BsB_R=0;   % Switch: BsF_InIs_BsB_R                Sr. No.: 167
Cnt.DInIs_BsB_R=0;      % Switch: DInIs_BsB_R                   Sr. No.: 168
Cnt.L_Bs_R=0;           % Switch: L-Bs-R                        Sr. No.: 169
Cnt.L_DIs_R=0;          % Switch: L_DIs_R                       Sr. No.: 170
Cnt.L_BsF_Is_R=0;       % Switch: L_BsF_Is_R                    Sr. No.: 171
Cnt.L_Is_BsB_R=0;       % Switch: L_Is_BsB_R                    Sr. No.: 172
Cnt.L_Msh_R=0;          % Switch: L_Msh_R                       Sr. No.: 173
Cnt.L_TIs_R=0;          % Switch: L_TIs_R                       Sr. No.: 174
Cnt.L_BsF_DIs_R=0;      % Switch: L_BsF_DIs_R                   Sr. No.: 175
Cnt.L_Is_BsB_Is_R=0;    % Switch: L_Is_BsB_Is_R                 Sr. No.: 176
Cnt.L_Is_BsF_Is_R=0;    % Switch: L_Is_BsF_Is_R                 Sr. No.: 177
Cnt.L_DIs_BsB_R=0;      % Switch: L_DIs_BsB_R                   Sr. No.: 178
Cnt.L_Msh_Is_R=0;       % Switch: L-Msh-Is-R                    Sr. No.: 179
Cnt.L_DBsF_Is_R=0;      % Switch: L_DBsF_Is_R                   Sr. No.: 180
Cnt.L_BsF_Is_BsB_R=0;   % Switch: L_BsF_Is_BsB_R                Sr. No.: 181
Cnt.L_Is_InIs_Is_R=0;   % Switch: L_Is_InIs_Is_R                Sr. No.: 182
Cnt.L_Is_DBsB_R=0;      % Switch: L_Is_DBsB_R                   Sr. No.: 183
Cnt.L_Is_Msh_R=0;       % Switch: L_Is_Msh_R                    Sr. No.: 184
Cnt.L_BsF_InIs_Is_R=0;  % Switch: L_BsF_InIs_Is_R               Sr. No.: 185
Cnt.L_Msh_BsB_R=0;      % Switch: L_Msh_BsB_R                   Sr. No.: 186
Cnt.L_BsF_Msh_R=0;      % Switch: L_BsF_Msh_R                   Sr. No.: 187
Cnt.L_Is_InIs_BsB_R=0;  % Switch: L_Is_InIs_BsB_R               Sr. No.: 188
Cnt.L_BsF_InIs_BsB_R=0; % Switch: L-BsF-InIs-BsB-R              Sr. No.: 189
% *************************************************************************

% *************************************************************************
% Array for searched parameters for differen switches
% *************************************************************************
bistability_par=[];
para_BS_all=[];
para_BS_pck=[];

Par.para_Is=[];
Par.para_BsB=[];
Par.para_BsF=[];
Par.para_InIs=[];
Par.para_DIs=[];
Par.para_BsB_Is=[];
Par.para_BsF_Is=[];
Par.para_Is_BsB=[];
Par.para_Is_BsF=[];
Par.para_InIs_Is=[];
Par.para_DBsB=[];
Par.para_InMsh=[];
Par.para_Msh=[];
Par.para_DBsF=[];
Par.para_Is_InIs=[];
Par.para_InIs_BsB=[];
Par.para_InIs_BsF=[];
Par.para_BsB_InIs=[];
Par.para_BsF_InIs=[];
Par.para_DInIs=[];
Par.para_TIs=[];
Par.para_BsB_DIs=[];
Par.para_BsF_DIs=[];
Par.para_Is_BsB_Is=[];
Par.para_Is_BsF_Is=[];
Par.para_DIs_BsB=[];
Par.para_DIs_BsF=[];
Par.para_InIs_DIs=[];
Par.para_DBsB_Is=[];
Par.para_InMsh_Is=[];
Par.para_BsB_Is_BsB=[];
Par.para_BsB_Is_BsF=[];
Par.para_Msh_Is=[];
Par.para_DBsF_Is=[];
Par.para_BsF_Is_BsB=[];
Par.para_BsF_Is_BsF=[];
Par.para_Is_InIs_Is=[];
Par.para_Is_DBsB=[];
Par.para_Is_InMsh=[];
Par.para_Is_Msh=[];
Par.para_Is_DBsF=[];
Par.para_DIs_Is=[];
Par.para_InIs_BsB_Is=[];
Par.para_InIs_BsF_Is=[];
Par.para_InIs_Is_BsB=[];
Par.para_InIs_Is_BsF=[];
Par.para_BsB_InIs_Is=[];
Par.para_TBsB=[];
Par.para_BsB_InMsh=[];
Par.para_InMsh_BsB=[];
Par.para_InMsh_BsF=[];
Par.para_BsB_Is_InIs=[];
Par.para_BsF_InIs_Is=[];
Par.para_Msh_BsB=[];
Par.para_Msh_BsF=[];
Par.para_BsF_Msh=[];
Par.para_TBsF=[];
Par.para_BsF_Is_InIs=[];
Par.para_Is_InIs_BsB=[];
Par.para_Is_InIs_BsF=[];
Par.para_Is_BsB_InIs=[];
Par.para_Is_BsF_InIs=[];
Par.para_DInIs_Is=[];
Par.para_InIs_DBsB=[];
Par.para_InIs_InMsh=[];
Par.para_InIs_Msh=[];
Par.para_InIs_DBsF=[];
Par.para_InIs_Is_InIs=[];
Par.para_BsB_InIs_BsB=[];
Par.para_BsB_InIs_BsF=[];
Par.para_DBsB_InIs=[];
Par.para_InMsh_InIs=[];
Par.para_BsF_InIs_BsB=[];
Par.para_BsF_InIs_BsF=[];
Par.para_Msh_InIs=[];
Par.para_DBsF_InIs=[];
Par.para_Is_DInIs=[];
Par.para_DInIs_BsB=[];
Par.para_DInIs_BsF=[];
Par.para_InIs_BsB_InIs=[];
Par.para_InIs_BsF_InIs=[];
Par.para_BsB_DInIs=[];
Par.para_BsF_DInIs=[];
Par.para_TInIs=[];
Par.para_L_BsB=[];
Par.para_L_BsF=[];
Par.para_L_DIs=[];
Par.para_L_BsF_Is=[];
Par.para_L_Is_BsB=[];
Par.para_L_Is_BsF=[];
Par.para_L_Msh=[];
Par.para_L_DBsF=[];
Par.para_L_Is_InIs=[];
Par.para_L_BsF_InIs=[];
Par.para_L_Tis=[];
Par.para_L_BsF_DIs=[];
Par.para_L_Is_BsB_Is=[];
Par.para_L_Is_BsF_Is=[];
Par.para_L_DIs_BsB=[];
Par.para_L_DIs_BsF=[];
Par.para_L_Msh_Is=[];
Par.para_L_DBsF_Is=[];
Par.para_L_BsF_Is_BsB=[];
Par.para_L_BsF_Is_BsF=[];
Par.para_L_Is_InIs_Is=[];
Par.para_L_Is_DBsB=[];
Par.para_L_Is_InMsh=[];
Par.para_L_Is_Msh=[];
Par.para_L_Is_DBsF=[];
Par.para_L_DIs_Is=[];
Par.para_L_BsF_InIs_Is=[];
Par.para_L_Msh_BsB=[];
Par.para_L_Msh_BsF=[];
Par.para_L_BsF_Msh=[];
Par.para_L_TBsF=[];
Par.para_L_BsF_Is_InIs=[];
Par.para_L_Is_InIs_BsB=[];
Par.para_L_Is_InIs_BsF=[];
Par.para_L_Is_BsB_InIs=[];
Par.para_L_Is_BsF_InIs=[];
Par.para_L_BsF_InIs_BsB=[];
Par.para_L_BsF_InIs_BsF=[];
Par.para_L_Msh_InIs=[];
Par.para_L_DBsF_InIs=[];
Par.para_L_Is_DInIs=[];
Par.para_L_BsF_DInIs=[];
Par.para_BsF_R=[];
Par.para_BsB_R=[];
Par.para_DIs_R=[];
Par.para_BsB_Is_R=[];
Par.para_BsF_Is_R=[];
Par.para_Is_BsB_R=[];
Par.para_InIs_Is_R=[];
Par.para_DBsB_R=[];
Par.para_Msh_R=[];
Par.para_InIs_BsB_R=[];
Par.para_Tis_R=[];
Par.para_BsB_DIs_R=[];
Par.para_BsF_DIs_R=[];
Par.para_Is_BsB_Is_R=[];
Par.para_Is_BsF_Is_R=[];
Par.para_DIs_BsB_R=[];
Par.para_InIs_DIs_R=[];
Par.para_DBsB_Is_R=[];
Par.para_InMsh_Is_R=[];
Par.para_BsB_Is_BsB_R=[];
Par.para_Msh_Is_R=[];
Par.para_DBsF_Is_R=[];
Par.para_BsF_Is_BsB_R=[];
Par.para_Is_InIs_Is_R=[];
Par.para_Is_DBsB_R=[];
Par.para_Is_Msh_R=[];
Par.para_InIs_BsB_Is_R=[];
Par.para_InIs_BsF_Is_R=[];
Par.para_InIs_Is_BsB_R=[];
Par.para_BsB_InIs_Is_R=[];
Par.para_TBsB_R=[];
Par.para_InMsh_BsB_R=[];
Par.para_BsF_InIs_Is_R=[];
Par.para_Msh_BsB_R=[];
Par.para_BsF_Msh_R=[];
Par.para_Is_InIs_BsB_R=[];
Par.para_DInIs_Is_R=[];
Par.para_InIs_DBsB_R=[];
Par.para_InIs_Msh_R=[];
Par.para_BsB_InIs_BsB_R=[];
Par.para_BsF_InIs_BsB_R=[];
Par.para_DInIs_BsB_R=[];
Par.para_L_Bs_R=[];
Par.para_L_DIs_R=[];
Par.para_L_BsF_Is_R=[];
Par.para_L_Is_BsB_R=[];
Par.para_L_Msh_R=[];
Par.para_L_TIs_R=[];
Par.para_L_BsF_DIs_R=[];
Par.para_L_Is_BsB_Is_R=[];
Par.para_L_Is_BsF_Is_R=[];
Par.para_L_DIs_BsB_R=[];
Par.para_L_Msh_Is_R=[];
Par.para_L_DBsF_Is_R=[];
Par.para_L_BsF_Is_BsB_R=[];
Par.para_L_Is_InIs_Is_R=[];
Par.para_L_Is_DBsB_R=[];
Par.para_L_Is_Msh_R=[];
Par.para_L_BsF_InIs_Is_R=[];
Par.para_L_Msh_BsB_R=[];
Par.para_L_BsF_Msh_R=[];
Par.para_L_Is_InIs_BsB_R=[];
Par.para_L_BsF_InIs_BsB_R=[];
% *************************************************************************

% *************************************************************************
% To store the index of the parameters
% *************************************************************************
Indx.Is_par=[];
Indx.BsB_par=[];
Indx.BsF_par=[];
Indx.InIs_par=[];
Indx.DIs_par=[];
Indx.BsB_Is_par=[];
Indx.BsF_Is_par=[];
Indx.Is_BsB_par=[];
Indx.Is_BsF_par=[];
Indx.InIs_Is_par=[];
Indx.DBsB_par=[];
Indx.InMsh_par=[];
Indx.Msh_par=[];
Indx.DBsF_par=[];
Indx.Is_InIs_par=[];
Indx.InIs_BsB_par=[];
Indx.InIs_BsF_par=[];
Indx.BsB_InIs_par=[];
Indx.BsF_InIs_par=[];
Indx.DInIs_par=[];
Indx.TIs_par=[];
Indx.BsB_DIs_par=[];
Indx.BsF_DIs_par=[];
Indx.Is_BsB_Is_par=[];
Indx.Is_BsF_Is_par=[];
Indx.DIs_BsB_par=[];
Indx.DIs_BsF_par=[];
Indx.InIs_DIs_par=[];
Indx.DBsB_Is_par=[];
Indx.InMsh_Is_par=[];
Indx.BsB_Is_BsB_par=[];
Indx.BsB_Is_BsF_par=[];
Indx.Msh_Is_par=[];
Indx.DBsF_Is_par=[];
Indx.BsF_Is_BsB_par=[];
Indx.BsF_Is_BsF_par=[];
Indx.Is_InIs_Is_par=[];
Indx.Is_DBsB_par=[];
Indx.Is_InMsh_par=[];
Indx.Is_Msh_par=[];
Indx.Is_DBsF_par=[];
Indx.DIs_Is_par=[];
Indx.InIs_BsB_Is_par=[];
Indx.InIs_BsF_Is_par=[];
Indx.InIs_Is_BsB_par=[];
Indx.InIs_Is_BsF_par=[];
Indx.BsB_InIs_Is_par=[];
Indx.TBsB_par=[];
Indx.BsB_InMsh_par=[];
Indx.InMsh_BsB_par=[];
Indx.InMsh_BsF_par=[];
Indx.BsB_Is_InIs_par=[];
Indx.BsF_InIs_Is_par=[];
Indx.Msh_BsB_par=[];
Indx.Msh_BsF_par=[];
Indx.BsF_Msh_par=[];
Indx.TBsF_par=[];
Indx.BsF_Is_InIs_par=[];
Indx.Is_InIs_BsB_par=[];
Indx.Is_InIs_BsF_par=[];
Indx.Is_BsB_InIs_par=[];
Indx.Is_BsF_InIs_par=[];
Indx.DInIs_Is_par=[];
Indx.InIs_DBsB_par=[];
Indx.InIs_InMsh_par=[];
Indx.InIs_Msh_par=[];
Indx.InIs_DBsF_par=[];
Indx.InIs_Is_InIs_par=[];
Indx.BsB_InIs_BsB_par=[];
Indx.BsB_InIs_BsF_par=[];
Indx.DBsB_InIs_par=[];
Indx.InMsh_InIs_par=[];
Indx.BsF_InIs_BsB_par=[];
Indx.BsF_InIs_BsF_par=[];
Indx.Msh_InIs_par=[];
Indx.DBsF_InIs_par=[];
Indx.Is_DInIs_par=[];
Indx.DInIs_BsB_par=[];
Indx.DInIs_BsF_par=[];
Indx.InIs_BsB_InIs_par=[];
Indx.InIs_BsF_InIs_par=[];
Indx.BsB_DInIs_par=[];
Indx.BsF_DInIs_par=[];
Indx.TInIs_par=[];
Indx.L_BsB_par=[];
Indx.L_BsF_par=[];
Indx.L_DIs_par=[];
Indx.L_BsF_Is_par=[];
Indx.L_Is_BsB_par=[];
Indx.L_Is_BsF_par=[];
Indx.L_Msh_par=[];
Indx.L_DBsF_par=[];
Indx.L_Is_InIs_par=[];
Indx.L_BsF_InIs_par=[];
Indx.L_Tis_par=[];
Indx.L_BsF_DIs_par=[];
Indx.L_Is_BsB_Is_par=[];
Indx.L_Is_BsF_Is_par=[];
Indx.L_DIs_BsB_par=[];
Indx.L_DIs_BsF_par=[];
Indx.L_Msh_Is_par=[];
Indx.L_DBsF_Is_par=[];
Indx.L_BsF_Is_BsB_par=[];
Indx.L_BsF_Is_BsF_par=[];
Indx.L_Is_InIs_Is_par=[];
Indx.L_Is_DBsB_par=[];
Indx.L_Is_InMsh_par=[];
Indx.L_Is_Msh_par=[];
Indx.L_Is_DBsF_par=[];
Indx.L_DIs_Is_par=[];
Indx.L_BsF_InIs_Is_par=[];
Indx.L_Msh_BsB_par=[];
Indx.L_Msh_BsF_par=[];
Indx.L_BsF_Msh_par=[];
Indx.L_TBsF_par=[];
Indx.L_BsF_Is_InIs_par=[];
Indx.L_Is_InIs_BsB_par=[];
Indx.L_Is_InIs_BsF_par=[];
Indx.L_Is_BsB_InIs_par=[];
Indx.L_Is_BsF_InIs_par=[];
Indx.L_BsF_InIs_BsB_par=[];
Indx.L_BsF_InIs_BsF_par=[];
Indx.L_Msh_InIs_par=[];
Indx.L_DBsF_InIs_par=[];
Indx.L_Is_DInIs_par=[];
Indx.L_BsF_DInIs_par=[];
Indx.BsF_R_par=[];
Indx.BsB_R_par=[];
Indx.DIs_R_par=[];
Indx.BsB_Is_R_par=[];
Indx.BsF_Is_R_par=[];
Indx.Is_BsB_R_par=[];
Indx.InIs_Is_R_par=[];
Indx.DBsB_R_par=[];
Indx.Msh_R_par=[];
Indx.InIs_BsB_R_par=[];
Indx.Tis_R_par=[];
Indx.BsB_DIs_R_par=[];
Indx.BsF_DIs_R_par=[];
Indx.Is_BsB_Is_R_par=[];
Indx.Is_BsF_Is_R_par=[];
Indx.DIs_BsB_R_par=[];
Indx.InIs_DIs_R_par=[];
Indx.DBsB_Is_R_par=[];
Indx.InMsh_Is_R_par=[];
Indx.BsB_Is_BsB_R_par=[];
Indx.Msh_Is_R_par=[];
Indx.DBsF_Is_R_par=[];
Indx.BsF_Is_BsB_R_par=[];
Indx.Is_InIs_Is_R_par=[];
Indx.Is_DBsB_R_par=[];
Indx.Is_Msh_R_par=[];
Indx.InIs_BsB_Is_R_par=[];
Indx.InIs_BsF_Is_R_par=[];
Indx.InIs_Is_BsB_R_par=[];
Indx.BsB_InIs_Is_R_par=[];
Indx.TBsB_R_par=[];
Indx.InMsh_BsB_R_par=[];
Indx.BsF_InIs_Is_R_par=[];
Indx.Msh_BsB_R_par=[];
Indx.BsF_Msh_R_par=[];
Indx.Is_InIs_BsB_R_par=[];
Indx.DInIs_Is_R_par=[];
Indx.InIs_DBsB_R_par=[];
Indx.InIs_Msh_R_par=[];
Indx.BsB_InIs_BsB_R_par=[];
Indx.BsF_InIs_BsB_R_par=[];
Indx.DInIs_BsB_R_par=[];
Indx.L_Bs_R_par=[];
Indx.L_DIs_R_par=[];
Indx.L_BsF_Is_R_par=[];
Indx.L_Is_BsB_R_par=[];
Indx.L_Msh_R_par=[];
Indx.L_TIs_R_par=[];
Indx.L_BsF_DIs_R_par=[];
Indx.L_Is_BsB_Is_R_par=[];
Indx.L_Is_BsF_Is_R_par=[];
Indx.L_DIs_BsB_R_par=[];
Indx.L_Msh_Is_R_par=[];
Indx.L_DBsF_Is_R_par=[];
Indx.L_BsF_Is_BsB_R_par=[];
Indx.L_Is_InIs_Is_R_par=[];
Indx.L_Is_DBsB_R_par=[];
Indx.L_Is_Msh_R_par=[];
Indx.L_BsF_InIs_Is_R_par=[];
Indx.L_Msh_BsB_R_par=[];
Indx.L_BsF_Msh_R_par=[];
Indx.L_Is_InIs_BsB_R_par=[];
Indx.L_BsF_InIs_BsB_R_par=[];
% *************************************************************************
param=ones(19,1)*NaN;
ic1=0;
ic3=0;

rng('shuffle')

% *************************************************************************
% Loading of thresholds of S, A and B obtained from half-functional rules
% *************************************************************************
load jas_in_ppMISA_OR.dat
load jab_in_ppMISA_OR.dat
load jba_in_ppMISA_OR.dat
% *************************************************************************

% *************************************************************************
% Random sampling of parameters from uniform distributions
% *************************************************************************
size_jas=length(jas_in_ppMISA_OR);
size_jab=length(jab_in_ppMISA_OR);
size_jba=length(jba_in_ppMISA_OR);

% Randomizing the threshold parameters
rnd_as=randperm(size_jas)';
rnd_bs=randperm(size_jas)';
rnd_ab=randperm(size_jab)';
rnd_ba=randperm(size_jba)';
rnd_bb=randperm(size_jba)';

% Selecting parameters from uniform distributions
ga0=1+(10-1).*rand(nr,1);
gas=1+(100-1).*rand(nr,1);
gab=1+(100-1).*rand(nr,1);
gb0=1+(10-1).*rand(nr,1);
gbs=1+(100-1).*rand(nr,1);
gba=1+(100-1).*rand(nr,1);
gbb=1+(100-1).*rand(nr,1);
nas=randi([1,10],nr,1);
nbs=randi([1,10],nr,1);
nab=randi([1,10],nr,1);
nba=randi([1,10],nr,1);
nbb=randi([1,10],nr,1);
gma=0.01+(0.1-0.01).*rand(nr,1);
gmb=0.01+(0.1-0.01).*rand(nr,1);
% Selecting threshold parameters from distributions of half-functional rule
Jas=jas_in_ppMISA_OR(rnd_as(1:nr));
Jbs=jas_in_ppMISA_OR(rnd_bs(1:nr));
Jab=jab_in_ppMISA_OR(rnd_ab(1:nr));
Jba=jba_in_ppMISA_OR(rnd_ba(1:nr));
Jbb=jba_in_ppMISA_OR(rnd_bb(1:nr));
% *************************************************************************

% *************************************************************************
% Numerical parameters for bifurcation calculations 
% *************************************************************************
sig_max=1000;   % The maximum value of the bifurcation parameter (S)
dsig1=0.5;      % bifurcation parameter step length (dS) in low-res run
dsig2=0.1;      % bifurcation parameter step length (dS) in high-res run
sigE1=sig_max/dsig1;    % # of signal values in low-res calculation      
sigE2=sig_max/dsig2;    % # of signal points in high-res calculation
dx1=8;          % step length of the dynamical variable in low-res run    
dx2=1;          % step length of the dynamical variable in high-res run
xE=10000;       % Maximum value of the dynamical variable     
b1=[0:dx1:xE];      
b2=[0:dx2:xE];
sig1=[1:sigE1];
sig2=[1:sigE2];
% *************************************************************************

% *************************************************************************
% Numerical parameters to speed up high-res bifurcation calculations
% *************************************************************************
% dSr: different chosen values of bistable regions to modify dS as needed
dSr=[5 50 200 400];
% dSn: step length depending on the bistable region in the low-res run
% fac: a factor to adjust step length as needed in high-res run
fac=1;              
dSn=[0.025 0.05 0.1 0.2 0.5].*fac;
% for dS <= dSr(1): new dS=dSn(1)
% for dSr(1) < dS <= dSr(2): new dS=dSn(2)
% for dSr(2) < dS <= dSr(3): new dS=dSn(3)
% for dSr(3) < dS <= dSr(4): new dS=dSn(4)
% for dS> dSr(4): new dS=dSn(5)

% parameters to run high-res run only around the bistable region to seed up
% runtime
dSc=[50 100 200];
Sct=[15 25 50 100];
% *************************************************************************

% *************************************************************************
% Arrays for storing the steady states in the low-res run
% *************************************************************************
nmbr_peaks_ss=ones(1,sigE1)*NaN;
nmbr_peaks_us=ones(1,sigE1)*NaN;
peaks_ss=ones(1,sigE2)*NaN;
peaks_us=ones(1,sigE2)*NaN;
vss=ones(sigE2,4)*NaN;
vuss=ones(sigE2,4)*NaN;
% *************************************************************************

% storing all parameters 
data=[ga0 gas gab gb0 gbs gba gbb Jas Jbs Jab Jba Jbb nas nbs nab nba nbb gma gmb];

% Parameter searching begins for bistbale switches
for kk=1:nr         % loop for parameters

    param=data(kk,:)';
    % 1-p bifurcation run: low resolution run over singal S
    %**********************************************************************
    % First low-resolution 1-p bifurcation is run; if the low-res runs
    % results bistability then a high-res run is performed and the type of
    % switch is also determined. This allows minimize computational cost
    %**********************************************************************
    
    PotEr=[];
    xss=ones(length(sigE1),3)*NaN;
    xus=ones(length(sigE1),3)*NaN;
    dsig2=0.1;
        
    % *********************************************************************
    % Low-res bifurcation run starts here
    % *********************************************************************
    for jj=1:sigE1            % loop for bifurcation parameter
        
        S0=sig1(jj)*dsig1;
        [f]=BS_model_search(S0,b1,param);
        
        z=dx1*cumtrapz(-f); % z: pseudo-potential energy function
        
        % rescaling of potential w.r.t. the minima of the pontential 
        z1=z-min(z);        % used to determine the unstable steady states         
        z2=-z1;             % used to determine the stable steady states
        
        % storing the number of SS at each signal values
        nmbr_peaks_ss(jj)=numel(findpeaks(z2));     % no. of minima in PEF
        nmbr_peaks_us(jj)=numel(findpeaks(z1));     % no. of mamima in PEF
        [stb_pks stb_locs] = findpeaks(z2);
        [ustb_pks ustb_locs] = findpeaks(z1);
        if length(stb_locs)==2
            xss(jj,1)=S0;
            xss(jj,2)=b1(stb_locs(1));
            xss(jj,3)=b1(stb_locs(2));
        elseif length(stb_locs)==1
            xss(jj,1)=S0;
            xss(jj,2)=b1(stb_locs(1));
            xss(jj,3)=NaN;
        end
        if length(ustb_locs)==1
            xus(jj,1)=S0;
            xus(jj,2)=b1(ustb_locs(1));
            xus(jj,3)=NaN;
        elseif length(ustb_locs)==0
            xus(jj,1)=S0;
            xus(jj,2)=NaN;
            xus(jj,3)=NaN;
        end
    end
    % *********************************************************************
    % Low-res run ends here
    % *********************************************************************
    
    % *********************************************************************
    % Determination of no. of bifurcation points
    % *********************************************************************
    srt=nmbr_peaks_ss(cumsum(nmbr_peaks_ss,2) > 0);
    flipdiff=flip(srt);
    end_zero=flipdiff(cumsum(flipdiff,2) > 0);
    final_diff=flip(end_zero);
    diff_ss=diff(final_diff);
    sum_diffss=sum(abs(diff_ss));
    % *********************************************************************

    % *********************************************************************    
    % To Speed up runtime: adjustment of maximum value of the dynamical 
    % variable based on low-res run
    % *********************************************************************
    xmax=max(max(xss(:,2)),max(xss(:,3)));
    %   Setting new range of X based on X_ss maximum
    xE1=round(xmax,-3)+500;
    b2=[0:dx2:xE1];
    % *********************************************************************
    
    % *********************************************************************
    % Running high-res bifurcation only for the parameter combination that 
    % resulted multistability in the low-res run
    % *********************************************************************
    
    % Counting the no. of stable steady state
    if max(nmbr_peaks_ss)==1        % monostability: discarded
        continue
    elseif (nmbr_peaks_us(1)>=1)    % irreversible switch@Left: discarded
        continue
    elseif (nmbr_peaks_us(end)>=1)  % irreversible switch@Right: discarded
        continue
    elseif max(nmbr_peaks_ss)==2    % reversible BS switch: considered
               
%         fig1=figure(1);
%         ic3=ic3+1;
%         subplot(10,10,ic3)
%         hold off
%         plot(xss(:,1),xss(:,2),'.','color','k','MarkerSize',4);
%         hold on;
%         plot(xss(:,1),xss(:,3),'.','color','k','MarkerSize',4);
%         plot(xus(:,1),xus(:,2),'.','color','r','MarkerSize',4);
        
        % *****************************************************************
        % Determination of step length, minimum and maximum values of the
        % bifurcation paramters for the high-res run to speed up calculation
        % by runnig bifurcation only around the bistable region obtained
        % from the low-res run
        % *****************************************************************
        [sigE3,sigE3F1,dsig2nw,dsig2]=ParRegion_highres(nmbr_peaks_ss,sum_diffss,dSc,Sct,dSr,dSn,sigE1,sigE2,dsig2);
        % *****************************************************************
        
        sZ=sigE3-sigE3F1;
        peaks_ss=ones(1,sZ)*NaN;
        peaks_us=ones(1,sZ)*NaN;
        vss=ones(sZ,4)*NaN;
        vuss=ones(sZ,4)*NaN;
        sig2=[1:sigE3];
        
        % *****************************************************************
        % High-res bifurcation run starts here
        % *****************************************************************
        for j=1:sZ                  % Loop for bifurcation parameter
            
            j1=sigE3F1+(j-1);
            S0=sig2(j1)*dsig2;
            [f]=BS_model_search(S0,b2,param);
            
            z0=dx2*cumtrapz(-f);    % z0: pseudo-potential energy function 
            z11=z0-min(z0);         % rescaled PEF 
            z22=-z11;
            
            peaks_ss(j)=numel(findpeaks(z22));      % no. of minima in PEF
            peaks_us(j)=numel(findpeaks(z11));      % no. of maxima in PEF
            
            % pks_stb: no. of stable ss
            [pks_stb locs_stb] = findpeaks(z22); 
            
            % storing of stable branches
            if length(locs_stb)==3
                vss(j,1)=S0;
                vss(j,2)=b2(locs_stb(1));
                vss(j,3)=b2(locs_stb(2));
                vss(j,4)=b2(locs_stb(3));
            elseif length(locs_stb)==2
                vss(j,1)=S0;
                vss(j,2)=b2(locs_stb(1));
                vss(j,3)=b2(locs_stb(2));
                vss(j,4)=NaN;
            elseif length(locs_stb)==1
                vss(j,1)=S0;
                vss(j,2)=b2(locs_stb(1));
                vss(j,3)=NaN;
                vss(j,4)=NaN;
            end
            
            % pks_stb: no. of unstable ss
            [pks_us locs_us] = findpeaks(z11);   
            
            % storing of unstable branches
            if length(locs_us)==2
                vuss(j,1)=S0;
                vuss(j,2)=b2(locs_us(1));
                vuss(j,3)=b2(locs_us(2));
                vuss(j,4)=NaN;
            elseif length(locs_us)==1
                vuss(j,1)=S0;
                vuss(j,2)=b2(locs_us(1));
                vuss(j,3)=NaN;
                vuss(j,4)=NaN;
            elseif length(locs_us)==0
                vuss(j,1)=S0;
                vuss(j,2)=NaN;
                vuss(j,3)=NaN;
                vuss(j,4)=NaN;
            end
        end
        % *****************************************************************
        % High-res run ends here
        % *****************************************************************
        
        % *****************************************************************
        % Discarded: in case the high-res run genrates tristability 
        % *****************************************************************
        if max(peaks_ss)>=3         
            continue
        end
        % *****************************************************************
        
        % *****************************************************************
        % Discarded: if the bifurcation in truncated in the Y axis
        % *****************************************************************
        unF=find(~isnan(vuss(:,2)), 1, 'first');
        unL=find(~isnan(vuss(:,2)), 1, 'last');
        sbF=find(~isnan(vss(:,2)), 1, 'first');
        sbL=find(~isnan(vss(:,2)), 1, 'last');
        
        if peaks_us(1)>0
            if isnan(vss(unF,2)) | isnan(vss(unF,3))
                continue
            end
        elseif peaks_us(end)>0
            if isnan(vss(unL,2)) | isnan(vss(unL,3))
                continue
            end
        elseif peaks_us(1)>1 && peaks_us(end)>1
            if isnan(vss(unL,2)) | isnan(vss(unL,3)) | isnan(vss(unF,3)) | isnan(vss(unL,3))
                continue
            end
        else
            if isnan(vss(unF,3)) | isnan(vss(unL,3))
                continue
            end
        end
        % *****************************************************************
        
        % *****************************************************************
        % To determine jump pattern of SS at the bifurcation points
        % steady states values away from the bifurcation points are
        % discared to minimize error in calculation
        % *****************************************************************
        if (dsig2nw==dSn(5))
            nCut=10;
        elseif (dsig2nw==dSn(4))
            nCut=20;
        elseif (dsig2nw==dSn(3))
            nCut=30;
        elseif (dsig2nw==dSn(2))
            nCut=40;
        else
            nCut=50;
        end
        nF=max(unF-nCut,1);
        nL=min(unL+nCut,sZ);
        nSize=nL-nF+1;

        vss1=vss(nF:nL,:);
        vus1=vuss(nF:nL,:);
        % *****************************************************************
        
        % *****************************************************************
        % Determination of jump numbers and locations in the bifurcation 
        % diagram
        % *****************************************************************
        [sum_diffss2,bfrSN,jmpN,jmpLocSN]=BS_jumpSS_SN(peaks_ss,vss1,vus1);
        % *****************************************************************
        
        % *****************************************************************
        % Storing of parameters for bistable switches in the high-res run
        % *****************************************************************
        ic1=ic1+1;
        bistability_par(ic1,1)=kk;      % storing index of selected parameters
        para_BS_pck(ic1,:)=data(kk,:);  % storing the selected parameters
        % *****************************************************************
        [kk ic1]
                
        %******************************************************************
        % plot of bifurcation diagrams
        %******************************************************************
%         fig2=figure(5);
%         subplot(11,11,ic1)
%         plot_bifurcation(bfrSN,vss1,vus1)
        %******************************************************************
        
        %******************************************************************
        % Determination of switches based on the number of bistable regions
        % and jump patterns of the stable branch at the SN points
        %******************************************************************
        [Cnt,Indx,Par]=BS_switchSegregation_189BS(kk,ic1,data,peaks_ss,sum_diffss2,jmpN,jmpLocSN,Cnt,Indx,Par);
        %******************************************************************
        
    end
end

%**************************************************************************
% Saving counts and parameters of segregated 189 BS switches 
%**************************************************************************
[ppMISA_OR_189BS]=BS_saveCntParIndx_189BS(Cnt,Indx,Par);
%**************************************************************************

%**************************************************************************
% Saving counts and parameters of 14 BS switches obtianed from grouping a 
% topologically similar switches
%**************************************************************************
[ppMISA_OR_14BS]=BS_saveCntParIndx_14BS(Cnt,Par);
%**************************************************************************

ppMISA_OR_189BS.para_BS_pck=para_BS_pck;

total_seg=sum(ppMISA_OR_189BS.total_bistability)

%**************************************************************************
% Ploting the counts and occurrence probability of 84 reversible switches 
%**************************************************************************
plot_counts_84BS(ppMISA_OR_189BS)
%**************************************************************************

%**************************************************************************
% Ploting the counts and occurrence probability of 14 reversible switches 
%**************************************************************************
plot_counts_14BS(ppMISA_OR_14BS)
%**************************************************************************

save parSearch_ppMISA_OR_189BS.mat ppMISA_OR_189BS
save parSearch_ppMISA_OR_14BS.mat ppMISA_OR_14BS

toc

% quit
